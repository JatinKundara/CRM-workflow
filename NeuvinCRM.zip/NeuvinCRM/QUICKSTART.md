# 🎯 NeuvinCRM - Quick Start Guide

## 5-Minute Setup

### Prerequisites
- PHP 8.5+
- MySQL 8.0+
- Apache/Nginx
- Composer
- Git (optional)

### Installation

**1. Download Project**
```bash
# Clone repository
git clone https://github.com/yourusername/neuvincrm.git
cd neuvincrm

# Or extract ZIP
unzip neuvincrm.zip
cd neuvincrm
```

**2. Install Dependencies**
```bash
composer install
```

**3. Configure Environment**
```bash
cp .env.example .env
# Edit .env with your database credentials
nano .env
```

**4. Run Web Installer**
```
Open in browser: http://localhost/neuvincrm/public/installer.php
```

**5. Login**
```
URL: http://localhost/neuvincrm/public
Email: admin@neuvincrm.com
Password: (your chosen password)
```

---

## Directory Structure

```
neuvincrm/
├── public/              # DocumentRoot (index.php, installer.php)
├── app/
│   ├── core/            # Framework classes (Database, Router, Controller, etc.)
│   ├── models/          # Database models
│   ├── services/        # Business logic services
│   ├── controllers/     # Web controllers
│   │   └── Api/         # REST API controllers
│   ├── middleware/      # Request middleware
│   ├── views/           # HTML templates
│   └── helpers/         # Helper functions
├── config/              # Configuration files
├── database/
│   ├── migrations/      # Database schema
│   └── seeders/         # Database seeders
├── routes/              # Route definitions
├── storage/             # Logs, cache, uploads
├── docs/                # Documentation
├── scripts/             # CLI scripts
├── composer.json        # Dependencies
└── .env                 # Environment config
```

---

## Core Modules

### 🏢 CRM Module
**Location:** `/app/controllers/LeadController.php`, `/app/models/Lead.php`

- Lead management with source tracking
- Customer relationship management
- Sales pipeline with 5 stages
- Deal forecasting and probability
- Task management with reminders

**Key Files:**
- `app/views/crm/leads/` - Lead templates
- `app/views/crm/customers/` - Customer templates
- `app/views/crm/deals/` - Deal kanban board

### 🏗️ ERP Module
**Location:** `/app/controllers/` (Employee, Attendance, Product, etc.)

**HRM:**
- Employee records with departments
- Attendance tracking
- Leave management
- Payroll management

**Inventory:**
- Product catalog with categories
- Stock management with reorder levels
- Inventory transactions
- Low stock alerts

**Procurement:**
- Vendor management
- Purchase orders with statuses
- Goods received notes (GRN)
- Purchase tracking

### 💰 Finance Module
**Location:** `/app/controllers/InvoiceController.php`, `/app/controllers/ExpenseController.php`

- Professional invoicing
- Payment tracking
- Expense management
- Recurring invoices
- Tax calculations
- PDF generation

### 📊 Reports Module
**Location:** `/app/controllers/Api/ReportController.php`

- Sales pipeline analysis
- Revenue reports
- Inventory status
- Custom reports (extensible)

---

## Key Features

### Security ✅
- RBAC with 7 roles and 40+ permissions
- Bcrypt password hashing (cost 12)
- CSRF protection on all forms
- XSS prevention via output sanitization
- SQL injection protection (prepared statements)
- Brute force attack prevention
- JWT authentication for API
- Audit logging of all actions

### API 🔌
- Full REST API at `/api/v1/`
- JWT token-based authentication
- CORS support
- Rate limiting (100 req/min)
- Consistent JSON responses
- Comprehensive error codes

### Frontend 🎨
- Bootstrap 5 responsive design
- Vanilla JavaScript (no heavy frameworks)
- Chart.js integration for reports
- Mobile-friendly admin dashboard
- Dark mode ready
- Accessibility (WCAG 2.1)

### Database 🗄️
- 25 well-designed tables
- Proper indexes and foreign keys
- UTF8MB4 charset and collation
- InnoDB storage engine
- Data integrity constraints
- Audit trail table

---

## API Quick Reference

### Authentication
```bash
# Login
curl -X POST http://localhost/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@neuvincrm.com","password":"password"}'
```

### Resources
```bash
# Get all leads
curl -X GET http://localhost/api/v1/leads \
  -H "Authorization: Bearer TOKEN"

# Create invoice
curl -X POST http://localhost/api/v1/invoices \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{...}'

# Get sales report
curl -X GET http://localhost/api/v1/reports/sales \
  -H "Authorization: Bearer TOKEN"
```

---

## Database Schema Overview

### User Management
- `users` - User accounts and authentication
- `roles` - Role definitions (Admin, Manager, Sales, HR, etc.)
- `permissions` - Permission definitions
- `role_permissions` - Role-to-permission mapping

### CRM Core
- `leads` - Lead records with source and status
- `customers` - Customer master data
- `deals` - Sales opportunities in pipeline
- `tasks` - Reminders and action items
- `activities` - Complete activity history

### ERP Modules
- `employees` - Employee records
- `departments` - Department definitions
- `attendance` - Daily attendance logs
- `payroll` - Payroll records
- `products` - Product catalog
- `vendors` - Vendor/supplier master
- `purchase_orders` - Purchase order records

### Finance
- `invoices` - Invoice master
- `invoice_items` - Invoice line items
- `payments` - Payment records
- `expenses` - Expense records

### System
- `audit_logs` - Complete action audit trail
- `activities` - All user activities

---

## User Roles & Permissions

### 👑 Super Admin
- Full system access
- Can create/delete users
- Can manage all roles
- System configuration

### 🔧 Admin
- System administration
- User management (no deletion)
- Report generation
- Settings management

### 👨‍💼 Manager
- Team lead functionality
- Department management
- View/approve timesheets
- Generate team reports

### 🎯 Sales
- Lead and customer management
- Deal pipeline management
- Invoice management
- Sales forecasting

### 👤 HR
- Employee management
- Attendance management
- Leave request approving
- Payroll access

### 💼 Accountant
- Invoice management
- Payment processing
- Expense management
- Financial reports

### 👨‍💻 Employee
- View own information
- Mark attendance
- View assigned tasks
- Submit leave requests

---

## Usage Examples

### Add a Lead via Web UI
1. Login to dashboard
2. Click CRM → Leads
3. Click "+ New Lead"
4. Fill form: Name, Email, Company, Source
5. Click "Add Lead"
6. Lead appears in list with status badge

### Create Invoice via API
```bash
curl -X POST http://localhost/api/v1/invoices \
  -H "Authorization: Bearer JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": 5,
    "invoice_date": "2024-01-15",
    "due_date": "2024-02-15",
    "items": [
      {
        "product_id": 1,
        "quantity": 2,
        "unit_price": 2500
      }
    ]
  }'
```

### Check Low Stock Items
1. Go to ERP → Products
2. Yellow alert shows low stock count
3. See products below reorder level
4. Update stock or create PO

### View Sales Pipeline
1. Go to CRM → Deals
2. Kanban board shows 5 stages
3. Drag deals between stages
4. Card shows deal value
5. Summary shows total pipeline

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Blank page | Check `.env` file, enable APP_DEBUG=true, check error logs |
| Database error | Verify DB credentials, ensure MySQL is running, check /storage/logs/ |
| Permission denied | Run `chmod -R 777 /storage`, check file ownership |
| API 401 error | Token expired, login again, use new token |
| Slow queries | Enable MySQL query log, check indexes, add caching |

---

## Next Steps

1. **Customize roles** - Edit `config/roles.php`
2. **Configure SMTP** - Set `MAIL_*` in `.env` for emails
3. **Add custom fields** - Extend models with additional columns
4. **Create workflows** - Add business logic in services
5. **API integration** - Connect with external systems
6. **Deploy to production** - Follow deployment guide

---

## Important Security Notes

⚠️ **Before Production:**
1. Change JWT_SECRET in `.env`
2. Update admin password immediately
3. Set APP_ENV=production in `.env`
4. Delete `public/installer.php`
5. Enable HTTPS
6. Set proper file permissions (755 for dirs, 644 for files)
7. Configure backup strategy
8. Set up monitoring/alerts

---

## Support & Resources

- **Main Docs:** [README.md](../README.md)
- **API Docs:** [docs/API.md](../docs/API.md)
- **Database Schema:** Check database migrations
- **Code Examples:** See `/app/controllers/` for patterns
- **Help:** Check error logs in `/storage/logs/`

---

## Performance Tips

1. Enable MySQL query cache
2. Add indexes for frequently filtered columns
3. Implement API caching headers
4. Use CDN for static assets
5. Enable gzip compression in web server
6. Use Redis for session storage (optional)
7. Implement database connection pooling

---

**Version:** 1.0.0  
**Last Updated:** April 12, 2024  
**License:** MIT
