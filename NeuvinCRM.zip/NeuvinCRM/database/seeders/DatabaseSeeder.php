<?php
/**
 * Database Seeders
 */

require_once dirname(__DIR__) . '/config/constants.php';

class DatabaseSeeder
{
    private \PDO $db;

    public function __construct()
    {
        $this->db = \App\Core\Database::getInstance()->getConnection();
    }

    public function run()
    {
        echo "Seeding database...\n";

        try {
            $this->seedRoles();
            $this->seedPermissions();
            $this->seedRolePermissions();
            $this->seedUsers();
            $this->seedDepartments();
            $this->seedProductCategories();
            $this->seedProducts();
            $this->seedVendors();

            echo "✅ Database seeding completed successfully!\n";
        } catch (Exception $e) {
            echo "❌ Seeding failed: " . $e->getMessage() . "\n";
            exit(1);
        }
    }

    private function seedRoles(): void
    {
        $roles = [
            ['name' => 'Super Admin', 'description' => 'Full system access'],
            ['name' => 'Admin', 'description' => 'System administrator'],
            ['name' => 'Manager', 'description' => 'Department manager'],
            ['name' => 'Sales', 'description' => 'Sales representative'],
            ['name' => 'HR', 'description' => 'Human Resources'],
            ['name' => 'Accountant', 'description' => 'Finance & Accounting'],
            ['name' => 'Employee', 'description' => 'Regular employee']
        ];

        foreach ($roles as $role) {
            $sql = "INSERT IGNORE INTO roles (name, description) VALUES (?, ?)";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$role['name'], $role['description']]);
        }

        echo "✓ Roles seeded\n";
    }

    private function seedPermissions(): void
    {
        $rolesConfig = require APP_ROOT . '/config/roles.php';
        
        foreach ($rolesConfig['permissions'] as $name => $description) {
            $sql = "INSERT IGNORE INTO permissions (name, description) VALUES (?, ?)";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$name, $description]);
        }

        echo "✓ Permissions seeded\n";
    }

    private function seedRolePermissions(): void
    {
        $rolesConfig = require APP_ROOT . '/config/roles.php';

        foreach ($rolesConfig['roles'] as $roleName => $roleData) {
            $roleResult = $this->db->prepare("SELECT id FROM roles WHERE name = ?")
                ->execute([$roleData['name']])
                ->fetch();

            if (!$roleResult) {
                continue;
            }

            $roleId = $roleResult['id'];

            foreach ($roleData['permissions'] as $permission) {
                if ($permission === '*') {
                    $permResult = $this->db->prepare("SELECT id FROM permissions WHERE name = '*'")
                        ->execute()
                        ->fetch();
                    
                    if ($permResult) {
                        $sql = "INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)";
                        $this->db->prepare($sql)->execute([$roleId, $permResult['id']]);
                    }
                } else {
                    $permResult = $this->db->prepare("SELECT id FROM permissions WHERE name = ?")
                        ->execute([$permission])
                        ->fetch();

                    if ($permResult) {
                        $sql = "INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)";
                        $this->db->prepare($sql)->execute([$roleId, $permResult['id']]);
                    }
                }
            }
        }

        echo "✓ Role permissions seeded\n";
    }

    private function seedUsers(): void
    {
        $superAdminRole = $this->db->prepare("SELECT id FROM roles WHERE name = 'Super Admin'")
            ->execute()
            ->fetch();

        $adminRole = $this->db->prepare("SELECT id FROM roles WHERE name = 'Admin'")
            ->execute()
            ->fetch();

        $users = [
            [
                'name' => 'Super Administrator',
                'email' => 'admin@neuvincrm.com',
                'password' => password_hash('admin123456', PASSWORD_BCRYPT, ['cost' => 12]),
                'role_id' => $superAdminRole['id'] ?? 1,
                'is_active' => true,
                'email_verified_at' => date('Y-m-d H:i:s')
            ],
            [
                'name' => 'Administrator',
                'email' => 'user@neuvincrm.com',
                'password' => password_hash('user123456', PASSWORD_BCRYPT, ['cost' => 12]),
                'role_id' => $adminRole['id'] ?? 2,
                'is_active' => true,
                'email_verified_at' => date('Y-m-d H:i:s')
            ]
        ];

        foreach ($users as $user) {
            $sql = "
                INSERT IGNORE INTO users 
                (name, email, password, role_id, is_active, email_verified_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $user['name'],
                $user['email'],
                $user['password'],
                $user['role_id'],
                $user['is_active'],
                $user['email_verified_at']
            ]);
        }

        echo "✓ Users seeded\n";
    }

    private function seedDepartments(): void
    {
        $departments = [
            'Sales',
            'Marketing',
            'Finance',
            'HR',
            'Operations',
            'IT'
        ];

        foreach ($departments as $dept) {
            $sql = "INSERT IGNORE INTO departments (name) VALUES (?)";
            $this->db->prepare($sql)->execute([$dept]);
        }

        echo "✓ Departments seeded\n";
    }

    private function seedProductCategories(): void
    {
        $categories = [
            'Electronics',
            'Software',
            'Services',
            'Hardware',
            'Consulting'
        ];

        foreach ($categories as $cat) {
            $sql = "INSERT IGNORE INTO product_categories (name) VALUES (?)";
            $this->db->prepare($sql)->execute([$cat]);
        }

        echo "✓ Product categories seeded\n";
    }

    private function seedProducts(): void
    {
        $categoryResult = $this->db->prepare("SELECT id FROM product_categories WHERE name = 'Software'")
            ->execute()
            ->fetch();

        $categoryId = $categoryResult['id'] ?? 1;

        $products = [
            ['name' => 'CRM License', 'sku' => 'CRM-001', 'unit_price' => 299.99, 'quantity' => 50],
            ['name' => 'ERP License', 'sku' => 'ERP-001', 'unit_price' => 499.99, 'quantity' => 30],
            ['name' => 'Support Package', 'sku' => 'SUP-001', 'unit_price' => 99.99, 'quantity' => 100]
        ];

        foreach ($products as $product) {
            $sql = "
                INSERT IGNORE INTO products 
                (name, sku, category_id, unit_price, quantity_in_stock)
                VALUES (?, ?, ?, ?, ?)
            ";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $product['name'],
                $product['sku'],
                $categoryId,
                $product['unit_price'],
                $product['quantity']
            ]);
        }

        echo "✓ Products seeded\n";
    }

    private function seedVendors(): void
    {
        $vendors = [
            ['name' => 'Tech Supplier Inc', 'email' => 'sales@techsupplier.com', 'phone' => '+1-800-123-4567'],
            ['name' => 'Global Services Ltd', 'email' => 'info@globalservices.com', 'phone' => '+44-20-7946-0958'],
            ['name' => 'Premium Logistics', 'email' => 'contact@premiumlogistics.com', 'phone' => '+60-3-7957-7888']
        ];

        foreach ($vendors as $vendor) {
            $sql = "
                INSERT IGNORE INTO vendors 
                (name, email, phone)
                VALUES (?, ?, ?)
            ";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $vendor['name'],
                $vendor['email'],
                $vendor['phone']
            ]);
        }

        echo "✓ Vendors seeded\n";
    }
}

// Run seeding if executed directly
if (php_sapi_name() === 'cli') {
    require_once dirname(__DIR__) . '/vendor/autoload.php';
    $seeder = new DatabaseSeeder();
    $seeder->run();
}
