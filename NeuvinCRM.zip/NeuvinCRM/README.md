# 🚀 NeuvinCRM - Enterprise CRM + ERP System

**A production-ready, scalable CRM + ERP system built with PHP 8.5, MySQL 8+, and Bootstrap 5.**

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![PHP](https://img.shields.io/badge/php-%3E%3D8.5-blue)
![MySQL](https://img.shields.io/badge/mysql-%3E%3D8.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)

---

## 📋 Table of Contents

- [Features](#features)
- [System Requirements](#system-requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage](#usage)
- [API Documentation](#api-documentation)
- [Deployment](#deployment)
- [Database Schema](#database-schema)
- [File Permissions](#file-permissions)
- [Cron Jobs](#cron-jobs)
- [Troubleshooting](#troubleshooting)
- [Support](#support)

---

## ✨ Features

### CRM Modules
- **Leads Management** - Add, track, and convert leads
- **Customer Management** - Maintain customer database with activity history
- **Sales Pipeline** - Kanban board view for deal stages
- **Sales Forecasting** - Predict revenue based on pipeline
- **Task Management** - Assign tasks with reminders
- **Activity Timeline** - Track all interactions

### ERP Modules
- **HRM** - Employee management, attendance, payroll
- **Inventory** - Stock management with barcode support
- **Purchase Orders** - Vendor management and purchase tracking
- **Finance** - Invoicing, expenses, payments with GST/VAT support
- **Reporting** - Comprehensive business reports

### Security & Access Control
- **RBAC** - Role-based access control with 7 predefined roles
- **2FA Ready** - TOTP support for extra security
- **Audit Logs** - Track all user actions
- **Password Hashing** - Bcrypt with cost 12
- **CSRF Protection** - All forms protected
- **XSS Prevention** - Output sanitization
- **SQL Injection Prevention** - Prepared statements

### API & Integration
- **REST API** - Full REST API with JWT authentication
- **CORS Support** - Cross-origin requests enabled
- **API Rate Limiting** - Protect against abuse
- **Multi-tenant Ready** - Design supports multiple organizations

### UI/UX
- **Bootstrap 5** - Responsive admin dashboard
- **Chart.js Integration** - Beautiful data visualizations
- **Vanilla JS** - No heavy frameworks, lightweight
- **Mobile Responsive** - Works on all devices

---

## 📦 System Requirements

### Minimum Requirements
- **PHP**: 8.3 or higher
- **MySQL**: 8.0 or higher
- **Web Server**: Apache 2.4+ or Nginx 1.19+
- **RAM**: 1GB minimum
- **Disk Space**: 500MB minimum
- **Extensions**: PDO, PDO-MySQL, JSON, MBString, cURL

### Recommended Requirements
- **PHP**: 8.3+ with OpCache enabled
- **MySQL**: 8.0+ with InnoDB
- **Web Server**: Nginx 1.24+
- **RAM**: 2GB+
- **SSD**: 2GB+ for better performance
- **SSL**: HTTPS enabled

---

## 🔧 Installation

### Step 1: Download & Extract

```bash
# Clone or download the repository
git clone https://github.com/yourusername/neuvincrm.git
cd neuvincrm

# Or extract ZIP file
unzip neuvincrm.zip
cd neuvincrm
```

### Step 2: Install Dependencies

```bash
# Install Composer dependencies
composer install

# For development
composer install --dev
```

### Step 3: Configure Environment

```bash
# Copy environment file
cp .env.example .env

# Edit .env file with your database credentials
nano .env
```

**Environment Variables:**
```
APP_ENV=production
APP_DEBUG=false

DB_HOST=localhost
DB_NAME=neuvincrm
DB_USER=neuvin_user
DB_PASS=secure_password
DB_PORT=3306

JWT_SECRET=generate-a-secure-token-here

MAIL_DRIVER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
```

### Step 4: Run Installer

1. Open your browser and navigate to: `http://localhost/neuvincrm/public/installer.php`
2. Follow the 4-step installer wizard:
   - **Step 1**: Check server requirements
   - **Step 2**: Configure database
   - **Step 3**: Create admin account
   - **Step 4**: Complete installation

### Step 5: Access Application

```
URL: http://localhost/neuvincrm/public
Email: admin@neuvincrm.com
Password: (the password you set during installation)
```

**⚠️ IMPORTANT:** Delete `public/installer.php` after installation for security!

---

## 🔐 Configuration

### Database Configuration

Edit `config/database.php`:

```php
'mysql' => [
    'driver' => 'mysql',
    'host' => getenv('DB_HOST'),
    'database' => getenv('DB_NAME'),
    'username' => getenv('DB_USER'),
    'password' => getenv('DB_PASS'),
    'port' => getenv('DB_PORT'),
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
]
```

### Roles & Permissions

Edit `config/roles.php` to customize roles and permissions:

Predefined Roles:
- **Super Admin** - Full system access
- **Admin** - System administrator (no user deletion)
- **Manager** - Department manager
- **Sales** - Sales representative
- **HR** - Human Resources
- **Accountant** - Finance & Accounting
- **Employee** - Regular employee

### Email Configuration

Configure SMTP for email notifications:

```
MAIL_DRIVER=smtp
MAIL_HOST=smtp.gmail.com (or your mail server)
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=app-specific-password
```

**Gmail Setup:**
1. Enable 2-Factor Authentication
2. Generate an App Password: https://myaccount.google.com/apppasswords
3. Use the generated password in `.env`

---

## 📊 Usage

### Dashboard

The dashboard provides an overview with:
- Key metrics (leads, deals, invoices, inventory)
- Sales pipeline visualization
- Upcoming tasks
- Low stock alerts
- Recent activities

### CRM Module

**Leads:**
- Add/edit/delete leads
- Track lead source and status
- Convert leads to customers
- Assign to sales representatives

**Customers:**
- Maintain customer database
- View activity history
- Track deals and invoices
- Manage communications

**Sales Pipeline:**
- View all deals on Kanban board
- Drag deals between stages
- Track deal probability and value
- Generate sales forecasts

### ERP Module

**Employees:**
- Add employee records
- Track departments
- Manage designations
- View attendance

**Attendance:**
- Mark daily attendance
- Generate reports by month
- Track leave requests

**Inventory:**
- Add/manage products
- Track stock levels
- Set reorder levels
- Get low stock alerts
- Support barcode scanning

**Purchase Orders:**
- Create purchase orders
- Track vendor performance
- Generate GRNs (Goods Received Notes)

### Finance Module

**Invoices:**
- Create and send invoices
- Track payments
- Support recurring invoices
- Generate PDF invoices
- Tax calculations

**Expenses:**
- Log expenses
- Categorize transactions
- Monthly summaries

---

## 🔌 API Documentation

### Authentication

```bash
# Login and get JWT token
curl -X POST http://localhost/neuvincrm/public/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@neuvincrm.com",
    "password": "password123"
  }'

# Response
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {...}
}
```

### API Endpoints

#### Leads
```bash
# List leads
GET /api/v1/leads

# Get specific lead
GET /api/v1/leads/{id}

# Create lead
POST /api/v1/leads
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john@example.com",
  "phone": "+1234567890",
  "company": "ACME Corp",
  "source": "website"
}

# Update lead
PUT /api/v1/leads/{id}

# Delete lead
DELETE /api/v1/leads/{id}
```

#### Customers
```bash
GET /api/v1/customers
POST /api/v1/customers
GET /api/v1/customers/{id}
PUT /api/v1/customers/{id}
DELETE /api/v1/customers/{id}
```

#### Invoices
```bash
GET /api/v1/invoices
POST /api/v1/invoices
GET /api/v1/invoices/{id}
PUT /api/v1/invoices/{id}
DELETE /api/v1/invoices/{id}
POST /api/v1/invoices/{id}/send
```

#### Products
```bash
GET /api/v1/products
POST /api/v1/products
GET /api/v1/products/{id}
PUT /api/v1/products/{id}
DELETE /api/v1/products/{id}
```

#### Employees
```bash
GET /api/v1/employees
POST /api/v1/employees
GET /api/v1/employees/{id}
PUT /api/v1/employees/{id}
DELETE /api/v1/employees/{id}
```

#### Reports
```bash
GET /api/v1/reports/sales
GET /api/v1/reports/revenue
GET /api/v1/reports/inventory
```

### Using the API with cURL

```bash
# Get token
TOKEN=$(curl -s -X POST http://localhost/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@neuvincrm.com","password":"password"}' \
  | jq -r '.token')

# Make API request
curl -X GET http://localhost/api/v1/leads \
  -H "Authorization: Bearer $TOKEN"
```

---

## 🚢 Deployment

### Apache Deployment

```apache
<VirtualHost *:80>
    ServerName neuvincrm.example.com
    DocumentRoot /var/www/neuvincrm/public

    <Directory /var/www/neuvincrm/public>
        AllowOverride All
        Require all granted
    </Directory>

    # Redirect HTTP to HTTPS
    Redirect permanent / https://neuvincrm.example.com/
</VirtualHost>

<VirtualHost *:443>
    ServerName neuvincrm.example.com
    DocumentRoot /var/www/neuvincrm/public
    SSLEngine on
    SSLCertificateFile /etc/ssl/certs/neuvincrm.crt
    SSLCertificateKeyFile /etc/ssl/private/neuvincrm.key

    <Directory /var/www/neuvincrm/public>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

### Nginx Deployment

```nginx
server {
    listen 80;
    server_name neuvincrm.example.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name neuvincrm.example.com;
    root /var/www/neuvincrm/public;

    ssl_certificate /etc/ssl/certs/neuvincrm.crt;
    ssl_certificate_key /etc/ssl/private/neuvincrm.key;

    index index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.3-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\. {
        deny all;
    }
}
```

### Docker Deployment

```dockerfile
FROM php:8.3-fpm
WORKDIR /var/www/neuvincrm

# Install dependencies
RUN apt-get update && apt-get install -y \
    libpq-dev \
    && docker-php-ext-install pdo pdo_mysql mbstring

# Copy application
COPY . .

# Install Composer dependencies
RUN curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
RUN composer install --no-dev --optimize-autoloader

# Set permissions
RUN chown -R www-data:www-data /var/www/neuvincrm/storage

EXPOSE 9000
CMD ["php-fpm"]
```

---

## 🗄️ Database Schema

### Core Tables
- `users` - User accounts
- `roles` - Role definitions
- `permissions` - Permission definitions
- `role_permissions` - Role-permission mapping

### CRM Tables
- `leads` - Lead records
- `customers` - Customer records
- `deals` - Sales opportunities
- `tasks` - Tasks and reminders
- `activities` - Activity timeline

### ERP Tables
- `employees` - Employee records
- `departments` - Department definitions
- `attendance` - Attendance records
- `leave_requests` - Leave applications
- `payroll` - Payroll records

### Inventory Tables
- `products` - Product catalog
- `product_categories` - Product categories
- `inventory_transactions` - Stock movements
- `vendors` - Vendor records
- `purchase_orders` - Purchase orders
- `goods_received_notes` - GRN records

### Finance Tables
- `invoices` - Invoice records
- `invoice_items` - Invoice line items
- `payments` - Payment records
- `expenses` - Expense records

### Audit Tables
- `audit_logs` - Action audit trails

---

## 📁 File Permissions

```bash
# Set directory permissions (chmod 755)
sudo chmod -R 755 /var/www/neuvincrm

# Set storage and cache writable (chmod 777)
sudo chmod -R 777 /var/www/neuvincrm/storage
sudo chmod -R 777 /var/www/neuvincrm/public/assets

# Set owner to web server
sudo chown -R www-data:www-data /var/www/neuvincrm
```

---

## ⏰ Cron Jobs

### Email Notifications
```bash
*/5 * * * * /usr/bin/php /var/www/neuvincrm/cron/notifications.php
```

### Recurring Invoices
```bash
0 0 * * * /usr/bin/php /var/www/neuvincrm/cron/recurring-invoices.php
```

### Backup
```bash
0 2 * * * /usr/bin/php /var/www/neuvincrm/cron/backup.php
```

### Maintenance
```bash
0 3 * * * /usr/bin/php /var/www/neuvincrm/cron/maintenance.php
```

---

## 🔍 Troubleshooting

### PHP Extensions Missing
```bash
# Check installed extensions
php -m

# Install missing extensions
sudo apt-get install php8.3-pdo php8.3-mysql php8.3-mbstring
```

### Database Connection Error
```bash
# Test connection
mysql -h localhost -u neuvin_user -p neuvincrm

# Check credentials in .env
cat .env | grep DB_
```

### Permission Denied Errors
```bash
# Fix storage permissions
sudo chmod -R 777 /var/www/neuvincrm/storage

# Fix cache permissions
sudo chmod -R 777 /var/www/neuvincrm/storage/cache
```

### Blank Page
```bash
# Check error logs
tail -f /var/log/php-fpm.log
tail -f /var/log/apache2/error.log

# Enable debug in .env
APP_DEBUG=true
```

### Slow Performance
```bash
# Enable PHP OpCache in php.ini
opcache.enable=1
opcache.memory_consumption=128
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=4000
opcache.validate_timestamps=0
```

---

## 🆘 Support

### Documentation
- [API Documentation](docs/api.md)
- [Database Schema](docs/schema.md)
- [User Guide](docs/user-guide.md)

### Getting Help
- Email: support@neuvincrm.com
- GitHub Issues: https://github.com/yourusername/neuvincrm/issues
- Wiki: https://github.com/yourusername/neuvincrm/wiki

### Reporting Bugs
Please include:
1. PHP version
2. MySQL version
3. Steps to reproduce
4. Error messages
5. Debug logs

---

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

## 🤝 Contributing

We welcome contributions! Please follow these guidelines:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 🎉 Getting Started

### For New Users
1. Install the application following the Installation section
2. Log in with admin credentials
3. Visit the Dashboard to familiarize yourself
4. Check the User Guide for detailed instructions

### For Developers
1. Clone the repository
2. Install dependencies: `composer install`
3. Copy `.env.example` to `.env`
4. Run migrations: `php app/core/Migration.php`
5. Seed database: `php database/seeders/DatabaseSeeder.php`
6. Start development server: `php -S localhost:8000 -t public`

### API Testing
Use Postman or similar tool to test API endpoints:
```
Base URL: http://localhost/api/v1
Content-Type: application/json
Authorization: Bearer {JWT_TOKEN}
```

---

**Made with ❤️ for Enterprise**

Last Updated: April 12, 2026
Version: 1.0.0
