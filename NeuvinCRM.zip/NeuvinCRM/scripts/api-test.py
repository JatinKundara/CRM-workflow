#!/usr/bin/env python3

"""
NeuvinCRM API Testing Script
Usage: python3 api-test.py
"""

import requests
import json
import sys
from tabulate import tabulate

BASE_URL = "http://localhost/neuvincrm/public/api/v1"
EMAIL = "admin@neuvincrm.com"
PASSWORD = "admin123456"

class APITester:
    def __init__(self, base_url):
        self.base_url = base_url
        self.token = None
        self.session = requests.Session()

    def login(self):
        """Test login endpoint"""
        print("🔐 Testing Login Endpoint...")
        response = self.session.post(
            f"{self.base_url}/auth/login",
            json={
                "email": EMAIL,
                "password": PASSWORD
            }
        )

        if response.status_code == 200:
            data = response.json()
            self.token = data.get('token')
            print(f"✓ Login successful! Token: {self.token[:20]}...\n")
            return True
        else:
            print(f"✗ Login failed! Status: {response.status_code}")
            print(response.text)
            return False

    def _headers(self):
        """Get authorization headers"""
        return {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }

    def get_leads(self):
        """Get list of leads"""
        print("📋 Fetching Leads...")
        response = self.session.get(
            f"{self.base_url}/leads",
            headers=self._headers()
        )

        if response.status_code == 200:
            data = response.json()
            leads = data.get('data', [])
            
            if leads:
                table_data = [[
                    lead['id'],
                    lead['first_name'] + ' ' + lead['last_name'],
                    lead['email'],
                    lead['status']
                ] for lead in leads]
                
                print(tabulate(
                    table_data,
                    headers=['ID', 'Name', 'Email', 'Status'],
                    tablefmt='grid'
                ))
            else:
                print("No leads found.")
            print()
        else:
            print(f"Error: {response.status_code}\n")

    def create_lead(self):
        """Create a new lead"""
        print("➕ Creating New Lead...")
        response = self.session.post(
            f"{self.base_url}/leads",
            headers=self._headers(),
            json={
                "first_name": "John",
                "last_name": "Doe",
                "email": "john.doe@example.com",
                "phone": "+1234567890",
                "company": "Tech Corp",
                "source": "api"
            }
        )

        if response.status_code in [200, 201]:
            data = response.json()
            print(f"✓ Lead created successfully!")
            print(json.dumps(data, indent=2))
        else:
            print(f"✗ Failed to create lead: {response.status_code}")
            print(response.text)
        print()

    def get_products(self):
        """Get list of products"""
        print("📦 Fetching Products...")
        response = self.session.get(
            f"{self.base_url}/products",
            headers=self._headers()
        )

        if response.status_code == 200:
            data = response.json()
            products = data.get('data', [])
            
            if products:
                table_data = [[
                    p['id'],
                    p['name'],
                    f"${p['unit_price']:.2f}",
                    p['current_stock']
                ] for p in products]
                
                print(tabulate(
                    table_data,
                    headers=['ID', 'Product', 'Price', 'Stock'],
                    tablefmt='grid'
                ))
            else:
                print("No products found.")
            print()
        else:
            print(f"Error: {response.status_code}\n")

    def get_reports(self):
        """Get sales report"""
        print("📊 Fetching Sales Report...")
        response = self.session.get(
            f"{self.base_url}/reports/sales",
            headers=self._headers()
        )

        if response.status_code == 200:
            data = response.json()
            report = data.get('data', {})
            print(json.dumps(report, indent=2))
        else:
            print(f"Error: {response.status_code}")
        print()

    def run_all_tests(self):
        """Run all tests"""
        print("🚀 NeuvinCRM API Testing\n")

        if not self.login():
            sys.exit(1)

        self.get_leads()
        self.create_lead()
        self.get_products()
        self.get_reports()

        print("✓ All tests completed!")

if __name__ == "__main__":
    tester = APITester(BASE_URL)
    tester.run_all_tests()
