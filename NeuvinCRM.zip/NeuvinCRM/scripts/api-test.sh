#!/usr/bin/env bash

# NeuvinCRM API Testing Script
# Usage: ./api-test.sh

BASE_URL="http://localhost/neuvincrm/public/api/v1"
EMAIL="admin@neuvincrm.com"
PASSWORD="admin123456"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🚀 NeuvinCRM API Testing${NC}\n"

# Step 1: Login
echo -e "${YELLOW}Step 1: Testing Login Endpoint${NC}"
LOGIN_RESPONSE=$(curl -s -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d "{
    \"email\": \"$EMAIL\",
    \"password\": \"$PASSWORD\"
  }")

echo "Response: $LOGIN_RESPONSE"

# Extract token
TOKEN=$(echo $LOGIN_RESPONSE | python3 -c "import sys, json; print(json.load(sys.stdin)['token'])" 2>/dev/null)

if [ -z "$TOKEN" ]; then
    echo -e "${RED}❌ Login failed!${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Login successful! Token: ${TOKEN:0:20}...${NC}\n"

# Step 2: List Leads
echo -e "${YELLOW}Step 2: Listing Leads${NC}"
curl -s -X GET "$BASE_URL/leads" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" | python3 -m json.tool

echo -e "\n"

# Step 3: Create Lead
echo -e "${YELLOW}Step 3: Creating New Lead${NC}"
CREATE_LEAD_RESPONSE=$(curl -s -X POST "$BASE_URL/leads" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "first_name": "Test",
    "last_name": "Lead",
    "email": "test@example.com",
    "phone": "+1234567890",
    "company": "Test Company",
    "source": "api"
  }')

echo "Response: $CREATE_LEAD_RESPONSE" | python3 -m json.tool

echo -e "\n"

# Step 4: List Products
echo -e "${YELLOW}Step 4: Listing Products${NC}"
curl -s -X GET "$BASE_URL/products" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" | python3 -m json.tool

echo -e "\n"

# Step 5: Sales Report
echo -e "${YELLOW}Step 5: Getting Sales Report${NC}"
curl -s -X GET "$BASE_URL/reports/sales" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" | python3 -m json.tool

echo -e "\n${GREEN}✓ All tests completed!${NC}"
