<?php
/**
 * Web Routes
 */

$app = \App\Core\Application::getInstance();
$router = $app->getRouter();

// Auth Routes
$router->get('/login', 'AuthController@showLogin');
$router->post('/login', 'AuthController@login');
$router->get('/logout', 'AuthController@logout');
$router->get('/register', 'AuthController@showRegister');
$router->post('/register', 'AuthController@register');
$router->get('/forgot-password', 'AuthController@showForgotPassword');
$router->post('/forgot-password', 'AuthController@sendResetEmail');
$router->get('/reset-password', 'AuthController@showResetPassword');
$router->post('/reset-password', 'AuthController@resetPassword');

// Dashboard
$router->get('/', 'DashboardController@index', ['AuthMiddleware']);
$router->get('/dashboard', 'DashboardController@index', ['AuthMiddleware']);

// CRM Routes
$router->get('/crm/leads', 'LeadController@index', ['AuthMiddleware']);
$router->get('/crm/leads/{id}', 'LeadController@show', ['AuthMiddleware']);
$router->post('/crm/leads', 'LeadController@store', ['AuthMiddleware']);
$router->put('/crm/leads/{id}', 'LeadController@update', ['AuthMiddleware']);
$router->delete('/crm/leads/{id}', 'LeadController@delete', ['AuthMiddleware']);

$router->get('/crm/customers', 'CustomerController@index', ['AuthMiddleware']);
$router->get('/crm/customers/{id}', 'CustomerController@show', ['AuthMiddleware']);
$router->post('/crm/customers', 'CustomerController@store', ['AuthMiddleware']);
$router->put('/crm/customers/{id}', 'CustomerController@update', ['AuthMiddleware']);
$router->delete('/crm/customers/{id}', 'CustomerController@delete', ['AuthMiddleware']);

$router->get('/crm/deals', 'DealController@index', ['AuthMiddleware']);
$router->get('/crm/deals/kanban', 'DealController@kanban', ['AuthMiddleware']);
$router->post('/crm/deals', 'DealController@store', ['AuthMiddleware']);
$router->put('/crm/deals/{id}', 'DealController@update', ['AuthMiddleware']);

$router->get('/crm/tasks', 'TaskController@index', ['AuthMiddleware']);
$router->post('/crm/tasks', 'TaskController@store', ['AuthMiddleware']);

// ERP Routes
$router->get('/erp/employees', 'EmployeeController@index', ['AuthMiddleware']);
$router->get('/erp/employees/{id}', 'EmployeeController@show', ['AuthMiddleware']);
$router->post('/erp/employees', 'EmployeeController@store', ['AuthMiddleware']);

$router->get('/erp/attendance', 'AttendanceController@index', ['AuthMiddleware']);
$router->post('/erp/attendance', 'AttendanceController@markAttendance', ['AuthMiddleware']);

$router->get('/erp/payroll', 'PayrollController@index', ['AuthMiddleware']);
$router->post('/erp/payroll/generate', 'PayrollController@generate', ['AuthMiddleware']);

$router->get('/erp/products', 'ProductController@index', ['AuthMiddleware']);
$router->get('/erp/products/{id}', 'ProductController@show', ['AuthMiddleware']);
$router->post('/erp/products', 'ProductController@store', ['AuthMiddleware']);

$router->get('/erp/vendors', 'VendorController@index', ['AuthMiddleware']);
$router->post('/erp/vendors', 'VendorController@store', ['AuthMiddleware']);

$router->get('/erp/purchase-orders', 'PurchaseOrderController@index', ['AuthMiddleware']);
$router->post('/erp/purchase-orders', 'PurchaseOrderController@store', ['AuthMiddleware']);

// Finance Routes
$router->get('/finance/invoices', 'InvoiceController@index', ['AuthMiddleware']);
$router->get('/finance/invoices/{id}', 'InvoiceController@show', ['AuthMiddleware']);
$router->post('/finance/invoices', 'InvoiceController@store', ['AuthMiddleware']);
$router->get('/finance/invoices/{id}/pdf', 'InvoiceController@generatePdf', ['AuthMiddleware']);

$router->get('/finance/expenses', 'ExpenseController@index', ['AuthMiddleware']);
$router->post('/finance/expenses', 'ExpenseController@store', ['AuthMiddleware']);

// Settings Routes
$router->get('/settings', 'SettingController@index', ['AuthMiddleware']);
$router->post('/settings', 'SettingController@update', ['AuthMiddleware']);

// Profile Routes
$router->get('/profile', 'ProfileController@show', ['AuthMiddleware']);
$router->post('/profile', 'ProfileController@update', ['AuthMiddleware']);
