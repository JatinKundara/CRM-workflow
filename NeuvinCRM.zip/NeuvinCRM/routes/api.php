<?php
/**
 * API Routes
 */

$app = \App\Core\Application::getInstance();
$router = $app->getRouter();

// API Auth Routes
$router->post('/api/v1/auth/login', 'Api\AuthController@login', ['CorsMiddleware']);
$router->post('/api/v1/auth/logout', 'Api\AuthController@logout', ['CorsMiddleware', 'JwtMiddleware']);
$router->post('/api/v1/auth/refresh', 'Api\AuthController@refreshToken', ['CorsMiddleware', 'JwtMiddleware']);

// API Leads
$router->get('/api/v1/leads', 'Api\LeadController@index', ['CorsMiddleware', 'JwtMiddleware']);
$router->post('/api/v1/leads', 'Api\LeadController@store', ['CorsMiddleware', 'JwtMiddleware']);
$router->get('/api/v1/leads/{id}', 'Api\LeadController@show', ['CorsMiddleware', 'JwtMiddleware']);
$router->put('/api/v1/leads/{id}', 'Api\LeadController@update', ['CorsMiddleware', 'JwtMiddleware']);
$router->delete('/api/v1/leads/{id}', 'Api\LeadController@delete', ['CorsMiddleware', 'JwtMiddleware']);

// API Customers
$router->get('/api/v1/customers', 'Api\CustomerController@index', ['CorsMiddleware', 'JwtMiddleware']);
$router->post('/api/v1/customers', 'Api\CustomerController@store', ['CorsMiddleware', 'JwtMiddleware']);
$router->get('/api/v1/customers/{id}', 'Api\CustomerController@show', ['CorsMiddleware', 'JwtMiddleware']);
$router->put('/api/v1/customers/{id}', 'Api\CustomerController@update', ['CorsMiddleware', 'JwtMiddleware']);
$router->delete('/api/v1/customers/{id}', 'Api\CustomerController@delete', ['CorsMiddleware', 'JwtMiddleware']);

// API Invoices
$router->get('/api/v1/invoices', 'Api\InvoiceController@index', ['CorsMiddleware', 'JwtMiddleware']);
$router->post('/api/v1/invoices', 'Api\InvoiceController@store', ['CorsMiddleware', 'JwtMiddleware']);
$router->get('/api/v1/invoices/{id}', 'Api\InvoiceController@show', ['CorsMiddleware', 'JwtMiddleware']);
$router->put('/api/v1/invoices/{id}', 'Api\InvoiceController@update', ['CorsMiddleware', 'JwtMiddleware']);
$router->delete('/api/v1/invoices/{id}', 'Api\InvoiceController@delete', ['CorsMiddleware', 'JwtMiddleware']);
$router->post('/api/v1/invoices/{id}/send', 'Api\InvoiceController@send', ['CorsMiddleware', 'JwtMiddleware']);

// API Products
$router->get('/api/v1/products', 'Api\ProductController@index', ['CorsMiddleware', 'JwtMiddleware']);
$router->post('/api/v1/products', 'Api\ProductController@store', ['CorsMiddleware', 'JwtMiddleware']);
$router->get('/api/v1/products/{id}', 'Api\ProductController@show', ['CorsMiddleware', 'JwtMiddleware']);
$router->put('/api/v1/products/{id}', 'Api\ProductController@update', ['CorsMiddleware', 'JwtMiddleware']);
$router->delete('/api/v1/products/{id}', 'Api\ProductController@delete', ['CorsMiddleware', 'JwtMiddleware']);

// API Employees
$router->get('/api/v1/employees', 'Api\EmployeeController@index', ['CorsMiddleware', 'JwtMiddleware']);
$router->post('/api/v1/employees', 'Api\EmployeeController@store', ['CorsMiddleware', 'JwtMiddleware']);
$router->get('/api/v1/employees/{id}', 'Api\EmployeeController@show', ['CorsMiddleware', 'JwtMiddleware']);
$router->put('/api/v1/employees/{id}', 'Api\EmployeeController@update', ['CorsMiddleware', 'JwtMiddleware']);
$router->delete('/api/v1/employees/{id}', 'Api\EmployeeController@delete', ['CorsMiddleware', 'JwtMiddleware']);

// API Reports
$router->get('/api/v1/reports/sales', 'Api\ReportController@sales', ['CorsMiddleware', 'JwtMiddleware']);
$router->get('/api/v1/reports/revenue', 'Api\ReportController@revenue', ['CorsMiddleware', 'JwtMiddleware']);
$router->get('/api/v1/reports/inventory', 'Api\ReportController@inventory', ['CorsMiddleware', 'JwtMiddleware']);
