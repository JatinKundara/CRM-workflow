<?php
/**
 * Application Constants
 */

// Static constants
define('APP_NAME', 'NeuvinCRM');
define('APP_VERSION', '1.0.0');

// Dynamic constants (from environment with fallbacks)
define('APP_ENV', getenv('APP_ENV') ?: 'development');
define('APP_DEBUG', getenv('APP_DEBUG') ?: true);

// Paths
define('APP_ROOT', dirname(__DIR__));
define('PUBLIC_PATH', dirname(__DIR__) . '/public');
define('STORAGE_PATH', dirname(__DIR__) . '/storage');
define('LOGS_PATH', dirname(__DIR__) . '/storage/logs');
define('UPLOADS_PATH', dirname(__DIR__) . '/storage/uploads');
define('CACHE_PATH', dirname(__DIR__) . '/storage/cache');

// Base URL path (for redirects and links)
// Detect base path from SCRIPT_NAME (set by Apache/Nginx)
$scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
$scriptDir = !empty($scriptName) ? dirname($scriptName) : '';
define('BASE_PATH', !empty($scriptDir) && $scriptDir !== '.' ? rtrim($scriptDir, '/') : '/');

// Construct BASE_URL only in web context
$baseUrl = '/';
if (!empty($_SERVER['HTTP_HOST']) && isset($_SERVER['SCRIPT_NAME'])) {
    $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $baseUrl = $protocol . '://' . $_SERVER['HTTP_HOST'] . BASE_PATH;
}
define('BASE_URL', $baseUrl);

// Database
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'neuvincrm');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_PORT', getenv('DB_PORT') ?: 3306);

// Security
define('PASSWORD_HASH_ALGO', PASSWORD_BCRYPT);
define('PASSWORD_HASH_OPTIONS', ['cost' => 12]);
define('JWT_SECRET', getenv('JWT_SECRET') ?: 'your-super-secret-jwt-key-change-in-production');
define('JWT_EXPIRATION', 86400); // 24 hours

// Session
define('SESSION_TIMEOUT', 3600); // 1 hour
define('REMEMBER_ME_DURATION', 2592000); // 30 days

// Email
define('MAIL_DRIVER', getenv('MAIL_DRIVER') ?: 'smtp');
define('MAIL_HOST', getenv('MAIL_HOST') ?: 'smtp.mailtrap.io');
define('MAIL_PORT', getenv('MAIL_PORT') ?: 587);
define('MAIL_USERNAME', getenv('MAIL_USERNAME') ?: '');
define('MAIL_PASSWORD', getenv('MAIL_PASSWORD') ?: '');
define('MAIL_FROM', getenv('MAIL_FROM') ?: 'noreply@neuvincrm.com');
define('MAIL_FROM_NAME', getenv('MAIL_FROM_NAME') ?: 'NeuvinCRM');

// Pagination
define('ITEMS_PER_PAGE', 20);

// Currency & Localization
define('DEFAULT_CURRENCY', 'USD');
define('DEFAULT_TIMEZONE', 'UTC');
define('DEFAULT_LOCALE', 'en_US');

// File Upload Constraints
define('MAX_UPLOAD_SIZE', 52428800); // 50MB
define('ALLOWED_UPLOAD_TYPES', ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'gif']);

// Brute Force Protection
define('BRUTE_FORCE_MAX_ATTEMPTS', 5);
define('BRUTE_FORCE_TIMEOUT', 900); // 15 minutes

// API
define('API_VERSION', 'v1');
define('API_RATE_LIMIT', 1000); // requests per hour
