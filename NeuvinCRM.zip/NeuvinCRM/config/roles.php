<?php
/**
 * Roles & Permissions Configuration
 */

return [
    'roles' => [
        'super_admin' => [
            'id' => 1,
            'name' => 'Super Admin',
            'description' => 'Full system access',
            'permissions' => ['*'] // All permissions
        ],
        'admin' => [
            'id' => 2,
            'name' => 'Admin',
            'description' => 'System administrator',
            'permissions' => [
                'users.manage', 'roles.manage', 'settings.manage',
                'crm.*', 'erp.*', 'reports.view'
            ]
        ],
        'manager' => [
            'id' => 3,
            'name' => 'Manager',
            'description' => 'Department manager',
            'permissions' => [
                'employees.view', 'employees.manage_own',
                'tasks.manage', 'reports.view',
                'crm.view', 'crm.manage_own'
            ]
        ],
        'sales' => [
            'id' => 4,
            'name' => 'Sales',
            'description' => 'Sales representative',
            'permissions' => [
                'leads.manage', 'customers.view', 'deals.manage',
                'tasks.manage_own', 'reports.view_own'
            ]
        ],
        'hr' => [
            'id' => 5,
            'name' => 'HR',
            'description' => 'Human Resources',
            'permissions' => [
                'employees.manage', 'attendance.manage', 'payroll.manage',
                'leave.manage', 'reports.view'
            ]
        ],
        'accountant' => [
            'id' => 6,
            'name' => 'Accountant',
            'description' => 'Finance & Accounting',
            'permissions' => [
                'invoices.manage', 'expenses.manage', 'payments.manage',
                'vendors.manage', 'reports.view', 'finance.*'
            ]
        ],
        'employee' => [
            'id' => 7,
            'name' => 'Employee',
            'description' => 'Regular employee',
            'permissions' => [
                'tasks.view_own', 'attendance.self', 'profile.edit_own',
                'leave.request'
            ]
        ]
    ],
    
    'permissions' => [
        // User Management
        'users.view' => 'View users',
        'users.create' => 'Create user',
        'users.edit' => 'Edit user',
        'users.delete' => 'Delete user',
        'users.manage' => 'Manage users',
        
        // Roles & Permissions
        'roles.view' => 'View roles',
        'roles.create' => 'Create role',
        'roles.edit' => 'Edit role',
        'roles.delete' => 'Delete role',
        'roles.manage' => 'Manage roles',
        
        // Settings
        'settings.view' => 'View settings',
        'settings.manage' => 'Manage settings',
        
        // CRM
        'crm.view' => 'View CRM',
        'crm.manage' => 'Manage CRM',
        'leads.view' => 'View leads',
        'leads.create' => 'Create lead',
        'leads.manage' => 'Manage leads',
        'customers.view' => 'View customers',
        'customers.create' => 'Create customer',
        'customers.manage' => 'Manage customers',
        'deals.view' => 'View deals',
        'deals.manage' => 'Manage deals',
        'tasks.view' => 'View tasks',
        'tasks.create' => 'Create task',
        'tasks.manage' => 'Manage tasks',
        'tasks.manage_own' => 'Manage own tasks',
        'tasks.view_own' => 'View own tasks',
        
        // ERP
        'erp.view' => 'View ERP',
        'erp.manage' => 'Manage ERP',
        'employees.view' => 'View employees',
        'employees.create' => 'Create employee',
        'employees.manage' => 'Manage employees',
        'employees.manage_own' => 'Manage own employee data',
        'attendance.view' => 'View attendance',
        'attendance.manage' => 'Manage attendance',
        'attendance.self' => 'Mark own attendance',
        'payroll.view' => 'View payroll',
        'payroll.manage' => 'Manage payroll',
        'leave.view' => 'View leaves',
        'leave.manage' => 'Manage leaves',
        'leave.request' => 'Request leave',
        'products.view' => 'View products',
        'products.manage' => 'Manage products',
        'inventory.view' => 'View inventory',
        'inventory.manage' => 'Manage inventory',
        'vendors.view' => 'View vendors',
        'vendors.manage' => 'Manage vendors',
        'purchase_orders.view' => 'View PO',
        'purchase_orders.manage' => 'Manage PO',
        
        // Finance
        'invoices.view' => 'View invoices',
        'invoices.create' => 'Create invoice',
        'invoices.manage' => 'Manage invoices',
        'expenses.view' => 'View expenses',
        'expenses.manage' => 'Manage expenses',
        'payments.view' => 'View payments',
        'payments.manage' => 'Manage payments',
        'finance.view' => 'View finance',
        'finance.manage' => 'Manage finance',
        
        // Reports
        'reports.view' => 'View reports',
        'reports.view_own' => 'View own reports',
        'reports.export' => 'Export reports',
        
        // Profile
        'profile.view' => 'View profile',
        'profile.edit_own' => 'Edit own profile',
    ]
];
