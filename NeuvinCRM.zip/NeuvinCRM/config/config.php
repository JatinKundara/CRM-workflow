<?php
/**
 * Application Configuration
 */

define('APP_NAME', 'NeuvinCRM');

/*
|--------------------------------------------------------------------------
| APP URL  (VERY IMPORTANT)
|--------------------------------------------------------------------------
| This must be your project root URL (without /public)
*/
define('APP_URL', 'http://localhost/NeuvinCRM');


/*
|--------------------------------------------------------------------------
| Database Configuration
|--------------------------------------------------------------------------
*/
define('DB_HOST', 'localhost');
define('DB_NAME', 'neuvincrm');   // change if your DB name different
define('DB_USER', 'root');
define('DB_PASS', '');            // default XAMPP password is empty


/*
|--------------------------------------------------------------------------
| Error Reporting
|--------------------------------------------------------------------------
*/
error_reporting(E_ALL);
ini_set('display_errors', 1);