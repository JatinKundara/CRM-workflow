<h1><?php echo $title ?? 'Profile'; ?></h1>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <h5>Personal Information</h5>
            <form method="POST" action="<?php echo url('profile'); ?>">
                <?php echo csrfField(); ?>
                
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo sanitize($user['name'] ?? ''); ?>">
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo sanitize($user['email'] ?? ''); ?>">
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Phone</label>
                    <input type="tel" class="form-control" name="phone" value="<?php echo sanitize($user['phone'] ?? ''); ?>">
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Avatar URL</label>
                    <input type="text" class="form-control" name="avatar" value="<?php echo sanitize($user['avatar'] ?? ''); ?>">
                </div>
                
                <button type="submit" class="btn btn-primary">Update Profile</button>
            </form>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card" style="text-align: center;">
            <h5>Account</h5>
            <p style="margin: 10px 0;"><strong><?php echo sanitize($user['name'] ?? 'User'); ?></strong></p>
            <p style="margin: 10px 0; color: #666;"><?php echo sanitize($user['email'] ?? ''); ?></p>
            <p style="margin: 10px 0;"><span class="status-badge status-active">Active</span></p>
            
            <hr>
            
            <p style="margin: 10px 0; font-size: 12px; color: #999;">
                Member since <?php echo formatDate($user['created_at'] ?? ''); ?>
            </p>
        </div>
    </div>
</div>
