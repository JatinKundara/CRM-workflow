<?php
/**
 * Invoices List View
 */
$title = 'Invoices';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?> - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><?php echo $title; ?></h2>
            <button class="btn btn-primary" onclick="showAddModal()">+ New Invoice</button>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="table table-hover table-sm mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Invoice #</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Due Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($invoices as $invoice): ?>
                            <tr>
                                <td><strong>INV-<?php echo str_pad($invoice['id'], 5, '0', STR_PAD_LEFT); ?></strong></td>
                                <td><?php echo sanitize($invoice['customer_name']); ?></td>
                                <td><?php echo formatCurrency($invoice['total']); ?></td>
                                <td>
                                    <span class="badge <?php echo $invoice['status'] === 'paid' ? 'bg-success' : 'bg-warning'; ?>">
                                        <?php echo ucfirst($invoice['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo formatDate($invoice['due_date']); ?></td>
                                <td>
                                    <a href="/finance/invoices/<?php echo $invoice['id']; ?>" class="btn btn-sm btn-info">View</a>
                                    <a href="/finance/invoices/<?php echo $invoice['id']; ?>/pdf" class="btn btn-sm btn-secondary">PDF</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
