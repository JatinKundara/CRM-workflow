<h1><?php echo $title ?? 'Expenses'; ?></h1>

<button class="btn btn-primary mb-3">+ Add Expense</button>

<div class="card">
    <div style="overflow-x: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Category</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($expenses) && is_array($expenses)): ?>
                    <?php foreach ($expenses as $expense): ?>
                        <tr>
                            <td><?php echo sanitize($expense['description'] ?? ''); ?></td>
                            <td><?php echo sanitize($expense['category'] ?? ''); ?></td>
                            <td><?php echo formatCurrency($expense['amount'] ?? 0); ?></td>
                            <td><?php echo formatDate($expense['date'] ?? ''); ?></td>
                            <td><span class="badge bg-warning">Pending</span></td>
                            <td>
                                <a href="#" class="btn btn-sm btn-outline-primary">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: #999;">No expenses found. <a href="<?php echo url('finance/expenses'); ?>">Add one now</a></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
