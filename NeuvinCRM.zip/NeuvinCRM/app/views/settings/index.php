<h1><?php echo $title ?? 'Settings'; ?></h1>

<div class="card">
    <h5>Application Settings</h5>
    <form method="POST" action="<?php echo url('settings'); ?>">
        <?php echo csrfField(); ?>
        
        <div class="mb-3">
            <label class="form-label">Application Name</label>
            <input type="text" class="form-control" name="app_name" value="<?php echo APP_NAME; ?>">
        </div>
        
        <div class="mb-3">
            <label class="form-label">Company Email</label>
            <input type="email" class="form-control" name="company_email" value="">
        </div>
        
        <div class="mb-3">
            <label class="form-label">Support Phone</label>
            <input type="tel" class="form-control" name="support_phone" value="">
        </div>
        
        <div class="mb-3">
            <label class="form-label">Currency</label>
            <select class="form-select" name="currency">
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="INR">INR (₹)</option>
            </select>
        </div>
        
        <div class="mb-3">
            <label class="form-label">Time Zone</label>
            <select class="form-select" name="timezone">
                <option value="UTC">UTC</option>
                <option value="Asia/Kolkata">Asia/Kolkata (IST)</option>
                <option value="America/New_York">America/New_York (EST)</option>
                <option value="Europe/London">Europe/London (GMT)</option>
            </select>
        </div>
        
        <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
</div>
