<h1><?php echo $title ?? 'Deals'; ?></h1>

<button class="btn btn-primary mb-3">+ Add Deal</button>

<div class="card">
    <div style="overflow-x: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Stage</th>
                    <th>Probability</th>
                    <th>Close Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($deals) && is_array($deals)): ?>
                    <?php foreach ($deals as $deal): ?>
                        <tr>
                            <td><?php echo sanitize($deal['title'] ?? ''); ?></td>
                            <td><?php echo sanitize($deal['customer_id'] ?? ''); ?></td>
                            <td><?php echo formatCurrency($deal['amount'] ?? 0); ?></td>
                            <td><span class="badge bg-primary"><?php echo sanitize($deal['stage'] ?? 'prospect'); ?></span></td>
                            <td><?php echo $deal['probability'] ?? 0; ?>%</td>
                            <td><?php echo formatDate($deal['expected_close_date'] ?? ''); ?></td>
                            <td>
                                <a href="<?php echo url('crm/deals/' . $deal['id']); ?>" class="btn btn-sm btn-outline-primary">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: #999;">No deals found. <a href="<?php echo url('crm/deals'); ?>">Add one now</a></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
