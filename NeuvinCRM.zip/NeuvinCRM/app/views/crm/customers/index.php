<h1><?php echo $title ?? 'Customers'; ?></h1>

<button class="btn btn-primary mb-3">+ Add Customer</button>

<div class="card">
    <div style="overflow-x: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($customers) && is_array($customers)): ?>
                    <?php foreach ($customers as $customer): ?>
                        <tr>
                            <td><?php echo sanitize($customer['first_name'] ?? '') . ' ' . sanitize($customer['last_name'] ?? ''); ?></td>
                            <td><?php echo sanitize($customer['email'] ?? ''); ?></td>
                            <td><?php echo sanitize($customer['company'] ?? ''); ?></td>
                            <td><?php echo sanitize($customer['phone'] ?? ''); ?></td>
                            <td><span class="status-badge status-active">Active</span></td>
                            <td>
                                <a href="<?php echo url('crm/customers/' . $customer['id']); ?>" class="btn btn-sm btn-outline-primary">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: #999;">No customers found. <a href="<?php echo url('crm/customers'); ?>">Add one now</a></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
