<h1><?php echo $title ?? 'Leads'; ?></h1>

<button class="btn btn-primary mb-3">+ Add Lead</button>

<div class="card">
    <div style="overflow-x: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Value</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($recent_leads) && is_array($recent_leads)): ?>
                    <?php foreach ($recent_leads as $lead): ?>
                        <tr>
                            <td><?php echo sanitize($lead['first_name'] ?? '') . ' ' . sanitize($lead['last_name'] ?? ''); ?></td>
                            <td><?php echo sanitize($lead['email'] ?? ''); ?></td>
                            <td><?php echo sanitize($lead['company'] ?? ''); ?></td>
                            <td><?php echo sanitize($lead['phone'] ?? ''); ?></td>
                            <td><span class="badge bg-warning"><?php echo sanitize($lead['status'] ?? 'new'); ?></span></td>
                            <td><?php echo formatCurrency($lead['estimated_value'] ?? 0); ?></td>
                            <td>
                                <a href="<?php echo url('crm/leads/' . $lead['id']); ?>" class="btn btn-sm btn-outline-primary">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: #999;">No leads found. <a href="<?php echo url('crm/leads'); ?>">Add one now</a></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
                                    <button class="btn btn-sm btn-danger" onclick="deleteLead(<?php echo $lead['id']; ?>)">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Lead Modal -->
    <div class="modal fade" id="addModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Lead</h5>
                    <button type="button" class="btn-close" onclick="document.getElementById('addModal').style.display='none'"></button>
                </div>
                <form onsubmit="return addLead(event)">
                    <div class="modal-body">
                        <?php echo \App\Core\CSRF::field(); ?>
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Company</label>
                            <input type="text" name="company" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Source</label>
                            <select name="source" class="form-control">
                                <option>Website</option>
                                <option>Referral</option>
                                <option>Email</option>
                                <option>Call</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('addModal').style.display='none'">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Lead</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showAddModal() {
            const modal = document.getElementById('addModal');
            if (!modal) {
                console.error('Modal not found');
                return;
            }
            modal.style.display = 'block';
        }

        function addLead(e) {
            e.preventDefault();
            const form = e.target;
            const data = new FormData(form);

            fetch('/crm/leads', {
                method: 'POST',
                body: data
            })
            .then(r => r.json())
            .then(json => {
                if (json.success) {
                    window.location.reload();
                } else {
                    alert('Error: ' + (json.message || 'Failed to add lead'));
                }
            })
            .catch(err => alert('Error: ' + err.message));

            return false;
        }

        function deleteLead(id) {
            if (confirm('Are you sure you want to delete this lead?')) {
                fetch('/crm/leads/' + id, { method: 'DELETE' })
                    .then(r => r.json())
                    .then(json => {
                        if (json.success) {
                            window.location.reload();
                        }
                    });
            }
        }
    </script>
</body>
</html>
