<h1><?php echo $title ?? 'Tasks'; ?></h1>

<button class="btn btn-primary mb-3">+ Add Task</button>

<div class="card">
    <div style="overflow-x: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Related To</th>
                    <th>Due Date</th>
                    <th>Priority</th>
                    <th>Status</th>
                    <th>Assigned To</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($tasks) && is_array($tasks)): ?>
                    <?php foreach ($tasks as $task): ?>
                        <tr>
                            <td><?php echo sanitize($task['title'] ?? ''); ?></td>
                            <td><?php echo sanitize($task['related_to'] ?? ''); ?></td>
                            <td><?php echo formatDate($task['due_date'] ?? ''); ?></td>
                            <td><span class="badge bg-warning">Normal</span></td>
                            <td><span class="badge bg-info"><?php echo sanitize($task['status'] ?? 'pending'); ?></span></td>
                            <td><?php echo sanitize($task['assigned_to'] ?? ''); ?></td>
                            <td>
                                <a href="#" class="btn btn-sm btn-outline-primary">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: #999;">No tasks found. <a href="<?php echo url('crm/tasks'); ?>">Add one now</a></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
