<?php
/**
 * Login View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Login'; ?> - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; }
        .login-container { background: white; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); }
        .login-form { padding: 40px; min-width: 400px; }
        h1 { color: #333; margin-bottom: 30px; text-align: center; font-weight: 700; }
        .form-control { border-radius: 5px; padding: 12px 15px; border: 1px solid #ddd; margin-bottom: 15px; }
        .form-control:focus { border-color: #667eea; box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25); }
        .btn-login { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; padding: 12px; border-radius: 5px; margin-top: 10px; }
        .btn-login:hover { background: linear-gradient(135deg, #764ba2 0%, #667eea 100%); }
        .link { color: #667eea; text-decoration: none; }
        .link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-form">
            <h1><?php echo APP_NAME; ?></h1>

            <form method="POST" action="<?php echo url('login'); ?>">
                <?php echo \App\Core\CSRF::field(); ?>

                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" class="form-control" name="email" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" required>
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="remember" name="remember">
                    <label class="form-check-label" for="remember">Remember me</label>
                </div>

                <button type="submit" class="btn btn-primary btn-login w-100">Sign In</button>
            </form>

            <hr>

            <p style="text-align: center; margin-top: 20px;">
                Don't have an account? <a href="<?php echo url('register'); ?>" class="link">Register here</a>
            </p>

            <p style="text-align: center;">
                <a href="<?php echo url('forgot-password'); ?>" class="link">Forgot password?</a>
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
