<?php
/**
 * Register View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Register'; ?> - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; }
        .register-container { background: white; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); }
        .register-form { padding: 40px; min-width: 400px; }
        h1 { color: #333; margin-bottom: 30px; text-align: center; font-weight: 700; }
        .form-control { border-radius: 5px; padding: 12px 15px; border: 1px solid #ddd; margin-bottom: 15px; }
        .form-control:focus { border-color: #667eea; box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25); }
        .btn-register { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; padding: 12px; border-radius: 5px; margin-top: 10px; }
        .btn-register:hover { background: linear-gradient(135deg, #764ba2 0%, #667eea 100%); }
        .link { color: #667eea; text-decoration: none; }
        .link:hover { text-decoration: underline; }
        .error-message { color: #dc3545; display: none; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-form">
            <h1><?php echo APP_NAME; ?></h1>
            <h5 style="text-align: center; color: #666; margin-bottom: 30px;">Create Account</h5>

            <div id="errorMessage" class="alert alert-danger error-message" role="alert"></div>

            <form id="registerForm" method="POST" action="<?php echo url('register'); ?>">
                <?php echo \App\Core\CSRF::field(); ?>

                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" class="form-control" name="name" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" class="form-control" name="email" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" id="password" required minlength="8">
                    <small class="form-text text-muted">Minimum 8 characters</small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" name="password_confirmation" id="passwordConfirm" required minlength="8">
                </div>

                <button type="submit" class="btn btn-primary btn-register w-100">Create Account</button>
            </form>

            <hr>

            <p style="text-align: center; margin-bottom: 0;">
                Already have an account? <a href="<?php echo url('login'); ?>" class="link">Login here</a>
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirm = document.getElementById('passwordConfirm').value;
            
            if (password !== confirm) {
                e.preventDefault();
                const errorDiv = document.getElementById('errorMessage');
                errorDiv.textContent = 'Passwords do not match!';
                errorDiv.style.display = 'block';
            }
        });
    </script>
</body>
</html>
