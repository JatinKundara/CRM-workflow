<?php
/**
 * Forgot Password View
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Forgot Password'; ?> - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; }
        .forgot-container { background: white; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); }
        .forgot-form { padding: 40px; min-width: 400px; }
        h1 { color: #333; margin-bottom: 10px; text-align: center; font-weight: 700; }
        .subtitle { text-align: center; color: #666; margin-bottom: 30px; font-size: 14px; }
        .form-control { border-radius: 5px; padding: 12px 15px; border: 1px solid #ddd; margin-bottom: 15px; }
        .form-control:focus { border-color: #667eea; box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25); }
        .btn-submit { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; padding: 12px; border-radius: 5px; margin-top: 10px; }
        .btn-submit:hover { background: linear-gradient(135deg, #764ba2 0%, #667eea 100%); }
        .link { color: #667eea; text-decoration: none; }
        .link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="forgot-container">
        <div class="forgot-form">
            <h1><?php echo APP_NAME; ?></h1>
            <p class="subtitle">Enter your email to reset your password</p>

            <form method="POST" action="<?php echo url('forgot-password'); ?>">
                <?php echo \App\Core\CSRF::field(); ?>

                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" class="form-control" name="email" required>
                </div>

                <button type="submit" class="btn btn-primary btn-submit w-100">Send Reset Link</button>
            </form>

            <hr>

            <p style="text-align: center; margin-bottom: 0;">
                <a href="<?php echo url('login'); ?>" class="link">← Back to Login</a>
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
