<h1><?php echo $title ?? 'Payroll'; ?></h1>

<button class="btn btn-primary mb-3">+ Generate Payroll</button>

<div class="card">
    <div style="overflow-x: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Employee</th>
                    <th>Month</th>
                    <th>Base Salary</th>
                    <th>Deductions</th>
                    <th>Net Salary</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($payroll) && is_array($payroll)): ?>
                    <?php foreach ($payroll as $record): ?>
                        <tr>
                            <td><?php echo sanitize($record['employee_id'] ?? ''); ?></td>
                            <td><?php echo sanitize($record['month'] ?? ''); ?></td>
                            <td><?php echo formatCurrency($record['base_salary'] ?? 0); ?></td>
                            <td><?php echo formatCurrency($record['deductions'] ?? 0); ?></td>
                            <td><?php echo formatCurrency($record['net_salary'] ?? 0); ?></td>
                            <td><span class="badge bg-success"><?php echo sanitize($record['status'] ?? 'pending'); ?></span></td>
                            <td>
                                <a href="#" class="btn btn-sm btn-outline-primary">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: #999;">No payroll records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
