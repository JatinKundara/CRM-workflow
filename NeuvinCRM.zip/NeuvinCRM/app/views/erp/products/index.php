<?php
/**
 * Products List View
 */
$title = 'Products';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?> - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><?php echo $title; ?></h2>
            <button class="btn btn-primary" onclick="showAddModal()">+ New Product</button>
        </div>

        <!-- Low Stock Alert -->
        <?php if ($low_stock_count > 0): ?>
            <div class="alert alert-warning">
                <strong>⚠️ Low Stock Alert:</strong> <?php echo $low_stock_count; ?> products are below reorder level.
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="table-responsive">
                <table class="table table-hover table-sm mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Product Name</th>
                            <th>SKU</th>
                            <th>Category</th>
                            <th>Unit Price</th>
                            <th>Current Stock</th>
                            <th>Reorder Level</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><strong><?php echo sanitize($product['name']); ?></strong></td>
                                <td><?php echo sanitize($product['sku']); ?></td>
                                <td><?php echo sanitize($product['category']); ?></td>
                                <td><?php echo formatCurrency($product['unit_price']); ?></td>
                                <td><?php echo $product['current_stock']; ?> Units</td>
                                <td><?php echo $product['reorder_level']; ?> Units</td>
                                <td>
                                    <?php if ($product['current_stock'] <= $product['reorder_level']): ?>
                                        <span class="badge bg-danger">Low Stock</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">In Stock</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="/erp/products/<?php echo $product['id']; ?>" class="btn btn-sm btn-info">View</a>
                                    <button class="btn btn-sm btn-danger" onclick="deleteProduct(<?php echo $product['id']; ?>)">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function deleteProduct(id) {
            if (confirm('Are you sure?')) {
                fetch('/erp/products/' + id, { method: 'DELETE' })
                    .then(r => r.json())
                    .then(json => {
                        if (json.success) {
                            window.location.reload();
                        }
                    });
            }
        }
    </script>
</body>
</html>
