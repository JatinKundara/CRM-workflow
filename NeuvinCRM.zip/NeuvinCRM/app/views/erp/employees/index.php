<h1><?php echo $title ?? 'Employees'; ?></h1>

<button class="btn btn-primary mb-3">+ Add Employee</button>

<div class="card">
    <div style="overflow-x: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Position</th>
                    <th>Join Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($employees) && is_array($employees)): ?>
                    <?php foreach ($employees as $employee): ?>
                        <tr>
                            <td><?php echo sanitize($employee['employee_id'] ?? ''); ?></td>
                            <td><?php echo sanitize($employee['first_name'] ?? '') . ' ' . sanitize($employee['last_name'] ?? ''); ?></td>
                            <td><?php echo sanitize($employee['email'] ?? ''); ?></td>
                            <td><?php echo sanitize($employee['department'] ?? ''); ?></td>
                            <td><?php echo sanitize($employee['position'] ?? ''); ?></td>
                            <td><?php echo formatDate($employee['date_of_joining'] ?? ''); ?></td>
                            <td><span class="status-badge status-active">Active</span></td>
                            <td>
                                <a href="<?php echo url('erp/employees/' . $employee['id']); ?>" class="btn btn-sm btn-outline-primary">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px; color: #999;">No employees found. <a href="<?php echo url('erp/employees'); ?>">Add one now</a></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
