<h1><?php echo $title ?? 'Purchase Orders'; ?></h1>

<button class="btn btn-primary mb-3">+ Create PO</button>

<div class="card">
    <div style="overflow-x: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>PO Number</th>
                    <th>Vendor</th>
                    <th>Order Date</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($purchase_orders) && is_array($purchase_orders)): ?>
                    <?php foreach ($purchase_orders as $po): ?>
                        <tr>
                            <td><?php echo sanitize($po['po_number'] ?? ''); ?></td>
                            <td><?php echo sanitize($po['vendor_id'] ?? ''); ?></td>
                            <td><?php echo formatDate($po['order_date'] ?? ''); ?></td>
                            <td><?php echo formatCurrency($po['total_amount'] ?? 0); ?></td>
                            <td><span class="badge bg-primary"><?php echo sanitize($po['status'] ?? 'draft'); ?></span></td>
                            <td>
                                <a href="#" class="btn btn-sm btn-outline-primary">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: #999;">No purchase orders found. <a href="<?php echo url('erp/purchase-orders'); ?>">Create one now</a></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
