<h1><?php echo $title ?? 'Attendance'; ?></h1>

<button class="btn btn-primary mb-3">+ Mark Attendance</button>

<div class="card">
    <div style="overflow-x: auto;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Employee</th>
                    <th>Date</th>
                    <th>Check In</th>
                    <th>Check Out</th>
                    <th>Status</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php if (isset($attendance) && is_array($attendance)): ?>
                    <?php foreach ($attendance as $record): ?>
                        <tr>
                            <td><?php echo sanitize($record['employee_id'] ?? ''); ?></td>
                            <td><?php echo formatDate($record['date'] ?? ''); ?></td>
                            <td><?php echo sanitize($record['check_in'] ?? '-'); ?></td>
                            <td><?php echo sanitize($record['check_out'] ?? '-'); ?></td>
                            <td><span class="badge bg-success"><?php echo sanitize($record['status'] ?? 'present'); ?></span></td>
                            <td><?php echo sanitize($record['notes'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: #999;">No attendance records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
