<?php
/**
 * Dashboard View (SAFE VERSION)
 */

/* ---------- SAFE FALLBACKS ---------- */
if (!function_exists('url')) {
    function url($path = '') {
        return '/neuvincrm/public/' . ltrim($path, '/');
    }
}

if (!function_exists('sanitize')) {
    function sanitize($str) {
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('formatDate')) {
    function formatDate($date) {
        return date('M j, Y', strtotime($date));
    }
}

/* Prevent undefined variable warnings */
$stats = $stats ?? [
    'total_leads' => 0,
    'open_deals' => 0,
    'pending_invoices' => 0,
    'low_stock_products' => 0
];

$user = $user ?? ['name' => 'User'];
$upcoming_tasks = $upcoming_tasks ?? [];
$sales_pipeline = $sales_pipeline ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - <?php echo APP_NAME ?? 'NeuvinCRM'; ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.0/dist/chart.min.js"></script>

<style>
body { background:#f4f6f9; }
.sidebar { background:#1f2937; color:white; min-height:100vh; padding:20px; }
.card { border:none; box-shadow:0 2px 8px rgba(0,0,0,.1); margin-bottom:20px; }
.stat-card { padding:20px; text-align:center; }
.stat-value { font-size:28px; font-weight:bold; }
</style>
</head>

<body>
<div class="container-fluid">
<div class="row">

<!-- Sidebar -->
<div class="col-md-3 sidebar">
    <h3><?php echo APP_NAME ?? 'NeuvinCRM'; ?></h3>
    <a href="<?= url('dashboard') ?>" class="text-white d-block p-2">Dashboard</a>
    <a href="<?= url('crm/leads') ?>" class="text-white d-block p-2">CRM</a>
    <a href="<?= url('erp/employees') ?>" class="text-white d-block p-2">ERP</a>
    <a href="<?= url('finance/invoices') ?>" class="text-white d-block p-2">Finance</a>
</div>

<!-- Main -->
<div class="col-md-9 p-4">

<h4>Welcome, <?php echo sanitize($user['name']); ?> 👋</h4>
<p class="text-muted"><?php echo date('F j, Y'); ?></p>

<!-- Stats -->
<div class="row">
<?php foreach ($stats as $label => $value): ?>
<div class="col-md-3">
    <div class="card stat-card">
        <div class="stat-value"><?= (int)$value ?></div>
        <div><?= ucwords(str_replace('_',' ',$label)) ?></div>
    </div>
</div>
<?php endforeach; ?>
</div>

<!-- Chart -->
<div class="card p-3">
<h5>Sales Pipeline</h5>
<canvas id="pipelineChart"></canvas>
</div>

<!-- Tasks -->
<div class="card p-3">
<h5>Upcoming Tasks</h5>
<?php if(empty($upcoming_tasks)): ?>
    <p class="text-muted">No upcoming tasks</p>
<?php else: ?>
    <ul>
        <?php foreach(array_slice($upcoming_tasks,0,5) as $task): ?>
            <li>
                <strong><?= sanitize($task['title']) ?></strong>
                - <?= formatDate($task['due_date']) ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>
</div>

</div>
</div>
</div>

<script>
const labels = <?= json_encode(array_keys($sales_pipeline)) ?>;
const dataVals = <?= json_encode(array_column($sales_pipeline,'total')) ?>;

if(labels.length){
    new Chart(document.getElementById('pipelineChart'), {
        type:'bar',
        data:{ labels:labels, datasets:[{ label:'Deal Value', data:dataVals }]},
        options:{ responsive:true }
    });
}
</script>

</body>
</html>