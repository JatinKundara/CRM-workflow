<?php
/**
 * Main Layout Template
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($title) ? sanitize($title) . ' - ' : ''; ?><?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: #f4f6f9;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .sidebar {
            background: #1f2937;
            color: white;
            min-height: 100vh;
            width: 250px;
            padding: 20px;
            position: fixed;
            left: 0;
            top: 0;
        }
        .sidebar h2 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 30px;
        }
        .sidebar nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar nav ul li {
            margin: 5px 0;
        }
        .sidebar nav ul li a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 12px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .sidebar nav ul li a:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        .sidebar nav ul li a.active {
            background: #3b82f6;
        }
        .main-content {
            margin-left: 250px;
            flex: 1;
            padding: 0;
        }
        .navbar-top {
            background: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e0e0e0;
        }
        .content-area {
            padding: 30px;
        }
        .card {
            border: none;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            padding: 20px;
        }
        .btn-primary {
            background: #3b82f6;
            border: none;
        }
        .btn-primary:hover {
            background: #2563eb;
        }
        h1 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 20px;
        }
        h2 {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-active {
            background: #d1fae5;
            color: #065f46;
        }
        .status-inactive {
            background: #fee2e2;
            color: #7f1d1d;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2><?php echo APP_NAME; ?></h2>
        <nav>
            <ul>
                <li><a href="<?php echo url('dashboard'); ?>" class="<?php echo isActive('dashboard'); ?>">📊 Dashboard</a></li>
                
                <li style="margin-top: 20px; color: #999; font-size: 12px; font-weight: 600;">CRM</li>
                <li><a href="<?php echo url('crm/leads'); ?>" class="<?php echo isActive('leads'); ?>">👥 Leads</a></li>
                <li><a href="<?php echo url('crm/customers'); ?>" class="<?php echo isActive('customers'); ?>">🤝 Customers</a></li>
                <li><a href="<?php echo url('crm/deals'); ?>" class="<?php echo isActive('deals'); ?>">💼 Deals</a></li>
                <li><a href="<?php echo url('crm/tasks'); ?>" class="<?php echo isActive('tasks'); ?>">✅ Tasks</a></li>
                
                <li style="margin-top: 20px; color: #999; font-size: 12px; font-weight: 600;">ERP</li>
                <li><a href="<?php echo url('erp/employees'); ?>" class="<?php echo isActive('employees'); ?>">👨 Employees</a></li>
                <li><a href="<?php echo url('erp/attendance'); ?>" class="<?php echo isActive('attendance'); ?>">📋 Attendance</a></li>
                <li><a href="<?php echo url('erp/payroll'); ?>" class="<?php echo isActive('payroll'); ?>">💰 Payroll</a></li>
                <li><a href="<?php echo url('erp/products'); ?>" class="<?php echo isActive('products'); ?>">📦 Products</a></li>
                <li><a href="<?php echo url('erp/vendors'); ?>" class="<?php echo isActive('vendors'); ?>">🏢 Vendors</a></li>
                <li><a href="<?php echo url('erp/purchase-orders'); ?>" class="<?php echo isActive('purchase-orders'); ?>">📄 Purchase Orders</a></li>
                
                <li style="margin-top: 20px; color: #999; font-size: 12px; font-weight: 600;">FINANCE</li>
                <li><a href="<?php echo url('finance/invoices'); ?>" class="<?php echo isActive('invoices'); ?>">🧾 Invoices</a></li>
                <li><a href="<?php echo url('finance/expenses'); ?>" class="<?php echo isActive('expenses'); ?>">💸 Expenses</a></li>
                
                <li style="margin-top: 20px; color: #999; font-size: 12px; font-weight: 600;">ACCOUNT</li>
                <li><a href="<?php echo url('profile'); ?>" class="<?php echo isActive('profile'); ?>">⚙️ Profile</a></li>
                <li><a href="<?php echo url('settings'); ?>" class="<?php echo isActive('settings'); ?>">🔧 Settings</a></li>
                <li><a href="<?php echo url('logout'); ?>" class="">🚪 Logout</a></li>
            </ul>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <div class="navbar-top">
            <div>
                <span style="font-size: 18px; font-weight: 600;">
                    <?php echo isset($title) ? sanitize($title) : 'Dashboard'; ?>
                </span>
            </div>
            <div style="display: flex; align-items: center; gap: 20px;">
                <span style="color: #666;">
                    <?php echo isset($user['name']) ? 'Welcome, ' . sanitize($user['name']) : 'Welcome'; ?>
                </span>
                <span style="color: #999; font-size: 14px;">
                    <?php echo date('F j, Y'); ?>
                </span>
            </div>
        </div>

        <!-- Content Area -->
        <div class="content-area">
            <?php echo $content ?? ''; ?>
        </div>
    </div>

    <script>
        // Add active class to current menu item
        function setActiveMenu() {
            const path = window.location.pathname;
            document.querySelectorAll('.sidebar nav ul li a').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') && path.includes(link.getAttribute('href').replace('<?php echo base_url(); ?>', ''))) {
                    link.classList.add('active');
                }
            });
        }
        setActiveMenu();
    </script>
</body>
</html>
