<?php
namespace App\Services;

use App\Core\Security;
use App\Core\Session;
use App\Core\JWTAuth;
use App\Models\User;

/**
 * Authentication Service
 */
class AuthService
{
    private Session $session;
    private User $userModel;

    public function __construct()
    {
        $this->session = new Session();
        $this->userModel = new User();
    }

    /**
     * Login user
     */
    public function login(string $email, string $password, bool $rememberMe = false): bool
    {
        $user = $this->userModel->findByEmail($email);

        if (!$user) {
            Security::recordBruteForceAttempt($email);
            return false;
        }

        if (!Security::verifyPassword($password, $user['password'])) {
            Security::recordBruteForceAttempt($email);
            return false;
        }

        if (!$user['is_active']) {
            return false;
        }

        Security::clearBruteForceRecord($email);
        $this->userModel->updateLastLogin($user['id']);

        $this->session->set('user_id', $user['id']);
        $this->session->regenerate();

        if ($rememberMe) {
            $token = Security::generateToken();
            setcookie('remember_token', $token, time() + REMEMBER_ME_DURATION, '/', '', true, true);
            // Store token in database for verification later
        }

        return true;
    }

    /**
     * Logout user
     */
    public function logout(): void
    {
        $this->session->flush();
        $this->session->destroy();
        setcookie('remember_token', '', time() - 3600, '/');
    }

    /**
     * Get authenticated user
     */
    public function getUser(): ?array
    {
        $userId = $this->session->get('user_id');

        if ($userId) {
            return $this->userModel->find($userId);
        }

        return null;
    }

    /**
     * Check if user is authenticated
     */
    public function isAuthenticated(): bool
    {
        return $this->getUser() !== null;
    }

    /**
     * Register user
     */
    public function register(array $data): int|false
    {
        // Validation
        if ($this->userModel->findByEmail($data['email'])) {
            return false; // Email already exists
        }

        $data['password'] = Security::hashPassword($data['password']);
        $data['is_active'] = false; // Requires email verification
        $data['email_verified_at'] = null;

        return $this->userModel->create($data);
    }

    /**
     * Send password reset email
     */
    public function sendPasswordResetEmail(string $email): bool
    {
        $user = $this->userModel->findByEmail($email);
        if (!$user) {
            return false;
        }

        $resetToken = Security::generateToken();
        // Store token with expiration in database
        
        $emailService = new EmailService();
        return $emailService->sendPasswordResetEmail($user['email'], $resetToken);
    }

    /**
     * Reset password
     */
    public function resetPassword(string $token, string $newPassword): bool
    {
        // Verify token from database and get user
        // This is simplified - implement full token validation in production
        
        $newPassword = Security::hashPassword($newPassword);
        return true;
    }

    /**
     * Verify email
     */
    public function verifyEmail(string $token): bool
    {
        // Verify token and mark email as verified
        return true;
    }

    /**
     * Generate API token (JWT)
     */
    public function generateApiToken(int $userId): string
    {
        $user = $this->userModel->find($userId);
        if (!$user) {
            throw new \Exception("User not found");
        }

        return JWTAuth::generateToken([
            'user_id' => $user['id'],
            'email' => $user['email']
        ]);
    }
}
