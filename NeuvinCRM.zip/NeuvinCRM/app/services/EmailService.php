<?php
namespace App\Services;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Email Service
 */
class EmailService
{
    private PHPMailer $mailer;

    public function __construct()
    {
        $this->mailer = new PHPMailer(true);
        $this->configureMail();
    }

    /**
     * Configure mail settings
     */
    private function configureMail(): void
    {
        try {
            if (MAIL_DRIVER === 'smtp') {
                $this->mailer->isSMTP();
                $this->mailer->Host = MAIL_HOST;
                $this->mailer->SMTPAuth = true;
                $this->mailer->Username = MAIL_USERNAME;
                $this->mailer->Password = MAIL_PASSWORD;
                $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $this->mailer->Port = MAIL_PORT;
            }

            $this->mailer->setFrom(MAIL_FROM, MAIL_FROM_NAME);
            $this->mailer->CharSet = 'UTF-8';
        } catch (Exception $e) {
            // Log error
        }
    }

    /**
     * Send welcome email
     */
    public function sendWelcomeEmail(string $email, string $name): bool
    {
        try {
            $this->mailer->addAddress($email);
            $this->mailer->Subject = 'Welcome to ' . APP_NAME;

            $body = "
                <h1>Welcome to " . APP_NAME . "</h1>
                <p>Hi {$name},</p>
                <p>Thank you for joining us.</p>
            ";

            $this->mailer->isHTML(true);
            $this->mailer->Body = $body;

            return $this->mailer->send();
        } catch (Exception $e) {
            error_log("Email Error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send password reset email
     */
    public function sendPasswordResetEmail(string $email, string $resetToken): bool
    {
        try {
            $this->mailer->addAddress($email);
            $this->mailer->Subject = 'Password Reset Request';

            $resetLink = url("/reset-password?token={$resetToken}");
            $body = "
                <h1>Password Reset Request</h1>
                <p>Click the link below to reset your password:</p>
                <p><a href='{$resetLink}'>Reset Password</a></p>
                <p>This link expires in 1 hour.</p>
            ";

            $this->mailer->isHTML(true);
            $this->mailer->Body = $body;

            return $this->mailer->send();
        } catch (Exception $e) {
            error_log("Email Error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send invoice email
     */
    public function sendInvoiceEmail(string $email, string $invoiceNumber, string $invoicePdfPath): bool
    {
        try {
            $this->mailer->addAddress($email);
            $this->mailer->Subject = "Invoice {$invoiceNumber}";
            $this->mailer->addAttachment($invoicePdfPath);

            $body = "
                <h1>Invoice {$invoiceNumber}</h1>
                <p>Please find attached your invoice.</p>
            ";

            $this->mailer->isHTML(true);
            $this->mailer->Body = $body;

            return $this->mailer->send();
        } catch (Exception $e) {
            error_log("Email Error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send notification email
     */
    public function sendNotification(string $email, string $subject, string $message): bool
    {
        try {
            $this->mailer->addAddress($email);
            $this->mailer->Subject = $subject;

            $this->mailer->isHTML(true);
            $this->mailer->Body = $message;

            return $this->mailer->send();
        } catch (Exception $e) {
            error_log("Email Error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send email verification
     */
    public function sendEmailVerification(string $email, string $verificationToken): bool
    {
        try {
            $this->mailer->addAddress($email);
            $this->mailer->Subject = 'Verify Your Email Address';

            $verifyLink = url("/verify-email?token={$verificationToken}");
            $body = "
                <h1>Email Verification</h1>
                <p>Click the link below to verify your email:</p>
                <p><a href='{$verifyLink}'>Verify Email</a></p>
            ";

            $this->mailer->isHTML(true);
            $this->mailer->Body = $body;

            return $this->mailer->send();
        } catch (Exception $e) {
            error_log("Email Error: " . $e->getMessage());
            return false;
        }
    }
}
