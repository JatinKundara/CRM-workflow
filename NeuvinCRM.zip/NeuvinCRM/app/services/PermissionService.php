<?php
namespace App\Services;

use App\Core\Database;

/**
 * Permission & RBAC Service
 */
class PermissionService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Check if user has permission
     */
    public function hasPermission(int $userId, string $permission): bool
    {
        // Get user role
        $sql = "SELECT role_id FROM users WHERE id = ?";
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        if (!$user) {
            return false;
        }

        // Check for wildcard permission (super admin)
        $sql = "
            SELECT COUNT(*) as count FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            WHERE rp.role_id = ? AND p.name = '*'
        ";
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->execute([$user['role_id']]);
        
        if ((int) $stmt->fetch()['count'] > 0) {
            return true;
        }

        // Check specific permission
        $sql = "
            SELECT COUNT(*) as count FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            WHERE rp.role_id = ? AND p.name = ?
        ";
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->execute([$user['role_id'], $permission]);

        return (int) $stmt->fetch()['count'] > 0;
    }

    /**
     * Check if user has any of the given permissions
     */
    public function hasAnyPermission(int $userId, array $permissions): bool
    {
        foreach ($permissions as $permission) {
            if ($this->hasPermission($userId, $permission)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get user permissions
     */
    public function getUserPermissions(int $userId): array
    {
        $sql = "
            SELECT p.name FROM permissions p
            JOIN role_permissions rp ON p.id = rp.permission_id
            JOIN users u ON rp.role_id = u.role_id
            WHERE u.id = ?
        ";
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->execute([$userId]);
        return array_column($stmt->fetchAll(), 'name');
    }

    /**
     * Get role permissions
     */
    public function getRolePermissions(int $roleId): array
    {
        $sql = "
            SELECT p.* FROM permissions p
            JOIN role_permissions rp ON p.id = rp.permission_id
            WHERE rp.role_id = ?
        ";
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->execute([$roleId]);
        return $stmt->fetchAll();
    }

    /**
     * Assign permission to role
     */
    public function assignPermissionToRole(int $roleId, int $permissionId): bool
    {
        $sql = "INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)";
        $stmt = $this->db->getConnection()->prepare($sql);
        return $stmt->execute([$roleId, $permissionId]);
    }

    /**
     * Revoke permission from role
     */
    public function revokePermissionFromRole(int $roleId, int $permissionId): bool
    {
        $sql = "DELETE FROM role_permissions WHERE role_id = ? AND permission_id = ?";
        $stmt = $this->db->getConnection()->prepare($sql);
        return $stmt->execute([$roleId, $permissionId]);
    }
}
