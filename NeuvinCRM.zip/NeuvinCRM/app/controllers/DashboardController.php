<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Deal;
use App\Models\Lead;
use App\Models\Invoice;
use App\Models\Task;
use App\Models\Attendance;
use App\Models\Product;

/**
 * Dashboard Controller
 */
class DashboardController extends Controller
{
    /**
     * Show dashboard
     */
    public function index(Request $request, Response $response, array $params): void
    {
        $user = $this->getAuthUser();

        $deal = new Deal();
        $lead = new Lead();
        $invoice = new Invoice();
        $task = new Task();
        $attendance = new Attendance();
        $product = new Product();

        $dashboardData = [
            'title' => 'Dashboard',
            'user' => $user,
            'stats' => [
                'total_leads' => $lead->count(),
                'open_deals' => count($deal->getByStage('prospect')),
                'pending_invoices' => count(array_filter($invoice->all(), fn($i) => $i['status'] === 'pending')),
                'completed_tasks' => count(array_filter($task->all(), fn($t) => $t['status'] === 'completed')),
                'low_stock_products' => count($product->getLowStock())
            ],
            'recent_leads' => array_slice($lead->all(), 0, 5),
            'sales_pipeline' => $deal->getPipeline(),
            'upcoming_tasks' => $task->getUpcoming(7),
            'low_stock_products' => $product->getLowStock(),
            'recent_invoices' => array_slice($invoice->all(), 0, 10)
        ];

        $this->view('dashboard/index', $dashboardData);
    }
}
