<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;

/**
 * Settings Controller
 */
class SettingController extends Controller
{
    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('settings.manage');
        $this->view('settings/index', ['title' => 'Settings']);
    }

    public function update(Request $request, Response $response, array $params): void
    {
        $this->authorize('settings.manage');
        $this->json(['success' => true, 'message' => 'Settings updated']);
    }
}
