<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Customer;

/**
 * Customer Controller
 */
class CustomerController extends Controller
{
    private Customer $customerModel;

    public function __construct()
    {
        parent::__construct();
        $this->customerModel = new Customer();
    }

    /**
     * List customers
     */
    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('customers.view');

        $page = (int) $request->getQuery('page', 1);
        $perPage = ITEMS_PER_PAGE;
        $offset = ($page - 1) * $perPage;

        $customers = $this->customerModel->all($perPage, $offset);

        $this->view('crm/customers/index', [
            'title' => 'Customers',
            'customers' => $customers,
            'currentPage' => $page
        ]);
    }

    /**
     * Show customer details
     */
    public function show(Request $request, Response $response, array $params): void
    {
        $this->authorize('customers.view');

        $customer = $this->customerModel->find($params['id'] ?? 0);

        if (!$customer) {
            $response->setStatusCode(404);
            $this->json(['error' => 'Customer not found']);
        }

        $this->view('crm/customers/show', [
            'title' => 'Customer Details',
            'customer' => $customer
        ]);
    }

    /**
     * Create customer
     */
    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('customers.create');

        $user = $this->getAuthUser();

        $customerId = $this->customerModel->create([
            'first_name' => $request->getPost('first_name'),
            'last_name' => $request->getPost('last_name'),
            'email' => $request->getPost('email'),
            'phone' => $request->getPost('phone'),
            'company' => $request->getPost('company'),
            'created_by' => $user['id']
        ]);

        $this->json(['success' => true, 'message' => 'Customer created', 'id' => $customerId]);
    }

    /**
     * Update customer
     */
    public function update(Request $request, Response $response, array $params): void
    {
        $this->authorize('customers.manage');

        $customer = $this->customerModel->find($params['id'] ?? 0);

        if (!$customer) {
            $this->json(['error' => 'Customer not found'], 404);
        }

        $this->customerModel->update($customer['id'], $request->getPostAll());

        $this->json(['success' => true, 'message' => 'Customer updated']);
    }

    /**
     * Delete customer
     */
    public function delete(Request $request, Response $response, array $params): void
    {
        $this->authorize('customers.delete');

        $customer = $this->customerModel->find($params['id'] ?? 0);

        if (!$customer) {
            $this->json(['error' => 'Customer not found'], 404);
        }

        $this->customerModel->delete($customer['id']);

        $this->json(['success' => true, 'message' => 'Customer deleted']);
    }
}
