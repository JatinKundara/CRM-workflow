<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;

/**
 * Profile Controller
 */
class ProfileController extends Controller
{
    public function show(Request $request, Response $response, array $params): void
    {
        $user = $this->getAuthUser();
        $this->view('profile/show', ['title' => 'Profile', 'user' => $user]);
    }

    public function update(Request $request, Response $response, array $params): void
    {
        $this->json(['success' => true, 'message' => 'Profile updated']);
    }
}
