<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Invoice;

/**
 * Invoice Controller
 */
class InvoiceController extends Controller
{
    private Invoice $invoiceModel;

    public function __construct()
    {
        parent::__construct();
        $this->invoiceModel = new Invoice();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('invoices.view');
        $invoices = $this->invoiceModel->all();
        $this->view('finance/invoices/index', ['title' => 'Invoices', 'invoices' => $invoices]);
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $this->authorize('invoices.view');
        $invoice = $this->invoiceModel->find($params['id'] ?? 0);
        if (!$invoice) {
            $this->json(['error' => 'Invoice not found'], 404);
        }
        $this->view('finance/invoices/show', ['title' => 'Invoice Details', 'invoice' => $invoice]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('invoices.create');
        $invoiceId = $this->invoiceModel->create($request->getPostAll());
        $this->json(['success' => true, 'message' => 'Invoice created', 'id' => $invoiceId]);
    }

    public function generatePdf(Request $request, Response $response, array $params): void
    {
        $this->authorize('invoices.view');
        // PDF generation would go here using a library like TCPDF or FPDF
        $this->json(['message' => 'PDF generation not implemented']);
    }
}
