<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Employee;

/**
 * Employee Controller
 */
class EmployeeController extends Controller
{
    private Employee $employeeModel;

    public function __construct()
    {
        parent::__construct();
        $this->employeeModel = new Employee();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('employees.view');
        $employees = $this->employeeModel->all();
        $this->view('erp/employees/index', ['title' => 'Employees', 'employees' => $employees]);
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $this->authorize('employees.view');
        $employee = $this->employeeModel->find($params['id'] ?? 0);
        if (!$employee) {
            $this->json(['error' => 'Employee not found'], 404);
        }
        $this->view('erp/employees/show', ['title' => 'Employee Details', 'employee' => $employee]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('employees.create');
        $employeeId = $this->employeeModel->create($request->getPostAll());
        $this->json(['success' => true, 'message' => 'Employee created', 'id' => $employeeId]);
    }
}
