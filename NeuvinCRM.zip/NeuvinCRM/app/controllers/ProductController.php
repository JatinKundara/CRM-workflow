<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Product;

/**
 * Product Controller
 */
class ProductController extends Controller
{
    private Product $productModel;

    public function __construct()
    {
        parent::__construct();
        $this->productModel = new Product();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('products.view');
        $products = $this->productModel->all();
        $this->view('erp/products/index', ['title' => 'Products', 'products' => $products]);
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $this->authorize('products.view');
        $product = $this->productModel->find($params['id'] ?? 0);
        if (!$product) {
            $this->json(['error' => 'Product not found'], 404);
        }
        $this->view('erp/products/show', ['title' => 'Product Details', 'product' => $product]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('products.create');
        $productId = $this->productModel->create($request->getPostAll());
        $this->json(['success' => true, 'message' => 'Product created', 'id' => $productId]);
    }
}
