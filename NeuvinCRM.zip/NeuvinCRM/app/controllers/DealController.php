<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Deal;

/**
 * Deal Controller
 */
class DealController extends Controller
{
    private Deal $dealModel;

    public function __construct()
    {
        parent::__construct();
        $this->dealModel = new Deal();
    }

    /**
     * List deals
     */
    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('deals.view');

        $deals = $this->dealModel->all();

        $this->view('crm/deals/index', [
            'title' => 'Deals',
            'deals' => $deals
        ]);
    }

    /**
     * Show kanban board
     */
    public function kanban(Request $request, Response $response, array $params): void
    {
        $this->authorize('deals.view');

        $pipeline = $this->dealModel->getPipeline();

        $this->view('crm/deals/kanban', [
            'title' => 'Sales Pipeline',
            'pipeline' => $pipeline
        ]);
    }

    /**
     * Create deal
     */
    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('deals.manage');

        $user = $this->getAuthUser();

        $dealId = $this->dealModel->create([
            'title' => $request->getPost('title'),
            'description' => $request->getPost('description'),
            'customer_id' => $request->getPost('customer_id'),
            'amount' => $request->getPost('amount'),
            'stage' => $request->getPost('stage', 'prospect'),
            'probability' => $request->getPost('probability', 0),
            'expected_close_date' => $request->getPost('expected_close_date'),
            'created_by' => $user['id']
        ]);

        $this->json(['success' => true, 'message' => 'Deal created', 'id' => $dealId]);
    }

    /**
     * Update deal
     */
    public function update(Request $request, Response $response, array $params): void
    {
        $this->authorize('deals.manage');

        $deal = $this->dealModel->find($params['id'] ?? 0);

        if (!$deal) {
            $this->json(['error' => 'Deal not found'], 404);
        }

        $this->dealModel->update($deal['id'], [
            'title' => $request->getPost('title'),
            'description' => $request->getPost('description'),
            'amount' => $request->getPost('amount'),
            'stage' => $request->getPost('stage'),
            'probability' => $request->getPost('probability'),
            'expected_close_date' => $request->getPost('expected_close_date')
        ]);

        $this->json(['success' => true, 'message' => 'Deal updated']);
    }
}
