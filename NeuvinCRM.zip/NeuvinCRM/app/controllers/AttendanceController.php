<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Attendance;

/**
 * Attendance Controller
 */
class AttendanceController extends Controller
{
    private Attendance $attendanceModel;

    public function __construct()
    {
        parent::__construct();
        $this->attendanceModel = new Attendance();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('attendance.view');
        $month = $request->getQuery('month', date('Y-m'));
        $attendance = $this->attendanceModel->getByMonth(
            (int)$request->getQuery('employee_id', 1),
            $month
        );
        $this->view('erp/attendance/index', ['title' => 'Attendance', 'attendance' => $attendance]);
    }

    public function markAttendance(Request $request, Response $response, array $params): void
    {
        $this->authorize('attendance.manage');
        $employeeId = $request->getPost('employee_id');
        $date = $request->getPost('date');

        $this->attendanceModel->markPresent($employeeId, $date);
        $this->json(['success' => true, 'message' => 'Attendance marked']);
    }
}
