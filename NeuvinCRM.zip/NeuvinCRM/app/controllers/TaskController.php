<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Task;

/**
 * Task Controller
 */
class TaskController extends Controller
{
    private Task $taskModel;

    public function __construct()
    {
        parent::__construct();
        $this->taskModel = new Task();
    }

    /**
     * List tasks
     */
    public function index(Request $request, Response $response, array $params): void
    {
        $user = $this->getAuthUser();

        // Show all tasks if admin, otherwise show user's tasks
        if ($this->can('tasks.manage')) {
            $tasks = $this->taskModel->all();
        } else {
            $tasks = $this->taskModel->getByUser($user['id']);
        }

        $this->view('crm/tasks/index', [
            'title' => 'Tasks',
            'tasks' => $tasks,
            'csrfToken' => \App\Core\CSRF::generate()
        ]);
    }

    /**
     * Create task
     */
    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('tasks.create');

        $user = $this->getAuthUser();

        $taskId = $this->taskModel->create([
            'title' => $request->getPost('title'),
            'description' => $request->getPost('description'),
            'assigned_to' => $request->getPost('assigned_to'),
            'priority' => $request->getPost('priority', 'medium'),
            'due_date' => $request->getPost('due_date'),
            'created_by' => $user['id']
        ]);

        $this->json(['success' => true, 'message' => 'Task created', 'id' => $taskId]);
    }
}
