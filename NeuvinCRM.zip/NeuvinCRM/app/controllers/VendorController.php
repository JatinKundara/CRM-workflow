<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Vendor;

/**
 * Vendor Controller
 */
class VendorController extends Controller
{
    private Vendor $vendorModel;

    public function __construct()
    {
        parent::__construct();
        $this->vendorModel = new Vendor();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('vendors.view');
        $vendors = $this->vendorModel->all();
        $this->view('erp/vendors/index', ['title' => 'Vendors', 'vendors' => $vendors]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('vendors.create');
        $vendorId = $this->vendorModel->create($request->getPostAll());
        $this->json(['success' => true, 'message' => 'Vendor created', 'id' => $vendorId]);
    }
}
