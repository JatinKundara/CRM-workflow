<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\PurchaseOrder;

/**
 * PurchaseOrder Controller
 */
class PurchaseOrderController extends Controller
{
    private PurchaseOrder $poModel;

    public function __construct()
    {
        parent::__construct();
        $this->poModel = new PurchaseOrder();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('purchase_orders.view');
        $pos = $this->poModel->all();
        $this->view('erp/purchase-orders/index', ['title' => 'Purchase Orders', 'pos' => $pos]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('purchase_orders.create');
        $poId = $this->poModel->create($request->getPostAll());
        $this->json(['success' => true, 'message' => 'PO created', 'id' => $poId]);
    }
}
