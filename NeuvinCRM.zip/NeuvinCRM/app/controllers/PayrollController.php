<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;

/**
 * Payroll Controller
 */
class PayrollController extends Controller
{
    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('payroll.view');
        $this->view('erp/payroll/index', ['title' => 'Payroll']);
    }

    public function generate(Request $request, Response $response, array $params): void
    {
        $this->authorize('payroll.manage');
        $this->json(['success' => true, 'message' => 'Payroll generated']);
    }
}
