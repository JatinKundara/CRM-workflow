<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Expense;

/**
 * Expense Controller
 */
class ExpenseController extends Controller
{
    private Expense $expenseModel;

    public function __construct()
    {
        parent::__construct();
        $this->expenseModel = new Expense();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('expenses.view');
        $expenses = $this->expenseModel->all();
        $this->view('finance/expenses/index', ['title' => 'Expenses', 'expenses' => $expenses]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('expenses.create');
        $expenseId = $this->expenseModel->create($request->getPostAll());
        $this->json(['success' => true, 'message' => 'Expense created', 'id' => $expenseId]);
    }
}
