<?php
namespace App\Controllers\Api;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Deal;
use App\Models\Invoice;
use App\Models\Product;

/**
 * API Report Controller
 */
class ReportController extends Controller
{
    /**
     * Sales report
     */
    public function sales(Request $request, Response $response, array $params): void
    {
        $deal = new Deal();
        $pipeline = $deal->getPipeline();

        $salesData = [];
        foreach ($pipeline as $stage => $data) {
            $salesData[] = [
                'stage' => $stage,
                'deals' => $data['count'],
                'value' => $data['total']
            ];
        }

        $this->json(['data' => $salesData]);
    }

    /**
     * Revenue report
     */
    public function revenue(Request $request, Response $response, array $params): void
    {
        $invoice = new Invoice();
        $invoices = $invoice->all();

        $totalRevenue = array_sum(array_column($invoices, 'total'));
        $paidInvoices = count(array_filter($invoices, fn($i) => $i['status'] === 'paid'));

        $this->json([
            'data' => [
                'total_revenue' => $totalRevenue,
                'paid_invoices' => $paidInvoices,
                'pending_revenue' => array_sum(
                    array_column(array_filter($invoices, fn($i) => $i['status'] !== 'paid'), 'total')
                )
            ]
        ]);
    }

    /**
     * Inventory report
     */
    public function inventory(Request $request, Response $response, array $params): void
    {
        $product = new Product();
        $lowStockProducts = $product->getLowStock();

        $this->json([
            'data' => [
                'low_stock_count' => count($lowStockProducts),
                'low_stock_products' => $lowStockProducts
            ]
        ]);
    }
}
