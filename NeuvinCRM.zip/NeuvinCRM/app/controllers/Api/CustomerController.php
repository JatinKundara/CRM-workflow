<?php
namespace App\Controllers\Api;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Customer;

/**
 * API Customer Controller
 */
class CustomerController extends Controller
{
    private Customer $customerModel;

    public function __construct()
    {
        parent::__construct();
        $this->customerModel = new Customer();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $customers = $this->customerModel->all();
        $this->json(['data' => $customers]);
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $customer = $this->customerModel->find($params['id'] ?? 0);
        if (!$customer) {
            $this->json(['error' => 'Customer not found'], 404);
        }
        $this->json(['data' => $customer]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $customerId = $this->customerModel->create($request->getJson());
        $this->json(['success' => true, 'id' => $customerId], 201);
    }

    public function update(Request $request, Response $response, array $params): void
    {
        $customer = $this->customerModel->find($params['id'] ?? 0);
        if (!$customer) {
            $this->json(['error' => 'Customer not found'], 404);
        }
        $this->customerModel->update($customer['id'], $request->getJson());
        $this->json(['success' => true]);
    }

    public function delete(Request $request, Response $response, array $params): void
    {
        $customer = $this->customerModel->find($params['id'] ?? 0);
        if (!$customer) {
            $this->json(['error' => 'Customer not found'], 404);
        }
        $this->customerModel->delete($customer['id']);
        $this->json(['success' => true]);
    }
}
