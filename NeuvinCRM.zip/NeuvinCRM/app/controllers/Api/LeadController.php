<?php
namespace App\Controllers\Api;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Lead;

/**
 * API Lead Controller
 */
class LeadController extends Controller
{
    private Lead $leadModel;

    public function __construct()
    {
        parent::__construct();
        $this->leadModel = new Lead();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $leads = $this->leadModel->all();
        $this->json(['data' => $leads]);
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $lead = $this->leadModel->find($params['id'] ?? 0);
        if (!$lead) {
            $this->json(['error' => 'Lead not found'], 404);
        }
        $this->json(['data' => $lead]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $leadId = $this->leadModel->create($request->getJson());
        $this->json(['success' => true, 'id' => $leadId], 201);
    }

    public function update(Request $request, Response $response, array $params): void
    {
        $lead = $this->leadModel->find($params['id'] ?? 0);
        if (!$lead) {
            $this->json(['error' => 'Lead not found'], 404);
        }
        $this->leadModel->update($lead['id'], $request->getJson());
        $this->json(['success' => true]);
    }

    public function delete(Request $request, Response $response, array $params): void
    {
        $lead = $this->leadModel->find($params['id'] ?? 0);
        if (!$lead) {
            $this->json(['error' => 'Lead not found'], 404);
        }
        $this->leadModel->delete($lead['id']);
        $this->json(['success' => true]);
    }
}
