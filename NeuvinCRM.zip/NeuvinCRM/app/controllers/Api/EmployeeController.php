<?php
namespace App\Controllers\Api;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Employee;

/**
 * API Employee Controller
 */
class EmployeeController extends Controller
{
    private Employee $employeeModel;

    public function __construct()
    {
        parent::__construct();
        $this->employeeModel = new Employee();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $employees = $this->employeeModel->all();
        $this->json(['data' => $employees]);
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $employee = $this->employeeModel->find($params['id'] ?? 0);
        if (!$employee) {
            $this->json(['error' => 'Employee not found'], 404);
        }
        $this->json(['data' => $employee]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $employeeId = $this->employeeModel->create($request->getJson());
        $this->json(['success' => true, 'id' => $employeeId], 201);
    }

    public function update(Request $request, Response $response, array $params): void
    {
        $employee = $this->employeeModel->find($params['id'] ?? 0);
        if (!$employee) {
            $this->json(['error' => 'Employee not found'], 404);
        }
        $this->employeeModel->update($employee['id'], $request->getJson());
        $this->json(['success' => true]);
    }

    public function delete(Request $request, Response $response, array $params): void
    {
        $employee = $this->employeeModel->find($params['id'] ?? 0);
        if (!$employee) {
            $this->json(['error' => 'Employee not found'], 404);
        }
        $this->employeeModel->delete($employee['id']);
        $this->json(['success' => true]);
    }
}
