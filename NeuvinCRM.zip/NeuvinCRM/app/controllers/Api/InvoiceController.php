<?php
namespace App\Controllers\Api;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Invoice;

/**
 * API Invoice Controller
 */
class InvoiceController extends Controller
{
    private Invoice $invoiceModel;

    public function __construct()
    {
        parent::__construct();
        $this->invoiceModel = new Invoice();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $invoices = $this->invoiceModel->all();
        $this->json(['data' => $invoices]);
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $invoice = $this->invoiceModel->find($params['id'] ?? 0);
        if (!$invoice) {
            $this->json(['error' => 'Invoice not found'], 404);
        }
        $this->json(['data' => $invoice]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $invoiceId = $this->invoiceModel->create($request->getJson());
        $this->json(['success' => true, 'id' => $invoiceId], 201);
    }

    public function update(Request $request, Response $response, array $params): void
    {
        $invoice = $this->invoiceModel->find($params['id'] ?? 0);
        if (!$invoice) {
            $this->json(['error' => 'Invoice not found'], 404);
        }
        $this->invoiceModel->update($invoice['id'], $request->getJson());
        $this->json(['success' => true]);
    }

    public function delete(Request $request, Response $response, array $params): void
    {
        $invoice = $this->invoiceModel->find($params['id'] ?? 0);
        if (!$invoice) {
            $this->json(['error' => 'Invoice not found'], 404);
        }
        $this->invoiceModel->delete($invoice['id']);
        $this->json(['success' => true]);
    }

    public function send(Request $request, Response $response, array $params): void
    {
        $invoice = $this->invoiceModel->find($params['id'] ?? 0);
        if (!$invoice) {
            $this->json(['error' => 'Invoice not found'], 404);
        }

        // Send invoice email
        $emailService = new \App\Services\EmailService();
        // Implementation would go here

        $this->json(['success' => true, 'message' => 'Invoice sent']);
    }
}
