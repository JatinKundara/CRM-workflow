<?php
namespace App\Controllers\Api;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Models\Product;

/**
 * API Product Controller
 */
class ProductController extends Controller
{
    private Product $productModel;

    public function __construct()
    {
        parent::__construct();
        $this->productModel = new Product();
    }

    public function index(Request $request, Response $response, array $params): void
    {
        $products = $this->productModel->all();
        $this->json(['data' => $products]);
    }

    public function show(Request $request, Response $response, array $params): void
    {
        $product = $this->productModel->find($params['id'] ?? 0);
        if (!$product) {
            $this->json(['error' => 'Product not found'], 404);
        }
        $this->json(['data' => $product]);
    }

    public function store(Request $request, Response $response, array $params): void
    {
        $productId = $this->productModel->create($request->getJson());
        $this->json(['success' => true, 'id' => $productId], 201);
    }

    public function update(Request $request, Response $response, array $params): void
    {
        $product = $this->productModel->find($params['id'] ?? 0);
        if (!$product) {
            $this->json(['error' => 'Product not found'], 404);
        }
        $this->productModel->update($product['id'], $request->getJson());
        $this->json(['success' => true]);
    }

    public function delete(Request $request, Response $response, array $params): void
    {
        $product = $this->productModel->find($params['id'] ?? 0);
        if (!$product) {
            $this->json(['error' => 'Product not found'], 404);
        }
        $this->productModel->delete($product['id']);
        $this->json(['success' => true]);
    }
}
