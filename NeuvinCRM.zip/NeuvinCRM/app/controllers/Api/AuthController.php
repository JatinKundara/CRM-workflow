<?php
namespace App\Controllers\Api;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\JWTAuth;
use App\Services\AuthService;

/**
 * API Auth Controller
 */
class AuthController extends Controller
{
    private AuthService $authService;

    public function __construct()
    {
        parent::__construct();
        $this->authService = new AuthService();
    }

    /**
     * API Login
     */
    public function login(Request $request, Response $response, array $params): void
    {
        $email = $request->getJson('email');
        $password = $request->getJson('password');

        if ($this->authService->login($email, $password)) {
            $userId = $this->authService->getUser()['id'];
            $token = $this->authService->generateApiToken($userId);

            $this->json([
                'success' => true,
                'message' => 'Login successful',
                'token' => $token,
                'user' => $this->authService->getUser()
            ]);
        } else {
            $this->json(['error' => 'Invalid credentials'], 401);
        }
    }

    /**
     * API Logout
     */
    public function logout(Request $request, Response $response, array $params): void
    {
        $this->authService->logout();
        $this->json(['success' => true, 'message' => 'Logged out']);
    }

    /**
     * Refresh token
     */
    public function refreshToken(Request $request, Response $response, array $params): void
    {
        $user = $this->getAuthUser();
        $token = $this->authService->generateApiToken($user['id']);

        $this->json(['token' => $token]);
    }
}
