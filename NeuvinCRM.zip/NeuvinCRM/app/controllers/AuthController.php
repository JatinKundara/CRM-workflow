<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Security;
use App\Core\Validator;
use App\Services\AuthService;

/**
 * Authentication Controller
 */
class AuthController extends Controller
{
    private AuthService $authService;

    public function __construct()
    {
        parent::__construct();
        $this->authService = new AuthService();
    }

    /**
     * Show login form
     */
    public function showLogin(Request $request, Response $response, array $params): void
    {
        if ($this->isAuthenticated()) {
            $response->redirect(BASE_PATH . '/dashboard');
        }

        $this->view('auth/login', [
            'title' => 'Login',
            'csrfToken' => \App\Core\CSRF::generate()
        ]);
    }

    /**
     * Handle login
     */
    public function login(Request $request, Response $response, array $params): void
    {
        if (!$this->isAuthenticated()) {
            $email = $request->getPost('email');
            $password = $request->getPost('password');

            if (Security::isBruteForceAttempt($email)) {
                $this->json(['error' => 'Too many attempts. Please try again later.'], 429);
            }

            if ($this->authService->login($email, $password)) {
                $this->json(['success' => true, 'message' => 'Login successful']);
            } else {
                $this->json(['error' => 'Invalid credentials'], 401);
            }
        }
    }

    /**
     * Show register form
     */
    public function showRegister(Request $request, Response $response, array $params): void
    {
        if ($this->isAuthenticated()) {
            $response->redirect(BASE_PATH . '/dashboard');
        }

        $this->view('auth/register', [
            'title' => 'Register',
            'csrfToken' => \App\Core\CSRF::generate()
        ]);
    }

    /**
     * Handle registration
     */
    public function register(Request $request, Response $response, array $params): void
    {
        $rules = [
            'name' => 'required|minlength:3',
            'email' => 'required|email|unique:users',
            'password' => 'required|minlength:8|confirmed',
            'password_confirmation' => 'required'
        ];

        $validator = new Validator($request->getPostAll(), $rules);

        if (!$validator->validate()) {
            $this->json(['errors' => $validator->getErrors()], 422);
        }

        $userId = $this->authService->register([
            'name' => $request->getPost('name'),
            'email' => $request->getPost('email'),
            'password' => $request->getPost('password')
        ]);

        if (!$userId) {
            $this->json(['error' => 'Registration failed'], 400);
        }

        // Send verification email
        $emailService = new \App\Services\EmailService();
        $emailService->sendWelcomeEmail($request->getPost('email'), $request->getPost('name'));

        $this->json(['success' => true, 'message' => 'Registration successful. Please verify your email.']);
    }

    /**
     * Handle logout
     */
    public function logout(Request $request, Response $response, array $params): void
    {
        $this->authService->logout();
        $response->redirect(BASE_PATH . '/login');
    }

    /**
     * Show forgot password form
     */
    public function showForgotPassword(Request $request, Response $response, array $params): void
    {
        $this->view('auth/forgot-password', [
            'title' => 'Forgot Password',
            'csrfToken' => \App\Core\CSRF::generate()
        ]);
    }

    /**
     * Send password reset email
     */
    public function sendResetEmail(Request $request, Response $response, array $params): void
    {
        $email = $request->getPost('email');

        if ($this->authService->sendPasswordResetEmail($email)) {
            $this->json(['success' => true, 'message' => 'Password reset email sent']);
        } else {
            $this->json(['error' => 'Email not found'], 404);
        }
    }

    /**
     * Show reset password form
     */
    public function showResetPassword(Request $request, Response $response, array $params): void
    {
        $this->view('auth/reset-password', [
            'title' => 'Reset Password',
            'csrfToken' => \App\Core\CSRF::generate()
        ]);
    }

    /**
     * Handle password reset
     */
    public function resetPassword(Request $request, Response $response, array $params): void
    {
        $token = $request->getPost('token');
        $password = $request->getPost('password');

        if ($this->authService->resetPassword($token, $password)) {
            $this->json(['success' => true, 'message' => 'Password reset successful']);
        } else {
            $this->json(['error' => 'Invalid or expired token'], 400);
        }
    }
}
