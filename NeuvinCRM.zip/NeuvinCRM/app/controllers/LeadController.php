<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Models\Lead;

/**
 * Lead Controller
 */
class LeadController extends Controller
{
    private Lead $leadModel;

    public function __construct()
    {
        parent::__construct();
        $this->leadModel = new Lead();
    }

    /**
     * List leads
     */
    public function index(Request $request, Response $response, array $params): void
    {
        $this->authorize('leads.view');

        $page = (int) $request->getQuery('page', 1);
        $perPage = ITEMS_PER_PAGE;
        $offset = ($page - 1) * $perPage;

        $leads = $this->leadModel->all($perPage, $offset);
        $totalLeads = $this->leadModel->count();
        $totalPages = ceil($totalLeads / $perPage);

        $this->view('crm/leads/index', [
            'title' => 'Leads',
            'leads' => $leads,
            'currentPage' => $page,
            'totalPages' => $totalPages,
            'csrfToken' => \App\Core\CSRF::generate()
        ]);
    }

    /**
     * Show lead details
     */
    public function show(Request $request, Response $response, array $params): void
    {
        $this->authorize('leads.view');

        $lead = $this->leadModel->find($params['id'] ?? 0);

        if (!$lead) {
            $response->setStatusCode(404);
            $this->json(['error' => 'Lead not found']);
        }

        $this->view('crm/leads/show', [
            'title' => 'Lead Details',
            'lead' => $lead
        ]);
    }

    /**
     * Create lead
     */
    public function store(Request $request, Response $response, array $params): void
    {
        $this->authorize('leads.create');

        $rules = [
            'first_name' => 'required',
            'email' => 'required|email',
            'phone' => 'required',
            'source' => 'required'
        ];

        $validator = new Validator($request->getPostAll(), $rules);

        if (!$validator->validate()) {
            $this->json(['errors' => $validator->getErrors()], 422);
        }

        $user = $this->getAuthUser();

        $leadId = $this->leadModel->create([
            'first_name' => $request->getPost('first_name'),
            'last_name' => $request->getPost('last_name'),
            'email' => $request->getPost('email'),
            'phone' => $request->getPost('phone'),
            'company' => $request->getPost('company'),
            'source' => $request->getPost('source'),
            'assigned_to' => $request->getPost('assigned_to'),
            'notes' => $request->getPost('notes'),
            'value' => $request->getPost('value')
        ]);

        audit($user['id'], 'CREATE', 'leads', ['lead_id' => $leadId]);

        $this->json(['success' => true, 'message' => 'Lead created', 'id' => $leadId]);
    }

    /**
     * Update lead
     */
    public function update(Request $request, Response $response, array $params): void
    {
        $this->authorize('leads.manage');

        $lead = $this->leadModel->find($params['id'] ?? 0);

        if (!$lead) {
            $this->json(['error' => 'Lead not found'], 404);
        }

        $user = $this->getAuthUser();

        $this->leadModel->update($lead['id'], [
            'first_name' => $request->getPost('first_name'),
            'last_name' => $request->getPost('last_name'),
            'email' => $request->getPost('email'),
            'phone' => $request->getPost('phone'),
            'company' => $request->getPost('company'),
            'source' => $request->getPost('source'),
            'status' => $request->getPost('status'),
            'assigned_to' => $request->getPost('assigned_to'),
            'notes' => $request->getPost('notes')
        ]);

        audit($user['id'], 'UPDATE', 'leads', ['lead_id' => $lead['id']]);

        $this->json(['success' => true, 'message' => 'Lead updated']);
    }

    /**
     * Delete lead
     */
    public function delete(Request $request, Response $response, array $params): void
    {
        $this->authorize('leads.delete');

        $lead = $this->leadModel->find($params['id'] ?? 0);

        if (!$lead) {
            $this->json(['error' => 'Lead not found'], 404);
        }

        $user = $this->getAuthUser();

        $this->leadModel->delete($lead['id']);

        audit($user['id'], 'DELETE', 'leads', ['lead_id' => $lead['id']]);

        $this->json(['success' => true, 'message' => 'Lead deleted']);
    }
}
