<?php
namespace App\Models;

use App\Core\Model;

/**
 * Deal Model
 */
class Deal extends Model
{
    protected string $table = 'deals';
    protected array $fillable = [
        'title', 'description', 'customer_id', 'amount', 'currency',
        'stage', 'probability', 'expected_close_date', 'assigned_to', 'created_by'
    ];

    /**
     * Deal stages (Kanban board)
     */
    const STAGES = ['prospect', 'negotiation', 'proposal', 'closed_won', 'closed_lost'];

    /**
     * Get deals by stage
     */
    public function getByStage(string $stage): array
    {
        return $this->where('stage', $stage);
    }

    /**
     * Get deals by probability
     */
    public function getByProbability(int $minProb, int $maxProb = 100): array
    {
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `probability` >= ? AND `probability` <= ? ORDER BY `probability` DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$minProb, $maxProb]);
        return $stmt->fetchAll();
    }

    /**
     * Get pipeline by stage
     */
    public function getPipeline(): array
    {
        $pipeline = [];
        foreach (self::STAGES as $stage) {
            $deals = $this->getByStage($stage);
            $pipeline[$stage] = [
                'stage' => $stage,
                'count' => count($deals),
                'total' => array_sum(array_column($deals, 'amount')),
                'deals' => $deals
            ];
        }
        return $pipeline;
    }

    /**
     * Update stage
     */
    public function updateStage(int $dealId, string $stage): bool
    {
        if (!in_array($stage, self::STAGES)) {
            return false;
        }
        return $this->update($dealId, ['stage' => $stage]);
    }

    /**
     * Get sales forecast
     */
    public function getSalesForecast(int $months = 3): array
    {
        $endDate = date('Y-m-d', strtotime("+{$months} months"));
        $sql = "
            SELECT DATE_FORMAT(`expected_close_date`, '%Y-%m') as month, SUM(`amount` * `probability` / 100) as forecast
            FROM `" . $this->table . "`
            WHERE `expected_close_date` <= ? AND `stage` != 'closed_lost'
            GROUP BY DATE_FORMAT(`expected_close_date`, '%Y-%m')
            ORDER BY month
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$endDate]);
        return $stmt->fetchAll();
    }
}
