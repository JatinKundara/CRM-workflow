<?php
namespace App\Models;

use App\Core\Model;

/**
 * PurchaseOrder Model
 */
class PurchaseOrder extends Model
{
    protected string $table = 'purchase_orders';
    protected array $fillable = [
        'po_number', 'vendor_id', 'total', 'currency', 'status',
        'order_date', 'expected_date', 'created_by', 'notes'
    ];

    const STATUSES = ['draft', 'sent', 'confirmed', 'received', 'cancelled'];

    /**
     * Get PO items
     */
    public function getItems(int $poId): array
    {
        $sql = "SELECT * FROM purchase_order_items WHERE purchase_order_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$poId]);
        return $stmt->fetchAll();
    }

    /**
     * Generate PO number
     */
    public function generatePoNumber(): string
    {
        $count = $this->count() + 1;
        $date = date('Y');
        return "PO-{$date}-" . str_pad($count, 5, '0', STR_PAD_LEFT);
    }

    /**
     * Get pending POs
     */
    public function getPending(): array
    {
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `status` IN ('sent', 'confirmed') ORDER BY `order_date`";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Get GRN (Goods Received Note)
     */
    public function getGRN(int $poId): ?array
    {
        $sql = "SELECT * FROM goods_received_notes WHERE purchase_order_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$poId]);
        return $stmt->fetch() ?: null;
    }
}
