<?php
namespace App\Models;

use App\Core\Model;

/**
 * Expense Model
 */
class Expense extends Model
{
    protected string $table = 'expenses';
    protected array $fillable = [
        'description', 'amount', 'category', 'date', 'created_by', 'notes'
    ];

    /**
     * Get expenses by category
     */
    public function getByCategory(string $category): array
    {
        return $this->where('category', $category);
    }

    /**
     * Get monthly expenses
     */
    public function getMonthlyTotal(string $month): float
    {
        $sql = "
            SELECT SUM(`amount`) as total
            FROM `" . $this->table . "`
            WHERE DATE_FORMAT(`date`, '%Y-%m') = ?
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$month]);
        $result = $stmt->fetch();
        return (float) ($result['total'] ?? 0);
    }

    /**
     * Get expenses report
     */
    public function getReport(string $startDate, string $endDate): array
    {
        $sql = "
            SELECT `category`, SUM(`amount`) as total, COUNT(*) as count
            FROM `" . $this->table . "`
            WHERE `date` BETWEEN ? AND ?
            GROUP BY `category`
            ORDER BY total DESC
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$startDate, $endDate]);
        return $stmt->fetchAll();
    }
}
