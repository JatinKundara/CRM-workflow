<?php
namespace App\Models;

use App\Core\Model;

/**
 * Vendor Model
 */
class Vendor extends Model
{
    protected string $table = 'vendors';
    protected array $fillable = [
        'name', 'email', 'phone', 'address', 'city', 'state',
        'country', 'postal_code', 'tax_id', 'contact_person'
    ];

    /**
     * Get vendor purchase orders
     */
    public function getPurchaseOrders(int $vendorId): array
    {
        $sql = "SELECT * FROM purchase_orders WHERE vendor_id = ? ORDER BY created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$vendorId]);
        return $stmt->fetchAll();
    }

    /**
     * Search vendors
     */
    public function search(string $query): array
    {
        $sql = "
            SELECT * FROM `" . $this->table . "`
            WHERE `name` LIKE ? OR `email` LIKE ? OR `tax_id` LIKE ?
            ORDER BY `name`
        ";
        $param = "%{$query}%";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$param, $param, $param]);
        return $stmt->fetchAll();
    }

    /**
     * Get vendor total purchases
     */
    public function getTotalPurchases(int $vendorId): float
    {
        $sql = "SELECT SUM(total) as total FROM purchase_orders WHERE vendor_id = ? AND status = 'completed'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$vendorId]);
        $result = $stmt->fetch();
        return (float) ($result['total'] ?? 0);
    }
}
