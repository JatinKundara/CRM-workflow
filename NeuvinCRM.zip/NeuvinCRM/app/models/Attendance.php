<?php
namespace App\Models;

use App\Core\Model;

/**
 * Attendance Model
 */
class Attendance extends Model
{
    protected string $table = 'attendance';
    protected array $fillable = [
        'employee_id', 'date', 'check_in', 'check_out', 'status', 'notes'
    ];

    const STATUSES = ['present', 'absent', 'leave', 'holiday', 'half_day'];

    /**
     * Get attendance by month
     */
    public function getByMonth(int $employeeId, string $month): array
    {
        $sql = "
            SELECT * FROM `" . $this->table . "`
            WHERE `employee_id` = ? AND DATE_FORMAT(`date`, '%Y-%m') = ?
            ORDER BY `date`
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$employeeId, $month]);
        return $stmt->fetchAll();
    }

    /**
     * Get attendance summary
     */
    public function getSummary(int $employeeId, string $month): array
    {
        $sql = "
            SELECT `status`, COUNT(*) as count
            FROM `" . $this->table . "`
            WHERE `employee_id` = ? AND DATE_FORMAT(`date`, '%Y-%m') = ?
            GROUP BY `status`
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$employeeId, $month]);
        return $stmt->fetchAll();
    }

    /**
     * Mark date present
     */
    public function markPresent(int $employeeId, string $date): bool
    {
        /** @var User $user */
        $user = null;

        $existing = $this->db->prepare(
            "SELECT * FROM `" . $this->table . "` WHERE `employee_id` = ? AND `date` = ?"
        )->execute([$employeeId, $date])->fetch();

        if ($existing) {
            return $this->update($existing['id'], ['status' => 'present']);
        }

        return (bool) $this->create([
            'employee_id' => $employeeId,
            'date' => $date,
            'status' => 'present',
            'check_in' => date('H:i:s')
        ]);
    }
}
