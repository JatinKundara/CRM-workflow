<?php
namespace App\Models;

use App\Core\Model;

/**
 * User Model
 */
class User extends Model
{
    protected string $table = 'users';
    protected array $fillable = [
        'name', 'email', 'password', 'phone', 'avatar', 
        'role_id', 'is_active', 'email_verified_at', 'remember_token', 'last_login'
    ];

    /**
     * Get user role
     */
    public function getRole(): ?array
    {
        return $this->db->prepare(
            "SELECT r.* FROM `roles` r WHERE r.`id` = (SELECT `role_id` FROM `users` WHERE `id` = ?)"
        )->execute([$this->attributes['id']])->fetch();
    }

    /**
     * Get user permissions
     */
    public function getPermissions(): array
    {
        $sql = "
            SELECT DISTINCT p.* FROM `permissions` p
            JOIN `role_permissions` rp ON p.`id` = rp.`permission_id`
            WHERE rp.`role_id` = (SELECT `role_id` FROM `users` WHERE `id` = ?)
        ";
        return $this->db->prepare($sql)->execute([$this->attributes['id']])->fetchAll();
    }

    /**
     * Find by email
     */
    public function findByEmail(string $email): ?array
    {
        return $this->where('email', $email)[0] ?? null;
    }

    /**
     * Verify email
     */
    public function verifyEmail(int $userId): bool
    {
        return $this->update($userId, ['email_verified_at' => date('Y-m-d H:i:s')]);
    }

    /**
     * Update last login
     */
    public function updateLastLogin(int $userId): bool
    {
        return $this->update($userId, ['last_login' => date('Y-m-d H:i:s')]);
    }
}
