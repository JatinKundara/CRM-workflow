<?php
namespace App\Models;

use App\Core\Model;

/**
 * Task Model
 */
class Task extends Model
{
    protected string $table = 'tasks';
    protected array $fillable = [
        'title', 'description', 'assigned_to', 'status', 'priority',
        'due_date', 'related_to_type', 'related_to_id', 'created_by'
    ];

    /**
     * Task priorities
     */
    const PRIORITIES = ['low', 'medium', 'high', 'urgent'];
    const STATUSES = ['pending', 'in_progress', 'completed', 'cancelled'];

    /**
     * Get tasks by status
     */
    public function getByStatus(string $status): array
    {
        return $this->where('status', $status);
    }

    /**
     * Get tasks by priority
     */
    public function getByPriority(string $priority): array
    {
        return $this->where('priority', $priority);
    }

    /**
     * Get upcoming tasks
     */
    public function getUpcoming(int $days = 7): array
    {
        $date = date('Y-m-d', strtotime("+{$days} days"));
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `due_date` <= ? AND `status` != 'completed' ORDER BY `due_date`";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$date]);
        return $stmt->fetchAll();
    }

    /**
     * Get overdue tasks
     */
    public function getOverdue(): array
    {
        $today = date('Y-m-d');
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `due_date` < ? AND `status` != 'completed' ORDER BY `due_date`";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$today]);
        return $stmt->fetchAll();
    }

    /**
     * Mark completed
     */
    public function markCompleted(int $taskId): bool
    {
        return $this->update($taskId, ['status' => 'completed', 'completed_at' => date('Y-m-d H:i:s')]);
    }

    /**
     * Get tasks by user
     */
    public function getByUser(int $userId): array
    {
        return $this->where('assigned_to', $userId);
    }
}
