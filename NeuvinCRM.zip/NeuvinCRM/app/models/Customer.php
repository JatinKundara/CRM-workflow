<?php
namespace App\Models;

use App\Core\Model;

/**
 * Customer Model
 */
class Customer extends Model
{
    protected string $table = 'customers';
    protected array $fillable = [
        'first_name', 'last_name', 'email', 'phone', 'company',
        'address', 'city', 'state', 'country', 'postal_code',
        'tax_id', 'created_by', 'notes'
    ];

    /**
     * Get customer full name
     */
    public function getFullName(): string
    {
        return ($this->attributes['first_name'] ?? '') . ' ' . ($this->attributes['last_name'] ?? '');
    }

    /**
     * Get customer deals
     */
    public function getDeals(int $customerId): array
    {
        $deal = new Deal();
        return $deal->where('customer_id', $customerId);
    }

    /**
     * Get customer invoices
     */
    public function getInvoices(int $customerId): array
    {
        $invoice = new Invoice();
        return $invoice->where('customer_id', $customerId);
    }

    /**
     * Get customer activities
     */
    public function getActivities(int $customerId): array
    {
        $sql = "SELECT * FROM activities WHERE customer_id = ? ORDER BY created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$customerId]);
        return $stmt->fetchAll();
    }

    /**
     * Search customers
     */
    public function search(string $query): array
    {
        $sql = "
            SELECT * FROM `" . $this->table . "`
            WHERE `first_name` LIKE ? OR `last_name` LIKE ? OR `email` LIKE ? OR `company` LIKE ?
            ORDER BY `created_at` DESC
        ";
        $param = "%{$query}%";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$param, $param, $param, $param]);
        return $stmt->fetchAll();
    }
}
