<?php
namespace App\Models;

use App\Core\Model;

/**
 * Lead Model
 */
class Lead extends Model
{
    protected string $table = 'leads';
    protected array $fillable = [
        'first_name', 'last_name', 'email', 'phone', 'company',
        'source', 'status', 'assigned_to', 'notes', 'value', 'currency'
    ];

    /**
     * Get assigned user
     */
    public function getAssignedUser(): ?array
    {
        if ($this->attributes['assigned_to'] ?? null) {
            $model = new User();
            return $model->find($this->attributes['assigned_to']);
        }
        return null;
    }

    /**
     * Get leads by status
     */
    public function getByStatus(string $status): array
    {
        return $this->where('status', $status);
    }

    /**
     * Get leads by source
     */
    public function getBySource(string $source): array
    {
        return $this->where('source', $source);
    }

    /**
     * Get leads by assigned user
     */
    public function getByAssignedUser(int $userId): array
    {
        return $this->where('assigned_to', $userId);
    }

    /**
     * Convert to customer
     */
    public function convertToCustomer(int $leadId, int $userId): int|false
    {
        $lead = $this->find($leadId);
        if (!$lead) {
            return false;
        }

        $customer = new Customer();
        $customerId = $customer->create([
            'first_name' => $lead['first_name'],
            'last_name' => $lead['last_name'],
            'email' => $lead['email'],
            'phone' => $lead['phone'],
            'company' => $lead['company'],
            'created_by' => $userId
        ]);

        if ($customerId) {
            $this->update($leadId, ['status' => 'converted']);
        }

        return $customerId;
    }
}
