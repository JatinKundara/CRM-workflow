<?php
namespace App\Models;

use App\Core\Model;

/**
 * Invoice Model
 */
class Invoice extends Model
{
    protected string $table = 'invoices';
    protected array $fillable = [
        'invoice_number', 'customer_id', 'amount', 'tax_amount', 'total',
        'currency', 'issue_date', 'due_date', 'status', 'notes', 'created_by'
    ];

    const STATUSES = ['draft', 'sent', 'paid', 'overdue', 'cancelled'];

    /**
     * Get invoice items
     */
    public function getItems(int $invoiceId): array
    {
        $sql = "SELECT * FROM invoice_items WHERE invoice_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$invoiceId]);
        return $stmt->fetchAll();
    }

    /**
     * Generate invoice number
     */
    public function generateInvoiceNumber(): string
    {
        $count = $this->count() + 1;
        $date = date('Y');
        return "INV-{$date}-" . str_pad($count, 5, '0', STR_PAD_LEFT);
    }

    /**
     * Get overdue invoices
     */
    public function getOverdue(): array
    {
        $today = date('Y-m-d');
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `due_date` < ? AND `status` NOT IN ('paid', 'cancelled') ORDER BY `due_date`";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$today]);
        return $stmt->fetchAll();
    }

    /**
     * Mark paid
     */
    public function markPaid(int $invoiceId): bool
    {
        return $this->update($invoiceId, ['status' => 'paid', 'paid_at' => date('Y-m-d H:i:s')]);
    }

    /**
     * Get recurring invoices
     */
    public function getRecurring(): array
    {
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `is_recurring` = 1 AND `status` = 'active'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
