<?php
namespace App\Models;

use App\Core\Model;

/**
 * Product Model
 */
class Product extends Model
{
    protected string $table = 'products';
    protected array $fillable = [
        'name', 'sku', 'category', 'price', 'cost', 'quantity', 'reorder_level'
    ];

    /**
     * Get products by category
     */
    public function getByCategory(int $categoryId): array
    {
        return $this->where('category_id', $categoryId);
    }

    /**
     * Get low stock products
     */
    public function getLowStock(): array
    {
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `quantity` <= `reorder_level` ORDER BY `quantity`";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Search products
     */
    public function search(string $query): array
    {
        $sql = "
            SELECT * FROM `" . $this->table . "`
            WHERE `name` LIKE ? OR `sku` LIKE ? OR `barcode` LIKE ?
            ORDER BY `name`
        ";
        $param = "%{$query}%";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$param, $param, $param]);
        return $stmt->fetchAll();
    }

    /**
     * Update stock
     */
    public function updateStock(int $productId, int $quantity, string $type = 'in'): bool
    {
        $product = $this->find($productId);
        if (!$product) {
            return false;
        }

        $newQuantity = $type === 'in'
            ? $product['quantity_in_stock'] + $quantity
            : $product['quantity_in_stock'] - $quantity;

        return $this->update($productId, ['quantity_in_stock' => max(0, $newQuantity)]);
    }
}
