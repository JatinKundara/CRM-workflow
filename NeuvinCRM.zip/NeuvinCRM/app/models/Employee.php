<?php
namespace App\Models;

use App\Core\Model;

/**
 * Employee Model
 */
class Employee extends Model
{
    protected string $table = 'employees';
    protected array $fillable = [
        'user_id', 'first_name', 'last_name', 'email', 'phone',
        'department_id', 'designation', 'hire_date', 'employee_id',
        'salary', 'address', 'city', 'state', 'country', 'postal_code'
    ];

    /**
     * Get employee full name
     */
    public function getFullName(): string
    {
        return ($this->attributes['first_name'] ?? '') . ' ' . ($this->attributes['last_name'] ?? '');
    }

    /**
     * Get employee attendance
     */
    public function getAttendance(int $employeeId): array
    {
        $sql = "SELECT * FROM attendance WHERE employee_id = ? ORDER BY date DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$employeeId]);
        return $stmt->fetchAll();
    }

    /**
     * Get employees by department
     */
    public function getByDepartment(int $departmentId): array
    {
        return $this->where('department_id', $departmentId);
    }

    /**
     * Get employee payroll history
     */
    public function getPayrollHistory(int $employeeId): array
    {
        $sql = "SELECT * FROM payroll WHERE employee_id = ? ORDER BY month DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$employeeId]);
        return $stmt->fetchAll();
    }

    /**
     * Search employees
     */
    public function search(string $query): array
    {
        $sql = "
            SELECT * FROM `" . $this->table . "`
            WHERE `first_name` LIKE ? OR `last_name` LIKE ? OR `email` LIKE ? OR `employee_id` LIKE ?
            ORDER BY `first_name`
        ";
        $param = "%{$query}%";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$param, $param, $param, $param]);
        return $stmt->fetchAll();
    }
}
