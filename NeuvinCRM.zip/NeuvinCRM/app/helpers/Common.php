<?php
/**
 * Common Helper Functions
 */

/**
 * Generate URL with base path
 */
function url(string $path = ''): string
{
    $base = defined('BASE_PATH') ? BASE_PATH : '';
    return rtrim($base, '/') . '/' . ltrim($path, '/');
}

/**
 * Redirect to URL
 */
function redirect(string $url, int $statusCode = 302): void
{
    header("Location: {$url}", true, $statusCode);
    exit;
}

/**
 * Sanitize output
 */
function sanitize(mixed $data): mixed
{
    return \App\Core\Security::sanitize($data);
}

/**
 * Hash password
 */
function hashPassword(string $password): string
{
    return \App\Core\Security::hashPassword($password);
}

/**
 * Verify password
 */
function verifyPassword(string $password, string $hash): bool
{
    return \App\Core\Security::verifyPassword($password, $hash);
}

/**
 * Get CSRF token
 */
function csrfToken(): string
{
    return \App\Core\CSRF::generate();
}

/**
 * Get CSRF field HTML
 */
function csrfField(): string
{
    return \App\Core\CSRF::field();
}

/**
 * Get flash message
 */
function flushMessage(string $key): mixed
{
    $session = new \App\Core\Session();
    return $session->getFlash($key);
}

/**
 * Format currency
 */
function formatCurrency(float $amount, string $currency = DEFAULT_CURRENCY): string
{
    return match ($currency) {
        'USD' => '$' . number_format($amount, 2),
        'EUR' => '€' . number_format($amount, 2),
        'GBP' => '£' . number_format($amount, 2),
        'INR' => '₹' . number_format($amount, 2),
        default => number_format($amount, 2)
    };
}

/**
 * Format date
 */
function formatDate(string|null $date, string $format = 'M d, Y'): string
{
    if (!$date) {
        return '';
    }
    return date($format, strtotime($date));
}

/**
 * Get current user
 */
function currentUser(): ?array
{
    $authService = new \App\Services\AuthService();
    return $authService->getUser();
}

/**
 * Check if user is authenticated
 */
function isAuthenticated(): bool
{
    return currentUser() !== null;
}

/**
 * Check if user has permission
 */
function can(string $permission): bool
{
    $user = currentUser();
    if (!$user) {
        return false;
    }

    $permissionService = new \App\Services\PermissionService();
    return $permissionService->hasPermission($user['id'], $permission);
}

/**
 * Get pagination offset
 */
function getPaginationOffset(int $page = 1, int $perPage = ITEMS_PER_PAGE): int
{
    return ($page - 1) * $perPage;
}

/**
 * Generate UUID
 */
function generateUuid(): string
{
    return \Ramsey\Uuid\Uuid::uuid4()->toString();
}

/**
 * Log message
 */
function logMessage(string $level, string $message, array $context = []): void
{
    $logger = new \App\Core\Logger();
    $logger->log($level, $message, $context);
}

/**
 * Log audit
 */
function audit(int $userId, string $action, string $module, array $details = []): void
{
    $logger = new \App\Core\Logger();
    $logger->audit($userId, $action, $module, $details);
}

/**
 * Route helper
 */
function route(string $name, array $params = []): string
{
    // Simple route helper - can be expanded with named routes
    return url($name);
}

/**
 * Query builder helper
 */
function query(string $sql, array $params = []): mixed
{
    $db = \App\Core\Database::getInstance()->getConnection();
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

/**
 * Truncate text
 */
function truncate(string $text, int $length = 100, string $suffix = '...'): string
{
    if (strlen($text) > $length) {
        return substr($text, 0, $length) . $suffix;
    }
    return $text;
}

/**
 * Check if production
 */
function isProduction(): bool
{
    return APP_ENV === 'production';
}

/**
 * Check if menu item is active
 */
function isActive(string $path): string
{
    $currentPath = $_SERVER['REQUEST_URI'] ?? '';
    // Remove base path and query string
    $currentPath = str_replace(BASE_PATH, '', $currentPath);
    $currentPath = strtok($currentPath, '?');
    
    if (strpos($currentPath, '/' . $path) !== false) {
        return 'active';
    }
    return '';
}

/**
 * Check if development
 */
function isDevelopment(): bool
{
    return APP_ENV === 'development';
}
