<?php
namespace App\Core;

/**
 * CSRF Protection
 */
class CSRF
{
    private const TOKEN_LENGTH = 32;
    private const TOKEN_NAME = '_csrf_token';

    /**
     * Generate CSRF token
     */
    public static function generate(): string
    {
        $session = new Session();
        
        if (!$session->has(self::TOKEN_NAME)) {
            $token = bin2hex(random_bytes(self::TOKEN_LENGTH));
            $session->set(self::TOKEN_NAME, $token);
        }

        return $session->get(self::TOKEN_NAME);
    }

    /**
     * Get token field HTML
     */
    public static function field(): string
    {
        $token = self::generate();
        return "<input type='hidden' name='" . self::TOKEN_NAME . "' value='{$token}'>";
    }

    /**
     * Verify token
     */
    public static function verify(string $token): bool
    {
        $session = new Session();
        $stored = $session->get(self::TOKEN_NAME);

        if (!$stored || !$token) {
            return false;
        }

        return hash_equals($stored, $token);
    }

    /**
     * Verify from request
     */
    public static function verifyRequest(Request $request): bool
    {
        $token = $request->getPost(self::TOKEN_NAME) ?: $request->getHeader('X-CSRF-Token');
        return self::verify($token ?? '');
    }
}
