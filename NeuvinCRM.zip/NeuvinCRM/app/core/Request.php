<?php
namespace App\Core;

/**
 * HTTP Request Handler
 */
class Request
{
    private array $get = [];
    private array $post = [];
    private array $files = [];
    private array $server = [];
    private array $json = [];
    private string $rawBody = '';

    public function __construct()
    {
        $this->get = $_GET ?? [];
        $this->post = $_POST ?? [];
        $this->files = $_FILES ?? [];
        $this->server = $_SERVER ?? [];
        $this->parseJson();
    }

    /**
     * Parse JSON input
     */
    private function parseJson(): void
    {
        if ($this->getContentType() === 'application/json') {
            $this->rawBody = file_get_contents('php://input');
            $this->json = json_decode($this->rawBody, true) ?? [];
        }
    }

    /**
     * Get request method
     */
    public function getMethod(): string
    {
        return strtoupper($this->server['REQUEST_METHOD'] ?? 'GET');
    }

    /**
     * Get request path
     */
    public function getPath(): string
    {
        // If using mod_rewrite, the url parameter is set
        if (isset($this->get['url'])) {
            return '/' . trim($this->get['url'], '/');
        }
        
        // Fallback: parse REQUEST_URI
        $path = parse_url($this->server['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        return str_replace(rtrim(dirname($this->server['SCRIPT_NAME'] ?? ''), '/'), '', $path);
    }

    /**
     * Get content type
     */
    public function getContentType(): string
    {
        return $this->server['CONTENT_TYPE'] ?? '';
    }

    /**
     * Get GET parameter
     */
    public function getQuery(string $key, mixed $default = null): mixed
    {
        return $this->get[$key] ?? $default;
    }

    /**
     * Get all GET parameters
     */
    public function getQueryAll(): array
    {
        return $this->get;
    }

    /**
     * Get POST parameter
     */
    public function getPost(string $key, mixed $default = null): mixed
    {
        return $this->post[$key] ?? $this->json[$key] ?? $default;
    }

    /**
     * Get all POST parameters
     */
    public function getPostAll(): array
    {
        return array_merge($this->post, $this->json);
    }

    /**
     * Get JSON parameter
     */
    public function getJson(?string $key = null, mixed $default = null): mixed
    {
        if ($key === null) {
            return $this->json;
        }
        return $this->json[$key] ?? $default;
    }

    /**
     * Get file
     */
    public function getFile(string $name): array|null
    {
        return $this->files[$name] ?? null;
    }

    /**
     * Get header
     */
    public function getHeader(string $name): string|null
    {
        $name = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        return $this->server[$name] ?? null;
    }

    /**
     * Get bearer token from Authorization header
     */
    public function getBearerToken(): string|null
    {
        $header = $this->getHeader('Authorization');
        if ($header && preg_match('/Bearer\s+(.+)/', $header, $matches)) {
            return $matches[1];
        }
        return null;
    }

    /**
     * Get client IP
     */
    public function getClientIp(): string
    {
        if (!empty($this->server['HTTP_CLIENT_IP'])) {
            return $this->server['HTTP_CLIENT_IP'];
        } elseif (!empty($this->server['HTTP_X_FORWARDED_FOR'])) {
            return explode(',', $this->server['HTTP_X_FORWARDED_FOR'])[0];
        }
        return $this->server['REMOTE_ADDR'] ?? '';
    }

    /**
     * Check if request is AJAX
     */
    public function isAjax(): bool
    {
        return $this->getHeader('X-Requested-With') === 'XMLHttpRequest';
    }

    /**
     * Check if request is HTTPS
     */
    public function isSecure(): bool
    {
        return (!empty($this->server['HTTPS']) && $this->server['HTTPS'] !== 'off') ||
               $this->server['SERVER_PORT'] === '443';
    }

    /**
     * Get session
     */
    public function getSession(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    /**
     * Set session
     */
    public function setSession(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }
}
