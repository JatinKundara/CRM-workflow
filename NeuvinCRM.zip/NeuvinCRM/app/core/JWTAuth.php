<?php
namespace App\Core;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

/**
 * JWT Authentication
 */
class JWTAuth
{
    /**
     * Generate token
     */
    public static function generateToken(array $payload, int $expiresIn = JWT_EXPIRATION): string
    {
        $payload['iat'] = time();
        $payload['exp'] = time() + $expiresIn;

        return JWT::encode($payload, JWT_SECRET, 'HS256');
    }

    /**
     * Verify and decode token
     */
    public static function decodeToken(string $token): ?array
    {
        try {
            $decoded = JWT::decode($token, new Key(JWT_SECRET, 'HS256'));
            return (array) $decoded;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Get token from request
     */
    public static function getTokenFromRequest(Request $request): ?string
    {
        return $request->getBearerToken();
    }

    /**
     * Verify request has valid token
     */
    public static function verify(Request $request): bool
    {
        $token = self::getTokenFromRequest($request);
        return $token && self::decodeToken($token) !== null;
    }
}
