<?php
namespace App\Core;

/**
 * Validation Engine
 */
class Validator
{
    private array $data = [];
    private array $rules = [];
    private array $errors = [];
    private array $messages = [];

    public function __construct(array $data, array $rules, array $messages = [])
    {
        $this->data = $data;
        $this->rules = $rules;
        $this->messages = $messages;
    }

    /**
     * Validate
     */
    public function validate(): bool
    {
        foreach ($this->rules as $field => $fieldRules) {
            $fieldRules = is_string($fieldRules) ? explode('|', $fieldRules) : $fieldRules;
            
            foreach ($fieldRules as $rule) {
                $this->validateRule($field, $rule);
            }
        }

        return empty($this->errors);
    }

    /**
     * Validate single rule
     */
    private function validateRule(string $field, string $rule): void
    {
        $value = $this->data[$field] ?? null;
        [$ruleName, $parameter] = $this->parseRule($rule);

        match ($ruleName) {
            'required' => $this->validateRequired($field, $value),
            'email' => $this->validateEmail($field, $value),
            'min' => $this->validateMin($field, $value, (int) $parameter),
            'max' => $this->validateMax($field, $value, (int) $parameter),
            'minlength' => $this->validateMinLength($field, $value, (int) $parameter),
            'maxlength' => $this->validateMaxLength($field, $value, (int) $parameter),
            'regex' => $this->validateRegex($field, $value, $parameter),
            'unique' => $this->validateUnique($field, $value, $parameter),
            'confirmed' => $this->validateConfirmed($field, $value),
            'numeric' => $this->validateNumeric($field, $value),
            'integer' => $this->validateInteger($field, $value),
            'url' => $this->validateUrl($field, $value),
            'date' => $this->validateDate($field, $value),
            default => null
        };
    }

    /**
     * Parse rule
     */
    private function parseRule(string $rule): array
    {
        if (str_contains($rule, ':')) {
            [$name, $param] = explode(':', $rule, 2);
            return [$name, $param];
        }
        return [$rule, null];
    }

    /**
     * Add error
     */
    private function addError(string $field, string $message): void
    {
        if (!isset($this->errors[$field])) {
            $this->errors[$field] = [];
        }
        $this->errors[$field][] = $message;
    }

    /**
     * Get error message
     */
    private function getErrorMessage(string $field, string $rule, string $parameter = null): string
    {
        $key = "{$field}.{$rule}";
        if (isset($this->messages[$key])) {
            return $this->messages[$key];
        }

        return match ($rule) {
            'required' => "{$field} is required",
            'email' => "{$field} must be a valid email",
            'min' => "{$field} must be at least {$parameter}",
            'max' => "{$field} must not exceed {$parameter}",
            'minlength' => "{$field} must be at least {$parameter} characters",
            'maxlength' => "{$field} must not exceed {$parameter} characters",
            'numeric' => "{$field} must be numeric",
            'integer' => "{$field} must be an integer",
            'url' => "{$field} must be a valid URL",
            'date' => "{$field} must be a valid date",
            'unique' => "{$field} already exists",
            default => "{$field} is invalid"
        };
    }

    // Validation methods

    private function validateRequired(string $field, mixed $value): void
    {
        if (empty($value)) {
            $this->addError($field, $this->getErrorMessage($field, 'required'));
        }
    }

    private function validateEmail(string $field, mixed $value): void
    {
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->addError($field, $this->getErrorMessage($field, 'email'));
        }
    }

    private function validateMin(string $field, mixed $value, int $min): void
    {
        if (!empty($value) && (int) $value < $min) {
            $this->addError($field, $this->getErrorMessage($field, 'min', (string) $min));
        }
    }

    private function validateMax(string $field, mixed $value, int $max): void
    {
        if (!empty($value) && (int) $value > $max) {
            $this->addError($field, $this->getErrorMessage($field, 'max', (string) $max));
        }
    }

    private function validateMinLength(string $field, mixed $value, int $min): void
    {
        if (!empty($value) && strlen((string) $value) < $min) {
            $this->addError($field, $this->getErrorMessage($field, 'minlength', (string) $min));
        }
    }

    private function validateMaxLength(string $field, mixed $value, int $max): void
    {
        if (!empty($value) && strlen((string) $value) > $max) {
            $this->addError($field, $this->getErrorMessage($field, 'maxlength', (string) $max));
        }
    }

    private function validateRegex(string $field, mixed $value, string $pattern): void
    {
        if (!empty($value) && !preg_match($pattern, (string) $value)) {
            $this->addError($field, $this->getErrorMessage($field, 'regex'));
        }
    }

    private function validateUnique(string $field, mixed $value, string $table): void
    {
        if (!empty($value)) {
            $db = Database::getInstance()->getConnection();
            $sql = "SELECT COUNT(*) as count FROM {$table} WHERE {$field}=?";
            $stmt = $db->prepare($sql);
            $stmt->execute([$value]);
            
            if ((int) $stmt->fetch()['count'] > 0) {
                $this->addError($field, $this->getErrorMessage($field, 'unique'));
            }
        }
    }

    private function validateConfirmed(string $field, mixed $value): void
    {
        $confirmField = "{$field}_confirmation";
        if ($value !== ($this->data[$confirmField] ?? null)) {
            $this->addError($field, "{$field} confirmation does not match");
        }
    }

    private function validateNumeric(string $field, mixed $value): void
    {
        if (!empty($value) && !is_numeric($value)) {
            $this->addError($field, $this->getErrorMessage($field, 'numeric'));
        }
    }

    private function validateInteger(string $field, mixed $value): void
    {
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_INT)) {
            $this->addError($field, $this->getErrorMessage($field, 'integer'));
        }
    }

    private function validateUrl(string $field, mixed $value): void
    {
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_URL)) {
            $this->addError($field, $this->getErrorMessage($field, 'url'));
        }
    }

    private function validateDate(string $field, mixed $value): void
    {
        if (!empty($value)) {
            $date = \DateTime::createFromFormat('Y-m-d', (string) $value);
            if (!$date) {
                $this->addError($field, $this->getErrorMessage($field, 'date'));
            }
        }
    }

    /**
     * Get errors
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * Has errors
     */
    public function hasErrors(): bool
    {
        return !empty($this->errors);
    }

    /**
     * Get first error for field
     */
    public function getError(string $field): string|null
    {
        return $this->errors[$field][0] ?? null;
    }
}
