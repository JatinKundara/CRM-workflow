<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Application Bootstrap (Subfolder-safe Routing)
 */
class Application
{
    private static ?self $instance = null;
    private Router $router;
    private Request $request;
    private Response $response;
    private Logger $logger;

    private function __construct()
    {
        $this->request  = new Request();
        $this->response = new Response();
        $this->router   = new Router($this->request, $this->response);
        $this->logger   = new Logger();
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * RUN APPLICATION
     */
    public function run(): void
    {
        try {
            $this->prepareUrl();      // ⭐ NEW (IMPORTANT)
            $this->registerRoutes();  // load routes
            $this->router->dispatch();
        } catch (\Throwable $e) {
            $this->handleException($e);
        }
    }

    /**
     * ⭐ REMOVE PROJECT FOLDER FROM URL
     * Converts /NeuvinCRM/dashboard → /dashboard
     */
    private function prepareUrl(): void
    {
        $base = '/NeuvinCRM';

        if (isset($_SERVER['REQUEST_URI'])) {
            $_SERVER['REQUEST_URI'] = preg_replace('#^' . $base . '#', '', $_SERVER['REQUEST_URI']);
        }
    }

    /**
     * REGISTER ROUTES
     */
    private function registerRoutes(): void
    {
        $router = $this->router;

        // ⭐ DEFAULT HOME ROUTE (CRITICAL)
        $router->get('/', function () {
            header('Location: /NeuvinCRM/dashboard');
            exit;
        });

        // load user defined routes
        require APP_ROOT . '/routes/web.php';
        require APP_ROOT . '/routes/api.php';
    }

    /**
     * ERROR HANDLER
     */
    private function handleException(\Throwable $e): void
    {
        $this->logger->error('Application Exception', [
            'message' => $e->getMessage(),
            'file'    => $e->getFile(),
            'line'    => $e->getLine()
        ]);

        $this->response->setStatusCode(500);

        if (APP_DEBUG) {
            $this->response->json([
                'error' => $e->getMessage(),
                'file'  => $e->getFile(),
                'line'  => $e->getLine()
            ]);
        } else {
            $this->response->json(['error' => 'Internal server error']);
        }
    }

    public function getRouter(): Router   { return $this->router; }
    public function getRequest(): Request { return $this->request; }
    public function getResponse(): Response { return $this->response; }
    public function getLogger(): Logger { return $this->logger; }
}