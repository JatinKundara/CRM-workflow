<?php
namespace App\Core;

use PDO;
use PDOException;

/**
 * Database Connection Manager (Singleton)
 */
class Database
{
    private static ?self $instance = null;
    private ?PDO $connection = null;
    private array $config;

    private function __construct()
    {
        $this->config = require APP_ROOT . '/config/database.php';
        $this->connect();
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function connect(): void
    {
        try {
            $config = $this->config['mysql'];
            $dsn = "mysql:host={$config['host']}:{$config['port']};dbname={$config['database']};charset={$config['charset']}";
            
            $this->connection = new PDO(
                $dsn,
                $config['username'],
                $config['password'],
                $config['options']
            );
        } catch (PDOException $e) {
            error_log("Database Connection Error: " . $e->getMessage());
            die("Database connection failed. Check logs for details.");
        }
    }

    public function getConnection(): PDO
    {
        return $this->connection;
    }

    public function close(): void
    {
        $this->connection = null;
    }
}
