<?php
namespace App\Core;

/**
 * Session Manager
 */
class Session
{
    private bool $started = false;

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
            $this->started = true;
        }
    }

    /**
     * Set session value
     */
    public function set(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    /**
     * Get session value
     */
    public function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    /**
     * Check if session key exists
     */
    public function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    /**
     * Delete session value
     */
    public function delete(string $key): void
    {
        unset($_SESSION[$key]);
    }

    /**
     * Flush all sessions
     */
    public function flush(): void
    {
        $_SESSION = [];
    }

    /**
     * Flash message
     */
    public function flash(string $key, mixed $value): void
    {
        $_SESSION['_flash'][$key] = $value;
    }

    /**
     * Get flash message
     */
    public function getFlash(string $key): mixed
    {
        $value = $_SESSION['_flash'][$key] ?? null;
        unset($_SESSION['_flash'][$key]);
        return $value;
    }

    /**
     * Regenerate session ID
     */
    public function regenerate(): void
    {
        session_regenerate_id(true);
    }

    /**
     * Destroy session
     */
    public function destroy(): void
    {
        session_destroy();
        $this->started = false;
    }
}
