<?php
namespace App\Core;

/**
 * Security utilities
 */
class Security
{
    /**
     * Hash password
     */
    public static function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_HASH_ALGO, PASSWORD_HASH_OPTIONS);
    }

    /**
     * Verify password
     */
    public static function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    /**
     * Sanitize output (XSS prevention)
     */
    public static function sanitize(mixed $data): mixed
    {
        if (is_string($data)) {
            return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
        }
        
        if (is_array($data)) {
            return array_map([self::class, 'sanitize'], $data);
        }

        return $data;
    }

    /**
     * Generate secure random token
     */
    public static function generateToken(int $length = 32): string
    {
        return bin2hex(random_bytes($length));
    }

    /**
     * Sanitize file name
     */
    public static function sanitizeFileName(string $fileName): string
    {
        $fileName = basename($fileName);
        $fileName = preg_replace('/[^a-zA-Z0-9._-]/', '', $fileName);
        return $fileName;
    }

    /**
     * Validate file (check MIME type and extension)
     */
    public static function validateFile(string $filePath, array $allowedExtensions, array $allowedMimeTypes = []): bool
    {
        if (!file_exists($filePath)) {
            return false;
        }

        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        
        if (!in_array($extension, $allowedExtensions)) {
            return false;
        }

        if (!empty($allowedMimeTypes)) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($finfo, $filePath);
            finfo_close($finfo);

            if (!in_array($mimeType, $allowedMimeTypes)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Check brute force attempt
     */
    public static function isBruteForceAttempt(string $identifier): bool
    {
        $cacheFile = CACHE_PATH . '/brute_force_' . md5($identifier) . '.json';
        
        if (file_exists($cacheFile)) {
            $data = json_decode(file_get_contents($cacheFile), true);
            
            if (time() - $data['first_attempt'] < BRUTE_FORCE_TIMEOUT) {
                return $data['attempts'] >= BRUTE_FORCE_MAX_ATTEMPTS;
            }
        }

        return false;
    }

    /**
     * Record brute force attempt
     */
    public static function recordBruteForceAttempt(string $identifier): void
    {
        $cacheFile = CACHE_PATH . '/brute_force_' . md5($identifier) . '.json';
        
        $data = file_exists($cacheFile)
            ? json_decode(file_get_contents($cacheFile), true)
            : ['attempts' => 0, 'first_attempt' => time()];

        if (time() - $data['first_attempt'] >= BRUTE_FORCE_TIMEOUT) {
            $data = ['attempts' => 0, 'first_attempt' => time()];
        }

        $data['attempts']++;
        file_put_contents($cacheFile, json_encode($data));
    }

    /**
     * Clear brute force record
     */
    public static function clearBruteForceRecord(string $identifier): void
    {
        $cacheFile = CACHE_PATH . '/brute_force_' . md5($identifier) . '.json';
        
        if (file_exists($cacheFile)) {
            unlink($cacheFile);
        }
    }
}
