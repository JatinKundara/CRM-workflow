<?php
declare(strict_types=1);

namespace App\Core;

use Throwable;

/**
 * Router - URL routing and dispatcher (FIXED)
 */
class Router
{
    private array $routes = [];
    private Request $request;
    private Response $response;

    public function __construct(Request $request, Response $response)
    {
        $this->request  = $request;
        $this->response = $response;
    }

    /* =========================
       ROUTE REGISTRATION
    ==========================*/

    public function get(string $path, $handler, array $middleware = []): void
    {
        $this->registerRoute('GET', $path, $handler, $middleware);
    }

    public function post(string $path, $handler, array $middleware = []): void
    {
        $this->registerRoute('POST', $path, $handler, $middleware);
    }

    public function put(string $path, $handler, array $middleware = []): void
    {
        $this->registerRoute('PUT', $path, $handler, $middleware);
    }

    public function delete(string $path, $handler, array $middleware = []): void
    {
        $this->registerRoute('DELETE', $path, $handler, $middleware);
    }

    private function registerRoute(string $method, string $path, $handler, array $middleware): void
    {
        $path = $this->normalizePath($path);

        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler,
            'middleware' => $middleware,
            'regex' => $this->pathToRegex($path)
        ];
    }

    /* =========================
       URL HELPERS
    ==========================*/

    private function normalizePath(string $path): string
    {
        $path = trim($path, '/');
        return '/' . $path;
    }

    private function getCurrentPath(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';

        // remove query string
        $uri = strtok($uri, '?');

        // remove trailing slash except root
        if ($uri !== '/') {
            $uri = rtrim($uri, '/');
        }

        return $this->normalizePath(urldecode($uri));
    }

    private function pathToRegex(string $path): string
    {
        // /users/{id} → regex
        $path = preg_replace('/{([a-zA-Z_]+)}/', '(?P<$1>[a-zA-Z0-9_-]+)', $path);
        return '#^' . $path . '$#';
    }

    /* =========================
       DISPATCHER
    ==========================*/

    public function dispatch(): void
    {
        try {
            $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
            $path   = $this->getCurrentPath();

            // DEBUG (remove later if you want)
            if (APP_DEBUG && isset($_GET['routes'])) {
                echo "<pre>";
                echo "Current Path: " . $path . "\n\n";
                print_r($this->routes);
                exit;
            }

            foreach ($this->routes as $route) {
                if ($route['method'] !== $method) continue;

                if (preg_match($route['regex'], $path, $matches)) {

                    // extract named params
                    $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

                    // run middleware
                    foreach ($route['middleware'] as $mw) {
                        $this->runMiddleware($mw);
                    }

                    // run controller / closure
                    $this->runHandler($route['handler'], $params);
                    return;
                }
            }

            // 404
            $this->response->setStatusCode(404);
            echo "<h1 style='font-family:Arial'>404 - Route not found</h1>";
            echo "<p>URL: {$path}</p>";

        } catch (Throwable $e) {
            error_log("Router Error: " . $e->getMessage());
            $this->response->setStatusCode(500);
            $this->response->json(['error' => 'Internal server error']);
        }
    }

    /* =========================
       EXECUTION HELPERS
    ==========================*/

    private function runMiddleware(string $middleware): void
    {
        $class = "App\\Middleware\\{$middleware}";

        if (!class_exists($class)) {
            throw new \Exception("Middleware {$middleware} not found");
        }

        (new $class())->handle($this->request, $this->response);
    }

    private function runHandler($handler, array $params): void
    {
        // Controller format: HomeController@index
        if (is_string($handler)) {
            [$controller, $method] = explode('@', $handler);

            $class = "App\\Controllers\\{$controller}";

            if (!class_exists($class)) {
                throw new \Exception("Controller {$controller} not found");
            }

            $instance = new $class();
            call_user_func([$instance, $method], $this->request, $this->response, $params);
            return;
        }

        // Closure route
        if (is_callable($handler)) {
            call_user_func($handler, $this->request, $this->response, $params);
            return;
        }

        throw new \Exception("Invalid route handler");
    }
}