<?php
namespace App\Core;

/**
 * Base Controller
 */
abstract class Controller
{
    protected Request $request;
    protected Response $response;

    public function __construct()
    {
        $this->request = new Request();
        $this->response = new Response();
    }

    /**
     * Render view
     */
    protected function view(string $view, array $data = []): void
    {
        $this->response->view($view, $data);
    }

    /**
     * Return JSON response
     */
    protected function json(array $data, int $statusCode = 200): void
    {
        $this->response->setStatusCode($statusCode);
        $this->response->json($data);
    }

    /**
     * Redirect
     */
    protected function redirect(string $url): void
    {
        $this->response->redirect($url);
    }

    /**
     * Get authenticated user
     */
    protected function getAuthUser(): ?array
    {
        $authService = new \App\Services\AuthService();
        return $authService->getUser();
    }

    /**
     * Check if user is authenticated
     */
    protected function isAuthenticated(): bool
    {
        return $this->getAuthUser() !== null;
    }

    /**
     * Check permission
     */
    protected function can(string $permission): bool
    {
        $user = $this->getAuthUser();
        if (!$user) {
            return false;
        }

        $permissionService = new \App\Services\PermissionService();
        return $permissionService->hasPermission($user['id'], $permission);
    }

    /**
     * Authorize action
     */
    protected function authorize(string $permission): void
    {
        if (!$this->can($permission)) {
            $this->response->setStatusCode(403);
            $this->view('errors/403');
        }
    }
}
