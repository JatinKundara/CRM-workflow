<?php
namespace App\Core;

/**
 * HTTP Response Handler
 */
class Response
{
    private int $statusCode = 200;
    private array $headers = [];
    private mixed $body = '';

    public function __construct()
    {
        $this->setHeader('Content-Type', 'text/html; charset=utf-8');
    }

    /**
     * Set HTTP status code
     */
    public function setStatusCode(int $code): self
    {
        $this->statusCode = $code;
        http_response_code($code);
        return $this;
    }

    /**
     * Get HTTP status code
     */
    public function getStatusCode(): int
    {
        return $this->statusCode;
    }

    /**
     * Set header
     */
    public function setHeader(string $name, string $value): self
    {
        $this->headers[$name] = $value;
        header("{$name}: {$value}");
        return $this;
    }

    /**
     * Set JSON response
     */
    public function json(array $data): void
    {
        $this->setHeader('Content-Type', 'application/json');
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }

    /**
     * Send file download
     */
    public function download(string $filePath, ?string $fileName = null): void
    {
        if (!file_exists($filePath)) {
            throw new \Exception("File not found: {$filePath}");
        }

        $fileName = $fileName ?? basename($filePath);
        $fileSize = filesize($filePath);

        $this->setHeader('Content-Description', 'File Transfer');
        $this->setHeader('Content-Type', 'application/octet-stream');
        $this->setHeader('Content-Disposition', "attachment; filename=\"{$fileName}\"");
        $this->setHeader('Content-Length', (string) $fileSize);
        $this->setHeader('Pragma', 'public');
        $this->setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0');

        readfile($filePath);
        exit;
    }

    /**
     * Redirect
     */
    public function redirect(string $url, int $statusCode = 302): void
    {
        $this->setStatusCode($statusCode);
        $this->setHeader('Location', $url);
        exit;
    }

    /**
     * Set view response
     */
    public function view(string $view, array $data = []): void
    {
        extract($data);
        $viewPath = APP_ROOT . "/app/views/{$view}.php";
        
        if (!file_exists($viewPath)) {
            throw new \Exception("View not found: {$view}");
        }

        ob_start();
        include $viewPath;
        $content = ob_get_clean();
        
        // Render with layout if it's not an auth view
        if (strpos($view, 'auth/') !== 0) {
            ob_start();
            extract($data);
            include APP_ROOT . "/app/views/layouts/app.php";
            $body = ob_get_clean();
        } else {
            $body = $content;
        }
        
        $this->body = $body;
        echo $this->body;
        exit;
    }

    /**
     * Send response
     */
    public function send(string $content): void
    {
        echo $content;
        exit;
    }
}
