<?php
namespace App\Core;

use PDO;

/**
 * Base Model - Database abstraction layer
 */
abstract class Model
{
    protected string $table;
    protected PDO $db;
    protected array $attributes = [];
    protected array $fillable = [];
    protected array $hidden = [];

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Create new record
     */
    public function create(array $data): bool|string
    {
        $data = $this->filterFillable($data);
        $columns = '`' . implode('`,`', array_keys($data)) . '`';
        $placeholders = implode(',', array_fill(0, count($data), '?'));

        $sql = "INSERT INTO `" . $this->table . "` (" . $columns . ") VALUES (" . $placeholders . ")";
        $stmt = $this->db->prepare($sql);

        if ($stmt->execute(array_values($data))) {
            return $this->db->lastInsertId();
        }

        return false;
    }

    /**
     * Update record
     */
    public function update(int|string $id, array $data): bool
    {
        $data = $this->filterFillable($data);
        $sets = implode(',', array_map(fn($k) => "`{$k}`=?", array_keys($data)));

        $sql = "UPDATE `" . $this->table . "` SET " . $sets . " WHERE `id`=?";
        $stmt = $this->db->prepare($sql);

        return $stmt->execute([...array_values($data), $id]);
    }

    /**
     * Delete record
     */
    public function delete(int|string $id): bool
    {
        $sql = "DELETE FROM `" . $this->table . "` WHERE `id`=?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$id]);
    }

    /**
     * Find by ID
     */
    public function find(int|string $id): ?array
    {
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `id`=? LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    /**
     * Find all
     */
    public function all(int $limit = 0, int $offset = 0): array
    {
        $sql = "SELECT * FROM `" . $this->table . "`";
        if ($limit > 0) {
            $sql .= " LIMIT {$limit} OFFSET {$offset}";
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Find by condition
     */
    public function where(string $column, mixed $value, string $operator = '='): array
    {
        $sql = "SELECT * FROM `" . $this->table . "` WHERE `{$column}` {$operator} ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$value]);
        return $stmt->fetchAll();
    }

    /**
     * Count records
     */
    public function count(): int
    {
        $sql = "SELECT COUNT(*) as total FROM `" . $this->table . "`";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return (int) $stmt->fetch()['total'];
    }

    /**
     * Filter fillable attributes
     */
    protected function filterFillable(array $data): array
    {
        if (empty($this->fillable)) {
            return $data;
        }
        
        return array_intersect_key($data, array_flip($this->fillable));
    }

    /**
     * Get table name
     */
    public function getTable(): string
    {
        return $this->table;
    }
}
