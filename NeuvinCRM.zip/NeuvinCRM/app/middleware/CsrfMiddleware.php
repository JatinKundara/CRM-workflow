<?php
namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\CSRF;

/**
 * CSRF Protection Middleware
 */
class CsrfMiddleware
{
    public function handle(Request $request, Response $response): void
    {
        // Skip CSRF check for safe methods and API requests
        if (in_array($request->getMethod(), ['GET', 'HEAD', 'OPTIONS'])) {
            return;
        }

        // Skip API requests (JWT protected)
        if (str_starts_with($request->getPath(), '/api/')) {
            return;
        }

        if (!CSRF::verifyRequest($request)) {
            $response->setStatusCode(419);
            $response->json(['error' => 'CSRF token validation failed']);
        }
    }
}
