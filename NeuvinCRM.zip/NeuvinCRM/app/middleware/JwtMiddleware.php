<?php
namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Core\JWTAuth;

/**
 * JWT Middleware for API routes
 */
class JwtMiddleware
{
    public function handle(Request $request, Response $response): void
    {
        if (!JWTAuth::verify($request)) {
            $response->setStatusCode(401);
            $response->json(['error' => 'Unauthorized - Invalid or missing token']);
        }
    }
}
