<?php
namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;
use App\Services\AuthService;

/**
 * Authentication Middleware
 */
class AuthMiddleware
{
    public function handle(Request $request, Response $response): void
    {
        $authService = new AuthService();
        
        if (!$authService->isAuthenticated()) {
            if ($request->isAjax()) {
                $response->setStatusCode(401);
                $response->json(['error' => 'Unauthorized']);
            } else {
                // Redirect using BASE_PATH
                $loginUrl = BASE_PATH . '/login';
                $response->redirect($loginUrl);
            }
        }
    }
}
