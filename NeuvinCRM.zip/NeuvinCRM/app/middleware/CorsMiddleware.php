<?php
namespace App\Middleware;

use App\Core\Request;
use App\Core\Response;

/**
 * CORS Middleware
 */
class CorsMiddleware
{
    public function handle(Request $request, Response $response): void
    {
        $allowedOrigins = [
            'http://localhost',
            'http://localhost:3000',
            'http://localhost:8000'
        ];

        $origin = $request->getHeader('Origin');
        
        if ($origin && in_array($origin, $allowedOrigins)) {
            $response->setHeader('Access-Control-Allow-Origin', $origin);
            $response->setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
            $response->setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-CSRF-Token');
            $response->setHeader('Access-Control-Allow-Credentials', 'true');
        }

        if ($request->getMethod() === 'OPTIONS') {
            $response->setStatusCode(200);
            exit;
        }
    }
}
