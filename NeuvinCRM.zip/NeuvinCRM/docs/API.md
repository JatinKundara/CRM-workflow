# NeuvinCRM REST API Documentation

## Base URL
```
http://localhost/neuvincrm/public/api/v1
```

## Authentication

All API requests (except login) require JWT token in Authorization header:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## Response Format

### Success Response (200/201)
```json
{
  "success": true,
  "data": {...}
}
```

### Error Response (4xx/5xx)
```json
{
  "success": false,
  "error": "Error message",
  "errors": {
    "field": ["Validation error message"]
  }
}
```

---

## Authentication Endpoints

### Login
**POST** `/auth/login`

**Request:**
```json
{
  "email": "admin@neuvincrm.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "name": "Admin",
    "email": "admin@neuvincrm.com",
    "role": "Admin"
  },
  "expires_in": 86400
}
```

### Logout
**POST** `/auth/logout`

### Refresh Token
**POST** `/auth/refresh`

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

## Leads Endpoints

### List Leads
**GET** `/leads`

**Query Parameters:**
- `page` - Page number (default: 1)
- `per_page` - Items per page (default: 20)
- `status` - Filter by status (qualified, unqualified)
- `source` - Filter by source (website, referral, etc.)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "first_name": "John",
      "last_name": "Doe",
      "email": "john@example.com",
      "phone": "+1234567890",
      "company": "ACME Corp",
      "status": "qualified",
      "source": "website",
      "assigned_to": 2,
      "estimated_value": 50000,
      "created_at": "2024-01-15 10:30:00"
    }
  ],
  "total": 1,
  "page": 1,
  "per_page": 20
}
```

### Get Specific Lead
**GET** `/leads/{id}`

### Create Lead
**POST** `/leads`

**Request:**
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john@example.com",
  "phone": "+1234567890",
  "company": "ACME Corp",
  "source": "website",
  "estimated_value": 50000
}
```

### Update Lead
**PUT** `/leads/{id}`

**Request:**
```json
{
  "status": "qualified",
  "assigned_to": 2
}
```

### Delete Lead
**DELETE** `/leads/{id}`

---

## Customers Endpoints

### List Customers
**GET** `/customers`

### Get Specific Customer
**GET** `/customers/{id}`

### Create Customer
**POST** `/customers`

**Request:**
```json
{
  "first_name": "Jane",
  "last_name": "Smith",
  "email": "jane@example.com",
  "phone": "+9876543210",
  "company": "Tech Corp",
  "billing_address": "123 Main St",
  "billing_city": "New York",
  "billing_state": "NY",
  "billing_zip": "10001",
  "billing_country": "USA"
}
```

### Update Customer
**PUT** `/customers/{id}`

### Delete Customer
**DELETE** `/customers/{id}`

---

## Invoices Endpoints

### List Invoices
**GET** `/invoices`

**Query Parameters:**
- `status` - paid, pending, overdue, cancelled
- `customer_id` - Filter by customer

### Get Specific Invoice
**GET** `/invoices/{id}`

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "invoice_number": "INV-001",
    "customer_id": 5,
    "customer_name": "Jane Smith",
    "invoice_date": "2024-01-15",
    "due_date": "2024-02-15",
    "total": 5000,
    "paid_amount": 0,
    "status": "pending",
    "items": [
      {
        "product_id": 1,
        "product_name": "Product A",
        "quantity": 2,
        "unit_price": 2500,
        "line_total": 5000
      }
    ],
    "created_at": "2024-01-15 10:30:00"
  }
}
```

### Create Invoice
**POST** `/invoices`

**Request:**
```json
{
  "customer_id": 5,
  "invoice_date": "2024-01-15",
  "due_date": "2024-02-15",
  "items": [
    {
      "product_id": 1,
      "quantity": 2,
      "unit_price": 2500
    }
  ],
  "tax_percentage": 10,
  "discount_percentage": 0
}
```

### Send Invoice
**POST** `/invoices/{id}/send`

Sends invoice to customer email.

### Update Invoice
**PUT** `/invoices/{id}`

**Request:**
```json
{
  "status": "paid",
  "paid_amount": 5000
}
```

### Delete Invoice
**DELETE** `/invoices/{id}`

---

## Products Endpoints

### List Products
**GET** `/products`

**Query Parameters:**
- `category_id` - Filter by category
- `low_stock` - Boolean, show only low stock items

### Get Specific Product
**GET** `/products/{id}`

### Create Product
**POST** `/products`

**Request:**
```json
{
  "name": "Product A",
  "sku": "SKU-001",
  "category_id": 1,
  "description": "Product description",
  "unit_price": 99.99,
  "current_stock": 100,
  "reorder_level": 20,
  "reorder_quantity": 50
}
```

### Update Product
**PUT** `/products/{id}`

### Delete Product
**DELETE** `/products/{id}`

---

## Employees Endpoints

### List Employees
**GET** `/employees`

### Get Specific Employee
**GET** `/employees/{id}`

### Create Employee
**POST** `/employees`

**Request:**
```json
{
  "first_name": "Bob",
  "last_name": "Johnson",
  "email": "bob@example.com",
  "phone": "+1111111111",
  "department_id": 1,
  "designation": "Manager",
  "joining_date": "2024-01-01",
  "salary": 50000
}
```

### Update Employee
**PUT** `/employees/{id}`

### Delete Employee
**DELETE** `/employees/{id}`

---

## Reports Endpoints

### Sales Pipeline Report
**GET** `/reports/sales`

**Response:**
```json
{
  "success": true,
  "data": {
    "prospect": {
      "count": 10,
      "total": 500000
    },
    "negotiation": {
      "count": 5,
      "total": 250000
    },
    "proposal": {
      "count": 3,
      "total": 150000
    },
    "closed_won": {
      "count": 8,
      "total": 400000
    },
    "total": 1300000
  }
}
```

### Revenue Report
**GET** `/reports/revenue`

**Response:**
```json
{
  "success": true,
  "data": {
    "total_revenue": 150000,
    "paid": 100000,
    "pending": 50000,
    "overdue": 10000
  }
}
```

### Inventory Report
**GET** `/reports/inventory`

**Response:**
```json
{
  "success": true,
  "data": {
    "total_products": 50,
    "low_stock_items": [
      {
        "id": 1,
        "name": "Product A",
        "current_stock": 5,
        "reorder_level": 20
      }
    ],
    "low_stock_count": 3
  }
}
```

---

## Error Codes

| Code | Message | Meaning |
|------|---------|---------|
| 200 | OK | Request successful |
| 201 | Created | Resource created successfully |
| 400 | Bad Request | Invalid request data |
| 401 | Unauthorized | Authentication required or invalid token |
| 403 | Forbidden | User lacks permission |
| 404 | Not Found | Resource not found |
| 422 | Validation Error | Validation failed |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Server Error | Internal server error |

---

## Rate Limiting

API requests are rate limited to 100 requests per minute per IP address.

Headers:
```
X-Rate-Limit-Limit: 100
X-Rate-Limit-Remaining: 95
X-Rate-Limit-Reset: 1642234800
```

---

## Examples Using cURL

### Login
```bash
curl -X POST http://localhost/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@neuvincrm.com",
    "password": "password123"
  }'
```

### List Leads
```bash
TOKEN="your-jwt-token-here"

curl -X GET "http://localhost/api/v1/leads?page=1" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json"
```

### Create Invoice
```bash
TOKEN="your-jwt-token-here"

curl -X POST http://localhost/api/v1/invoices \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": 5,
    "invoice_date": "2024-01-15",
    "due_date": "2024-02-15",
    "items": [
      {
        "product_id": 1,
        "quantity": 2,
        "unit_price": 2500
      }
    ]
  }'
```

### Get Sales Report
```bash
TOKEN="your-jwt-token-here"

curl -X GET http://localhost/api/v1/reports/sales \
  -H "Authorization: Bearer $TOKEN"
```

---

## Examples Using Python

```python
import requests
import json

BASE_URL = 'http://localhost/api/v1'

# Login
response = requests.post(f'{BASE_URL}/auth/login', json={
    'email': 'admin@neuvincrm.com',
    'password': 'password123'
})

data = response.json()
token = data['token']

# List leads
headers = {
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json'
}

response = requests.get(f'{BASE_URL}/leads', headers=headers)
leads = response.json()

print(leads)
```

---

## Examples Using JavaScript

```javascript
const baseURL = 'http://localhost/api/v1';

// Login
async function login() {
  const response = await fetch(`${baseURL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: 'admin@neuvincrm.com',
      password: 'password123'
    })
  });

  const data = await response.json();
  return data.token;
}

// Get leads
async function getLeads(token) {
  const response = await fetch(`${baseURL}/leads`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  });

  return await response.json();
}

// Usage
const token = await login();
const leads = await getLeads(token);
console.log(leads);
```

---

## Webhook Events

Subscribe to real-time events: (Coming Soon)

- `invoice.created`
- `invoice.paid`
- `lead.converted`
- `deal.stage_changed`
- `inventory.low_stock`

---

## Changelog

### Version 1.0.0 (2024-01-15)
- Initial API release
- Authentication endpoints
- Basic CRUD operations
- Reports endpoints
- Rate limiting

---

For more help, visit: https://docs.neuvincrm.com
