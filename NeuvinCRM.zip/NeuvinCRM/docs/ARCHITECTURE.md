# 🏗️ NeuvinCRM - Project Architecture

## System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Browser / API Client                 │
└──────────────────────┬──────────────────────────────────┘
                       │ HTTP/HTTPS
┌──────────────────────▼──────────────────────────────────┐
│              Web Server (Apache/Nginx)                  │
│  ┌────────────────────────────────────────────────────┐ │
│  │ public/index.php (Front Controller)                │ │
│  └────────────────────────────────────────────────────┘ │
└──────────────────────┬──────────────────────────────────┘
                       │ PHP Execution
┌──────────────────────▼──────────────────────────────────┐
│         Application\Core\Application (Bootstrap)        │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Routes (routes/web.php, routes/api.php)           │ │
│  │         ↓                                          │ │
│  │ Router (Route Matching & Dispatch)                │ │
│  │         ↓                                          │ │
│  │ Middleware Chain (Auth, CSRF, JWT, CORS)         │ │
│  │         ↓                                          │ │
│  │ Controller Action (Request Handling)              │ │
│  │         ↓                                          │ │
│  │ Services (Business Logic)                         │ │
│  │         ↓                                          │ │
│  │ Models (Data Access)                              │ │
│  │         ↓                                          │ │
│  │ Response (View/JSON)                              │ │
│  └────────────────────────────────────────────────────┘ │
└──────────────────────┬──────────────────────────────────┘
                       │ PDO Queries
┌──────────────────────▼──────────────────────────────────┐
│          MySQL Database (app/database/*.php)            │
│  ┌────────────────────────────────────────────────────┐ │
│  │ Tables: users, leads, customers, invoices, etc.   │ │
│  └────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

## Layer Architecture

### 1. Presentation Layer
**Files:** `/app/views/`, `/public/`

- HTML/Bootstrap templates
- View rendering
- Frontend assets (CSS, JS, images)
- User interface

### 2. Controller Layer
**Files:** `/app/controllers/`, `/app/controllers/Api/`

- Request handling
- Input validation
- Response formatting
- Business logic orchestration

### 3. Service Layer
**Files:** `/app/services/`

- Business logic implementation
- Data transformation
- External integrations (email, payment)
- Reusable operations

### 4. Model Layer
**Files:** `/app/models/`

- Data access objects
- Database queries (CRUD)
- Model relationships
- Data validation

### 5. Database Layer
**Files:** `/app/core/Database.php`, `/database/`

- Connection management
- Query execution
- Transaction handling
- Schema definition

### 6. Support Layers

**Middleware:** `/app/middleware/`
- Request preprocessing
- Authentication
- Authorization
- CORS, CSRF

**Routing:** `/routes/`
- URL pattern matching
- Controller method binding
- Middleware assignment

**Helpers:** `/app/helpers/`
- Utility functions
- Date/currency formatting
- Common operations

**Configuration:** `/config/`
- Application constants
- Database configuration
- Roles & permissions

---

## Request Flow Diagram

```
1. Browser Request
   ↓
2. Web Server Routes to public/index.php
   ↓
3. Application::getInstance()->run()
   ↓
4. Session & Environment Setup
   ↓
5. Router Matches URL to Route
   ↓
6. Middleware Chain Execution
   - CorsMiddleware (add headers)
   - CsrfMiddleware (validate token)
   - AuthMiddleware (check login)
   - JwtMiddleware (validate JWT)
   ↓
7. Controller Action Called
   ↓
8. Request Validation
   ↓
9. Service Layer Processing
   ↓
10. Model Database Operations
    ↓
11. Response Generated
    - View (HTML) for web routes
    - JSON for API routes
    ↓
12. Response Sent to Browser
```

---

## Component Interaction

### Creating a Lead (Web Flow)

```
User Browser
    ↓
POST /crm/leads (form data)
    ↓
LeadController::store()
    ↓
Validation (email, required fields)
    ↓
AuthService::checkPermission('leads.create')
    ↓
Lead::create(['first_name', 'last_name', ...])
    ↓
Database INSERT into leads table
    ↓
Logger::audit('lead_created')
    ↓
Session::flash('success', 'Lead created')
    ↓
Redirect to /crm/leads
    ↓
LeadController::index() displays list
```

---

## Database Schema Relationships

```
users (1) ──────────────────(∞) leads
  ├─ assigned_to                 ├─ converted_customer_id
  └─ id                          └─ lead_id

users (1) ──────────────────(∞) deals
  ├─ assigned_to                 ├─ owner_id
  └─ id                          └─ deal_id

users (1) ──────────────────(∞) employees
  └─ id                          └─ employee_id

customers (1) ──────────────(∞) deals
  └─ id                          └─ customer_id

customers (1) ──────────────(∞) invoices
  └─ id                          └─ customer_id

invoices (1) ──────────────(∞) invoice_items
  └─ id                          └─ invoice_id

products (1) ──────────────(∞) invoice_items
  └─ id                          └─ product_id

roles (1) ──────────────(∞) users
  └─ id                          └─ role_id

roles (∞) ────────────(∞) permissions
  └─ via role_permissions table

employees (1) ──────────────(∞) attendance
  └─ id                          └─ employee_id

vendors (1) ──────────────(∞) purchase_orders
  └─ id                          └─ vendor_id
```

---

## Class Relationships

### Core Framework Classes

```
Application (Singleton)
├── Router
│   └── routes/web.php
│   └── routes/api.php
├── Request
├── Response
├── Database (Singleton)
├── Session
└── Logger (Audit)

Controller (Base)
├── Web Controllers
│   ├── LeadController
│   ├── CustomerController
│   ├── InvoiceController
│   └── ...
└── Api Controllers
    ├── Api\LeadController
    ├── Api\InvoiceController
    └── ...

Model (Base)
├── Lead
├── Customer
├── Invoice
├── Product
└── ...

Middleware (Chain)
├── CsrfMiddleware
├── AuthMiddleware
├── JwtMiddleware
└── CorsMiddleware

Service
├── AuthService
├── PermissionService
└── EmailService
```

---

## Configuration Management

### Environment Variables (`.env`)
```env
APP_ENV=production
APP_DEBUG=false
JWT_SECRET=secret-key
DB_HOST=localhost
DB_NAME=neuvincrm
MAIL_DRIVER=smtp
```

### Application Constants (`config/constants.php`)
```php
define('APP_NAME', 'NeuvinCRM');
define('ITEMS_PER_PAGE', 20);
define('JWT_EXPIRATION', 86400);
define('BRUTE_FORCE_LIMIT', 5);
```

### Role-Based Configuration (`config/roles.php`)
```php
'admin' => ['permissions' => ['*']], // All permissions
'sales' => ['permissions' => ['leads.*', 'deals.*']],
```

---

## Security Architecture

### Authentication
1. Login form submits email/password
2. AuthService verifies password against bcrypt hash
3. Session created or JWT token issued
4. Session/Token stored in $_SESSION or Authorization header

### Authorization
1. Request reaches AuthMiddleware
2. Middleware checks session/JWT validity
3. PermissionService checks user's role permissions
4. Controller calls `$this->authorize('permission.name')`
5. Access denied → 403 Forbidden response

### Data Protection
1. **SQL Injection:** Prepared statements with parameterized queries
2. **XSS:** Output sanitization with htmlspecialchars()
3. **CSRF:** Token generation on form, verification on POST
4. **Password:** Bcrypt hashing with cost 12
5. **API:** JWT with HS256 algorithm, 24-hour expiration

### Audit Trail
1. All user actions logged to `audit_logs` table
2. Tracked fields: user_id, action, module, ip_address, user_agent, timestamp
3. Accessible via Logger::audit() helper

---

## Caching Strategy

### Database Connection
- Singleton pattern ensures one connection per request
- Connection pooling possible via web server

### Session
- PHP native sessions (file or database backend)
- Flash messages cleared after display
- Token stored in session for CSRF

### Computed Data
- Models cache calculated fields (getFullName(), etc.)
- Reports can cache via Redis (optional)

---

## Extension Points

### Adding Custom Controller
```php
// Create controller
class OrderController extends Controller {
    public function index() { ... }
}

// Register route in routes/web.php
$router->post('/orders', 'OrderController@store');
```

### Adding Custom Model
```php
// Create model
class Order extends Model {
    protected string $table = 'orders';
    protected array $fillable = ['...']; 
}
```

### Adding Custom Permission
```php
// In config/roles.php
'orders.create',
'orders.edit',
'orders.delete'

// In controller
$this->authorize('orders.create');
```

### Adding Custom Middleware
```php
// Create middleware class
class CustomMiddleware {
    public function execute($next) {
        // Pre-processing
        $response = $next();
        // Post-processing
        return $response;
    }
}
```

---

## Performance Optimizations

### Database
- Indexed columns on foreign keys
- Indexed columns on frequently filtered fields
- Proper use of LIMIT clause
- Connection pooling ready

### Caching
- Session storage optimization
- Assets served from CDN ready
- Gzip compression ready
- ETag support for static files

### Code
- Lazy loading of services
- Dependency injection ready
- Model query optimization
- Prepared statement caching

---

## Deployment Considerations

### Source Control
- Include: source code, composer.json, config examples
- Exclude: .env (use .env.example), /storage, /node_modules

### Environment Setup
- Development: APP_DEBUG=true, APP_ENV=development
- Staging: Mixed logging, JWT testing
- Production: APP_DEBUG=false, APP_ENV=production

### File Permissions
```bash
chmod 755 -R /app                    # App code readable
chmod 777 /storage                   # Write logs
chmod 777 /public/assets             # Write uploads
```

### SSL/HTTPS
- Required in production
- Let's Encrypt certificates recommended
- Auto-renewal via certbot

### Monitoring
- Error log monitoring
- Query performance logging
- User action audit trail
- Uptime monitoring

---

**Architecture Version:** 1.0  
**Last Updated:** April 12, 2024
