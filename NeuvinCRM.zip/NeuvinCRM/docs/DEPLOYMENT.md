# 🚢 NeuvinCRM - Production Deployment Guide

## Pre-Deployment Checklist

### Security ✅
```
□ Change JWT_SECRET in .env to 32+ character random string
□ Update admin password from default
□ Set APP_ENV=production
□ Set APP_DEBUG=false
□ Delete installer.php from server
□ Enable HTTPS (SSL/TLS certificate)
□ Set X-Frame-Options header (prevent clickjacking)
□ Set X-Content-Type-Options header (prevent MIME sniffing)
□ Set X-XSS-Protection header (enable XSS filter)
□ Configure strong Content-Security-Policy
□ Disable directory listing in web server
□ Set proper file permissions (755 for dirs, 644 for files)
□ Exclude .env from version control
□ Configure secure password policy
□ Enable two-factor authentication (ready for implementation)
□ Set up database backups
□ Configure log rotation
□ Review and restrict debug log visibility
```

### Performance ✅
```
□ Enable PHP OpCache
□ Configure MySQL query cache
□ Add database indexes for filtered columns
□ Configure web server compression (gzip)
□ Set up CDN for static assets
□ Enable browser caching headers
□ Optimize database connections
□ Configure connection pooling
□ Set up Redis for session storage (optional)
□ Test under expected load
□ Configure auto-scaling if using cloud
```

### Monitoring & Logging ✅
```
□ Configure error logging to file
□ Set up application performance monitoring (APM)
□ Configure uptime monitoring
□ Set up alerts for critical errors
□ Enable audit logging
□ Configure log aggregation (ELK, Splunk, etc.)
□ Set up database monitoring
□ Monitor disk space usage
□ Monitor memory usage
□ Set up backup verification alerts
```

### Backup & Recovery ✅
```
□ Configure automated daily backups
□ Test backup restoration procedure
□ Store backups off-site
□ Document recovery procedure
□ Set up backup verification
□ Configure incremental backups
□ Test disaster recovery plan
```

---

## Server Setup - Apache

### 1. Install Required Packages

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install apache2 php8.5 php8.5-mysql php8.5-mbstring php8.5-curl php8.5-json
sudo apt-get install mysql-server composer

# Enable required Apache modules
sudo a2enmod rewrite
sudo a2enmod ssl
sudo a2enmod headers
sudo systemctl restart apache2
```

### 2. Create Virtual Host

**File:** `/etc/apache2/sites-available/neuvincrm.conf`

```apache
<VirtualHost *:80>
    ServerName neuvincrm.example.com
    ServerAdmin admin@neuvincrm.example.com
    DocumentRoot /var/www/neuvincrm/public

    # Redirect to HTTPS
    Redirect permanent / https://neuvincrm.example.com/

    # Logging
    ErrorLog ${APACHE_LOG_DIR}/neuvincrm-error.log
    CustomLog ${APACHE_LOG_DIR}/neuvincrm-access.log combined
</VirtualHost>

<VirtualHost *:443>
    ServerName neuvincrm.example.com
    ServerAdmin admin@neuvincrm.example.com
    DocumentRoot /var/www/neuvincrm/public

    # SSL Configuration
    SSLEngine on
    SSLCertificateFile /etc/ssl/certs/neuvincrm.crt
    SSLCertificateKeyFile /etc/ssl/private/neuvincrm.key
    SSLCertificateChainFile /etc/ssl/certs/neuvincrm.ca-bundle

    # Security Headers
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"

    <Directory /var/www/neuvincrm/public>
        AllowOverride All
        Require all granted

        # Rewrite rules for pretty URLs
        <IfModule mod_rewrite.c>
            RewriteEngine On
            RewriteCond %{REQUEST_FILENAME} !-f
            RewriteCond %{REQUEST_FILENAME} !-d
            RewriteRule ^(.*)$ index.php [QSA,L]
        </IfModule>
    </Directory>

    # Logging
    ErrorLog ${APACHE_LOG_DIR}/neuvincrm-error.log
    CustomLog ${APACHE_LOG_DIR}/neuvincrm-access.log combined
</VirtualHost>
```

### 3. Enable Site & Configure Permissions

```bash
# Enable site
sudo a2ensite neuvincrm.conf
sudo apache2ctl configtest  # Should return "Syntax OK"
sudo systemctl restart apache2

# Set permissions
sudo chown -R www-data:www-data /var/www/neuvincrm
sudo chmod -R 755 /var/www/neuvincrm
sudo chmod -R 777 /var/www/neuvincrm/storage
sudo chmod -R 777 /var/www/neuvincrm/public/assets
```

### 4. Install SSL Certificate (Let's Encrypt)

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-apache

# Generate certificate
sudo certbot -a apache -i apache -d neuvincrm.example.com

# Auto-renewal
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer
```

---

## Server Setup - Nginx

### 1. Install Required Packages

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install nginx php8.5-fpm php8.5-mysql php8.5-mbstring php8.5-curl php8.5-json
sudo apt-get install mysql-server composer
```

### 2. Create Server Block

**File:** `/etc/nginx/sites-available/neuvincrm`

```nginx
# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name neuvincrm.example.com;
    return 301 https://$server_name$request_uri;
}

# Main HTTPS server block
server {
    listen 443 ssl http2;
    server_name neuvincrm.example.com;
    root /var/www/neuvincrm/public;
    index index.php;

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/neuvincrm.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/neuvincrm.example.com/privkey.pem;

    # SSL Settings
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Logging
    access_log /var/log/nginx/neuvincrm-access.log;
    error_log /var/log/nginx/neuvincrm-error.log;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript;

    # PHP location
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.5-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # Deny access to hidden files
    location ~ /\. {
        deny all;
    }

    # Pretty URLs
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
}
```

### 3. Enable & Test

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/neuvincrm /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx

# Enable and start PHP-FPM
sudo systemctl enable php8.5-fpm
sudo systemctl start php8.5-fpm
```

---

## Database Setup

### 1. Create Database & User

```bash
# Connect to MySQL as root
mysql -u root -p

# Create database
CREATE DATABASE neuvincrm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Create user with limited privileges
CREATE USER 'neuvin_user'@'localhost' IDENTIFIED BY 'strong_password_here';
GRANT ALL PRIVILEGES ON neuvincrm.* TO 'neuvin_user'@'localhost';
GRANT CREATE, ALTER, DROP ON neuvincrm.* TO 'neuvin_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 2. Run Migrations & Seeding

```bash
cd /var/www/neuvincrm

# Install PHP dependencies
composer install --no-dev --optimize-autoloader

# Copy and edit environment file
cp .env.example .env
nano .env  # Update DB credentials

# Run migrations (creates tables)
php database/migrations/Migration.php

# Seed database (add initial data)
php database/seeders/DatabaseSeeder.php
```

### 3. MySQL Optimization

**File:** `/etc/mysql/mysql.conf.d/mysqld.cnf`

```ini
# Connection pool
max_connections = 100
max_allowed_packet = 256M

# Query cache
query_cache_type = 1
query_cache_size = 256M

# InnoDB
innodb_buffer_pool_size = 1G
innodb_log_file_size = 256M

# Slow query logging
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow.log
long_query_time = 2
```

---

## Application Configuration

### 1. Environment File

**File:** `/var/www/neuvincrm/.env`

```env
# Application
APP_ENV=production
APP_DEBUG=false
APP_NAME=NeuvinCRM

# Database
DB_HOST=localhost
DB_NAME=neuvincrm
DB_USER=neuvin_user
DB_PASS=strong_password_here
DB_PORT=3306

# Security
JWT_SECRET=generate-with-openssl-rand-hex-32

# Email (SMTP)
MAIL_DRIVER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=app-specific-password
MAIL_FROM=noreply@neuvincrm.example.com
MAIL_FROM_NAME=NeuvinCRM

# Session
SESSION_NAME=NEUVINCRM_SESSION
SESSION_TIMEOUT=3600

# API
API_RATE_LIMIT=100
API_RATE_WINDOW=60
```

### 2. Generate JWT Secret

```bash
# Generate random secret
openssl rand -hex 32

# Output example: a1b2c3d4e5f6...
# Copy to JWT_SECRET in .env
```

---

## Cron Jobs Setup

### 1. Create Cron Scripts

**File:** `/var/www/neuvincrm/cron/recurring-invoices.php`

```php
<?php
// Generate recurring invoices daily
require_once dirname(__DIR__) . '/config/constants.php';
require_once dirname(__DIR__) . '/vendor/autoload.php';

// Run recurring invoice generation
$invoiceService = new \App\Services\InvoiceService();
$invoiceService->generateRecurringInvoices();

// Log execution
error_log(date('Y-m-d H:i:s') . ' - Recurring invoices generated');
```

### 2. Add to Crontab

```bash
# Edit crontab
sudo crontab -u www-data -e

# Add these lines:

# Generate recurring invoices daily at 2 AM
0 2 * * * /usr/bin/php /var/www/neuvincrm/cron/recurring-invoices.php

# Generate payroll monthly on 1st at 3 AM
0 3 1 * * /usr/bin/php /var/www/neuvincrm/cron/generate-payroll.php

# Cleanup old logs daily at 4 AM
0 4 * * * /usr/bin/php /var/www/neuvincrm/cron/cleanup-logs.php

# Database backup daily at 1 AM
0 1 * * * /usr/bin/php /var/www/neuvincrm/cron/backup-database.php
```

---

## Backup Strategy

### 1. Database Backup Script

**File:** `/var/www/neuvincrm/cron/backup-database.php`

```php
<?php
$date = date('Y-m-d-H-i-s');
$backupDir = '/var/backups/neuvincrm';
$backupFile = "$backupDir/neuvincrm_$date.sql.gz";

// Create backup directory if not exists
@mkdir($backupDir, 0750, true);

// Backup database
$cmd = sprintf(
    "mysqldump -u%s -p%s %s | gzip > %s",
    escapeshellarg($_ENV['DB_USER']),
    escapeshellarg($_ENV['DB_PASS']),
    escapeshellarg($_ENV['DB_NAME']),
    escapeshellarg($backupFile)
);

exec($cmd, $output, $return);

if ($return === 0) {
    error_log("✓ Database backup created: $backupFile");
} else {
    error_log("✗ Database backup failed");
}

// Delete backups older than 30 days
$files = glob("$backupDir/*.sql.gz");
foreach ($files as $file) {
    if (filemtime($file) < time() - (30 * 24 * 60 * 60)) {
        unlink($file);
    }
}
```

### 2. Filesystem Backup

```bash
#!/bin/bash
# Create filesystem backup
tar -czf /var/backups/neuvincrm-files-$(date +%Y-%m-%d).tar.gz \
  /var/www/neuvincrm \
  --exclude=/var/www/neuvincrm/storage/logs \
  --exclude=/var/www/neuvincrm/storage/cache

# Keep only last 7 days of backups
find /var/backups -name "neuvincrm-files-*.tar.gz" -mtime +7 -delete
```

---

## Monitoring & Logging

### 1. PHP Error Logging

**File:** `/etc/php/8.5/fpm/php.ini`

```ini
error_reporting = E_ALL
display_errors = Off
log_errors = On
error_log = /var/log/php-fpm-errors.log
```

### 2. Nginx Access Logs

```bash
# Real-time log monitoring
tail -f /var/log/nginx/neuvincrm-access.log

# Parse access logs
awk '{print $1}' /var/log/nginx/neuvincrm-access.log | sort | uniq -c | sort -rn

# Slow requests (>1s response time)
awk '$NF > 1 {print}' /var/log/nginx/neuvincrm-access.log
```

### 3. Application Logging

Logs are written to `/var/www/neuvincrm/storage/logs/`:
- `info.log` - Informational messages
- `warning.log` - Warning messages
- `error.log` - Error messages
- `critical.log` - Critical errors
- `audit.log` - User action audit trail (JSON)

### 4. Log Rotation

**File:** `/etc/logrotate.d/neuvincrm`

```
/var/www/neuvincrm/storage/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
}
```

---

## Performance Tuning

### PHP OpCache

**File:** `/etc/php/8.5/fpm/php.ini`

```ini
opcache.enable = 1
opcache.enable_cli = 0
opcache.memory_consumption = 128
opcache.interned_strings_buffer = 16
opcache.max_accelerated_files = 4000
opcache.max_wasted_percentage = 5
opcache.validate_timestamps = 0
opcache.revalidate_freq = 0
```

### MySQL Optimization

```sql
-- Add missing indexes
ALTER TABLE leads ADD INDEX idx_status (status);
ALTER TABLE leads ADD INDEX idx_source (source);
ALTER TABLE leads ADD INDEX idx_assigned_to (assigned_to);
ALTER TABLE invoices ADD INDEX idx_status (status);
ALTER TABLE invoices ADD INDEX idx_customer_id (customer_id);
ALTER TABLE products ADD INDEX idx_category_id (category_id);

-- Analyze tables
ANALYZE TABLE leads;
ANALYZE TABLE customers;
ANALYZE TABLE invoices;
```

### Nginx Performance

```nginx
# Connection pooling
keepalive_timeout 65;
keepalive_requests 100;

# Buffer optimization
client_body_buffer_size 128k;
client_max_body_size 10m;

# Worker processes (match CPU cores)
worker_processes auto;
worker_connections 1024;
```

---

## Security Hardening

### 1. Firewall Setup

```bash
sudo ufw enable
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Allow SSH, HTTP, HTTPS
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Allow MySQL only from localhost
sudo ufw allow from 127.0.0.1 to any port 3306
```

### 2. Auto Security Updates

```bash
# Enable unattended upgrades
sudo apt install unattended-upgrades apt-listchanges
sudo dpkg-reconfigure -plow unattended-upgrades
```

### 3. Fail2Ban (Brute Force Protection)

```bash
# Install
sudo apt install fail2ban

# Create local configuration
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local

# Configure for web application
sudo systemctl restart fail2ban
```

---

## Monitoring Commands

```bash
# System resources
top                          # RealTime process monitor
htop                         # Human-friendly top
iostat                       # I/O statistics
vmstat                       # Virtual memory statistics

# Disk usage
df -h                        # Overall disk usage
du -sh /var/www/neuvincrm    # Application size
du -sh /var/backups          # Backup size

# Network connections
netstat -tuln                # Open ports
ss -s                        # Socket statistics

# MySQL status
mysql -u root -p -e "SHOW STATUS LIKE '%'"
mysql -u root -p -e "SHOW PROCESSLIST"

# Check PHP-FPM
systemctl status php8.5-fpm
ps aux | grep php-fpm
```

---

## Troubleshooting

### Problem: 500 Internal Server Error

```bash
# Check error logs
tail -f /var/log/nginx/neuvincrm-error.log
tail -f /var/log/php-fpm-errors.log

# Check file permissions
ls -la /var/www/neuvincrm/storage
ls -la /var/www/neuvincrm/public/assets

# Check PHP syntax
php -l /var/www/neuvincrm/public/index.php
```

### Problem: Database Connection Timeout

```bash
# Check MySQL status
sudo systemctl status mysql

# Check connection limits
mysql -u root -p -e "SHOW VARIABLES LIKE 'max_connections'"

# Check current connections
mysql -u root -p -e "SHOW PROCESSLIST\G"
```

### Problem: High CPU Usage

```bash
# Identify process
top -b -n 1 | head -20

# Check slow queries
mysql -u root -p -e "SELECT * FROM INFORMATION_SCHEMA.PROCESSLIST WHERE COMMAND != 'Sleep'\G"

# Check PHP processes
ps aux | grep php
```

---

## Performance Testing

```bash
# Using Apache Bench
ab -n 1000 -c 100 https://neuvincrm.example.com/

# Using wrk (better concurrency)
wrk -t12 -c400 -d30s https://neuvincrm.example.com/

# Using load testing tool
locust -f locustfile.py --host=https://neuvincrm.example.com
```

---

## Maintenance Tasks

### Monthly
- [ ] Review error logs for patterns
- [ ] Check disk space usage
- [ ] Verify backups are working
- [ ] Test backup restoration

### Quarterly
- [ ] Performance optimization review
- [ ] Security audit
- [ ] Update dependencies
- [ ] Review user access logs

### Yearly
- [ ] Full security audit
- [ ] Capacity planning
- [ ] Disaster recovery drill
- [ ] License/contract renewal

---

**Version:** 1.0.0  
**Last Updated:** April 12, 2024
