<?php

/**
 * Root PHP Test Page (Safe Version)
 */

declare(strict_types=1);

/* Detect base path automatically */
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$baseUrl  = $basePath === '' ? '/' : $basePath . '/';

/* Helper for safe output */
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* Detect if running locally */
$isLocal = in_array($_SERVER['SERVER_NAME'], ['localhost', '127.0.0.1']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>PHP Test</title>

    <style>
        body {
            font-family: Arial;
            padding: 20px;
            background: #f0f0f0
        }

        .box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            max-width: 600px;
            margin: 20px auto;
            box-shadow: 0 2px 10px rgba(0, 0, 0, .1)
        }

        .success {
            color: green;
            font-size: 18px;
            font-weight: bold
        }

        .version {
            background: #f9f9f9;
            padding: 10px;
            margin: 10px 0;
            border-left: 4px solid #667eea
        }
    </style>
</head>

<body>
    <div class="box">
        <h1>PHP Installation Test</h1>

        <div class="success">✓ PHP is Working!</div>

        <div class="version">
            <strong>PHP Version:</strong> <?= e(PHP_VERSION) ?><br>
            <strong>SAPI:</strong> <?= e(php_sapi_name()) ?><br>

            <?php if ($isLocal): ?>
                <strong>OS:</strong> <?= e(PHP_OS_FAMILY) ?><br>
            <?php endif; ?>
        </div>

        <h3>Next Steps</h3>
        <ul>
            <li><a href="<?= e($baseUrl) ?>php-info.php">PHP Info</a></li>
            <li><a href="<?= e($baseUrl) ?>setup.php">Run Installer</a></li>
            <li><a href="<?= e($baseUrl) ?>">Start Application</a></li>
        </ul>

    </div>
</body>

</html>