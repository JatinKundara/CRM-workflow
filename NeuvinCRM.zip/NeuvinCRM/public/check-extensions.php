<?php
echo "=== PHP Extensions ===\n";
$modules = get_loaded_extensions();
echo "Total Extensions: " . count($modules) . "\n\n";

$pdo_drivers = PDO::getAvailableDrivers();
echo "=== PDO Drivers ===\n";
echo "Available Drivers: " . implode(", ", $pdo_drivers) . "\n";
if (!in_array('mysql', $pdo_drivers)) {
    echo "\n⚠️  WARNING: pdo_mysql driver NOT found!\n";
    echo "This is required to connect to MySQL databases.\n";
}

echo "\n=== All Modules ===\n";
sort($modules);
foreach ($modules as $mod) {
    if (stripos($mod, 'pdo') !== false || stripos($mod, 'mysql') !== false) {
        echo "✓ $mod\n";
    }
}
?>
