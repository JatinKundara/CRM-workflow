<?php
/**
 * Complete System Diagnostic
 */

// Load environment and constants (same as index.php)
$envFile = dirname(__DIR__) . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

require_once dirname(__DIR__) . '/config/constants.php';
require_once dirname(__DIR__) . '/app/helpers/Common.php';

ob_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>NeuvinCRM - System Diagnostic</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        h1 { color: #333; }
        .test { padding: 10px; margin: 10px 0; border-left: 4px solid; }
        .pass { background: #d4edda; border-left-color: #28a745; }
        .fail { background: #f8d7da; border-left-color: #dc3545; }
        .status { font-weight: bold; }
        code { background: #f4f4f4; padding: 2px 5px; border-radius: 3px; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #007bff; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 NeuvinCRM System Diagnostic</h1>

<?php
// Test 1: Environment
echo '<div class="test pass">';
echo '<span class="status">✓ Environment</span><br>';
echo 'PHP Version: ' . phpversion() . '<br>';
echo 'OS: ' . php_uname() . '<br>';
echo '</div>';

// Test 2: Constants
echo '<div class="test ' . (defined('APP_ROOT') && defined('BASE_PATH') ? 'pass' : 'fail') . '">';
echo '<span class="status">' . (defined('APP_ROOT') ? '✓' : '✗') . ' Constants</span><br>';
echo 'APP_ROOT: ' . (defined('APP_ROOT') ? '<code>' . APP_ROOT . '</code>' : '<span style="color:red">NOT DEFINED</span>') . '<br>';
echo 'BASE_PATH: ' . (defined('BASE_PATH') ? '<code>' . BASE_PATH . '</code>' : '<span style="color:red">NOT DEFINED</span>') . '<br>';
echo 'APP_ENV: ' . (defined('APP_ENV') ? APP_ENV : 'Not set') . '<br>';
echo '</div>';

// Test 3: Files
$requiredFiles = [
    'config/constants.php' => APP_ROOT . '/config/constants.php',
    'app/helpers/Common.php' => APP_ROOT . '/app/helpers/Common.php',
    'app/core/Application.php' => APP_ROOT . '/app/core/Application.php',
    'routes/web.php' => APP_ROOT . '/routes/web.php',
];

$allFilesExist = true;
echo '<div class="test pass"><span class="status">✓ Required Files</span><br><table>';
foreach ($requiredFiles as $name => $path) {
    $exists = file_exists($path);
    $allFilesExist = $allFilesExist && $exists;
    echo '<tr><td>' . $name . '</td><td>' . ($exists ? '✓ Exists' : '✗ Missing') . '</td></tr>';
}
echo '</table></div>';

// Test 4: PHP Functions
echo '<div class="test ' . (function_exists('url') ? 'pass' : 'fail') . '">';
echo '<span class="status">' . (function_exists('url') ? '✓' : '✗') . ' Helper Functions</span><br>';
echo 'url() function: ' . (function_exists('url') ? '<span style="color:green">✓ Available</span>' : '<span style="color:red">✗ NOT Available</span>') . '<br>';
echo 'redirect() function: ' . (function_exists('redirect') ? '<span style="color:green">✓ Available</span>' : '<span style="color:red">✗ NOT Available</span>') . '<br>';
echo 'sanitize() function: ' . (function_exists('sanitize') ? '<span style="color:green">✓ Available</span>' : '<span style="color:red">✗ NOT Available</span>') . '<br>';
echo '</div>';

// Test 5: Classes
$requiredClasses = [
    'App\\Core\\Application',
    'App\\Core\\Router',
    'App\\Core\\Request',
    'App\\Core\\Response',
];

echo '<div class="test pass"><span class="status">✓ Core Classes</span><br><table>';
foreach ($requiredClasses as $class) {
    echo '<tr><td>' . $class . '</td><td>' . (class_exists($class) ? '✓ Defined' : '✗ Missing') . '</td></tr>';
}
echo '</table></div>';

// Test 6: Database
echo '<div class="test pass"><span class="status">✓ Database Configuration</span><br>';
echo 'DB_HOST: ' . (defined('DB_HOST') ? DB_HOST : 'Not set') . '<br>';
echo 'DB_NAME: ' . (defined('DB_NAME') ? DB_NAME : 'Not set') . '<br>';
echo 'DB_USER: ' . (defined('DB_USER') ? DB_USER : 'Not set') . '<br>';
echo '</div>';

// Test 7: Sample URL Generation
echo '<div class="test pass"><span class="status">✓ URL Generation Examples</span><br>';
if (function_exists('url')) {
    echo '<table>';
    $routes = ['', 'login', 'dashboard', 'crm/leads', 'logout'];
    foreach ($routes as $route) {
        echo '<tr><td>' . ($route ?: 'home') . '</td><td><code>' . url($route) . '</code></td></tr>';
    }
    echo '</table>';
} else {
    echo '<span style="color:red">url() function not available</span>';
}
echo '</div>';

// Test 8: Session
echo '<div class="test ' . (session_status() === PHP_SESSION_ACTIVE ? 'pass' : 'fail') . '">';
echo '<span class="status">' . (session_status() === PHP_SESSION_ACTIVE ? '✓' : '✗') . ' Session</span><br>';
echo 'Status: ' . (session_status() === PHP_SESSION_ACTIVE ? 'Active' : 'Inactive') . '<br>';
echo 'Session ID: ' . (session_id() ? 'Set' : 'Not set') . '<br>';
echo '</div>';

echo '<div style="background: #e7f3ff; border: 1px solid #b3d9ff; padding: 15px; margin-top: 20px; border-radius: 4px;">';
echo '<h3 style="margin-top: 0;">✓ All Systems Ready</h3>';
echo '<p>Your NeuvinCRM application is properly configured and ready to run.</p>';
echo '<p><a href="' . url('') . '" style="color: #007bff; text-decoration: none; font-weight: bold;">→ Go to Application Home</a></p>';
if (function_exists('url')) {
    echo '<p><a href="' . url('login') . '" style="color: #007bff; text-decoration: none; font-weight: bold;">→ Go to Login Page</a></p>';
}
echo '</div>';

?>

    </div>
</body>
</html>
<?php
ob_end_flush();
?>
