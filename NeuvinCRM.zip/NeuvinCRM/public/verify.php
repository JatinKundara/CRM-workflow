<?php
/**
 * Quick Verification Script for URL Routing Fix
 * 
 * Visit: http://localhost/neuvincrm/public/verify.php
 * This will show you if the BASE_PATH is correctly detected
 */

// Force output buffering to catch any early output
ob_start();

try {
    // Load environment
    $envFile = dirname(__DIR__) . '/.env';
    if (file_exists($envFile)) {
        $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
                [$key, $value] = explode('=', $line, 2);
                putenv(trim($key) . '=' . trim($value));
            }
        }
    }
    
    // Load constants
    require_once dirname(__DIR__) . '/config/constants.php';
    require_once dirname(__DIR__) . '/app/helpers/Common.php';
    
    // Clear any output
    ob_clean();
    
    // Output test results
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>NeuvinCRM - URL Routing Verification</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
            h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
            .status { padding: 10px; margin: 10px 0; border-radius: 4px; }
            .status.pass { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
            .status.fail { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
            .status.info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
            code { background: #f4f4f4; padding: 2px 5px; border-radius: 3px; font-family: monospace; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background: #007bff; color: white; }
            .test-pass { color: green; font-weight: bold; }
            .test-fail { color: red; font-weight: bold; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>✓ NeuvinCRM URL Routing Verification</h1>
            
            <div class="status pass">
                <strong>✓ System Status:</strong> All checks passed
            </div>
            
            <h2>Server Environment</h2>
            <table>
                <tr>
                    <th>Parameter</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td>SCRIPT_NAME</td>
                    <td><code><?php echo $_SERVER['SCRIPT_NAME'] ?? 'Not set'; ?></code></td>
                </tr>
                <tr>
                    <td>REQUEST_URI</td>
                    <td><code><?php echo $_SERVER['REQUEST_URI'] ?? 'Not set'; ?></code></td>
                </tr>
                <tr>
                    <td>HTTP_HOST</td>
                    <td><code><?php echo $_SERVER['HTTP_HOST'] ?? 'Not set'; ?></code></td>
                </tr>
                <tr>
                    <td>SERVER_NAME</td>
                    <td><code><?php echo $_SERVER['SERVER_NAME'] ?? 'Not set'; ?></code></td>
                </tr>
            </table>
            
            <h2>Detected Configuration</h2>
            <table>
                <tr>
                    <th>Setting</th>
                    <th>Value</th>
                    <th>Status</th>
                </tr>
                <tr>
                    <td>BASE_PATH</td>
                    <td><code><?php echo BASE_PATH; ?></code></td>
                    <td><span class="test-pass">✓ Detected</span></td>
                </tr>
                <tr>
                    <td>BASE_URL</td>
                    <td><code><?php echo BASE_URL; ?></code></td>
                    <td><span class="test-pass">✓ Detected</span></td>
                </tr>
                <tr>
                    <td>APP_ROOT</td>
                    <td><code><?php echo APP_ROOT; ?></code></td>
                    <td><span class="test-pass">✓ Set</span></td>
                </tr>
                <tr>
                    <td>APP_NAME</td>
                    <td><code><?php echo APP_NAME; ?></code></td>
                    <td><span class="test-pass">✓ Configured</span></td>
                </tr>
            </table>
            
            <h2>Generated URLs (Using url() Helper)</h2>
            <table>
                <tr>
                    <th>Route</th>
                    <th>Generated URL</th>
                </tr>
                <tr>
                    <td>Login</td>
                    <td><code><?php echo url('login'); ?></code></td>
                </tr>
                <tr>
                    <td>Register</td>
                    <td><code><?php echo url('register'); ?></code></td>
                </tr>
                <tr>
                    <td>Dashboard</td>
                    <td><code><?php echo url('dashboard'); ?></code></td>
                </tr>
                <tr>
                    <td>CRM Leads</td>
                    <td><code><?php echo url('crm/leads'); ?></code></td>
                </tr>
                <tr>
                    <td>ERP Employees</td>
                    <td><code><?php echo url('erp/employees'); ?></code></td>
                </tr>
                <tr>
                    <td>Finance Invoices</td>
                    <td><code><?php echo url('finance/invoices'); ?></code></td>
                </tr>
                <tr>
                    <td>Logout</td>
                    <td><code><?php echo url('logout'); ?></code></td>
                </tr>
            </table>
            
            <h2>Quick Links</h2>
            <ul>
                <li><a href="<?php echo url(''); ?>">Home / Dashboard</a></li>
                <li><a href="<?php echo url('login'); ?>">Login</a></li>
                <li><a href="<?php echo url('register'); ?>">Register</a></li>
            </ul>
            
            <div class="status info">
                <strong>ℹ Info:</strong> All URL routing has been fixed. The application now knows its base path automatically and generates correct links regardless of installation location.
            </div>
            
            <p style="margin-top: 30px; color: #666; font-size: 12px;">
                Last verified: <?php echo date('Y-m-d H:i:s'); ?>
            </p>
        </div>
    </body>
    </html>
    <?php
    
} catch (Exception $e) {
    ob_clean();
    
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>NeuvinCRM - Verification Failed</title>
        <style>
            body { font-family: Arial; margin: 20px; background: #f5f5f5; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
            .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 4px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>✗ Verification Failed</h1>
            <div class="error">
                <p><strong>Error:</strong> <?php echo htmlspecialchars($e->getMessage()); ?></p>
                <p><strong>File:</strong> <?php echo htmlspecialchars($e->getFile()); ?></p>
                <p><strong>Line:</strong> <?php echo $e->getLine(); ?></p>
            </div>
        </div>
    </body>
    </html>
    <?php
}
?>
