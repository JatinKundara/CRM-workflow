<?php
/**
 * Installation Complete - Next Steps
 */

$appRoot = dirname(__DIR__);
$installed = file_exists($appRoot . '/storage/installed.txt');

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeuvinCRM Installation Complete</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container { max-width: 700px; width: 100%; }
        .card { 
            background: white;
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 { color: #28a745; font-size: 48px; text-align: center; margin-bottom: 20px; }
        h2 { color: #333; margin-top: 30px; margin-bottom: 15px; font-size: 20px; }
        .status { 
            padding: 15px;
            border-radius: 6px;
            margin: 15px 0;
            background: #d4edda;
            color: #155724;
        }
        .info-box {
            background: #f0f4ff;
            border-left: 4px solid #667eea;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }
        code { 
            background: #f5f5f5;
            padding: 3px 8px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }
        .url-list {
            list-style: none;
            margin: 15px 0;
        }
        .url-list li {
            padding: 10px;
            margin: 8px 0;
            background: #f9f9f9;
            border-left: 3px solid #667eea;
            border-radius: 4px;
        }
        .url-list a {
            color: #667eea;
            text-decoration: none;
            font-weight: bold;
        }
        .url-list a:hover { text-decoration: underline; }
        .warning {
            background: #fff3cd;
            color: #856404;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            margin: 10px 5px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }
        .btn:hover { background: #5568d3; }
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        .center { text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>✓ Installation Complete!</h1>
            
            <div class="status">
                <strong>NeuvinCRM has been successfully installed and configured.</strong>
            </div>

            <?php if ($installed): ?>
                
                <h2>Your Login Credentials:</h2>
                <div class="info-box">
                    <p><strong>Email:</strong> <code>admin@neuvincrm.com</code></p>
                    <p><strong>Password:</strong> <code>admin123456</code></p>
                    <p style="font-size: 12px; color: #666; margin-top: 10px;">
                        ⚠️ Please change your password immediately after first login for security.
                    </p>
                </div>

                <h2>Access Your CRM:</h2>
                <ul class="url-list">
                    <li>
                        <strong>CRM Login Page:</strong><br>
                        <a href="/NeuvinCRM/public/?url=login">http://localhost/NeuvinCRM/public/?url=login</a>
                        <p style="font-size: 12px; color: #666; margin-top: 5px;">Start here to log into your CRM</p>
                    </li>
                    <li>
                        <strong>CRM Dashboard (after login):</strong><br>
                        <a href="/NeuvinCRM/public/?url=dashboard">http://localhost/NeuvinCRM/public/?url=dashboard</a>
                    </li>
                    <li>
                        <strong>Direct Root (redirects to login if not authenticated):</strong><br>
                        <a href="/NeuvinCRM/public/">http://localhost/NeuvinCRM/public/</a>
                    </li>
                </ul>

                <h2>System Information:</h2>
                <ul class="url-list">
                    <li>
                        <strong>Debug & Status Page:</strong><br>
                        <a href="/NeuvinCRM/public/debug.php">http://localhost/NeuvinCRM/public/debug.php</a>
                        <p style="font-size: 12px; color: #666; margin-top: 5px;">View system configuration and database status</p>
                    </li>
                    <li>
                        <strong>PHP Information:</strong><br>
                        <a href="/NeuvinCRM/public/php-info.php">http://localhost/NeuvinCRM/public/php-info.php</a>
                    </li>
                </ul>

                <div class="warning">
                    <strong>⚠️ Important Security Notes:</strong>
                    <ul style="margin-left: 20px; margin-top: 10px;">
                        <li>Delete the setup wizard files when done (not necessary for functionality)</li>
                        <li>Change your admin password immediately</li>
                        <li>Configure your email settings in the settings page</li>
                        <li>Set up backups for your database</li>
                    </ul>
                </div>

                <div class="center" style="margin-top: 30px;">
                    <a href="/NeuvinCRM/public/?url=login" class="btn btn-success">
                        → Go to Login Page →
                    </a>
                </div>

            <?php else: ?>
                
                <div class="warning">
                    Installation not marked as complete. The installed.txt file may not have been created.
                </div>
                
                <div class="center" style="margin-top: 20px;">
                    <a href="/NeuvinCRM/public/simple-setup.php" class="btn">
                        ← Go Back to Setup Wizard →
                    </a>
                </div>

            <?php endif; ?>

            <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #999; text-align: center;">
                <p>NeuvinCRM v1.0.0 | © 2026 All Rights Reserved</p>
                <p>For support, visit documentation or contact support</p>
            </div>
        </div>
    </div>

    <?php if ($installed): ?>
        <script>
            // Auto-redirect to login after 5 seconds
            setTimeout(() => {
                window.location.href = '/NeuvinCRM/public/?url=login';
            }, 5000);
        </script>
    <?php endif; ?>
</body>
</html>
