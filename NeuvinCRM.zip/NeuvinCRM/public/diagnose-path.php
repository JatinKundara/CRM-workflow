<?php
/**
 * Diagnostic: Request Path Analysis
 */

echo "=== REQUEST PATH ANALYSIS ===\n\n";

echo "SUPER GLOBALS:\n";
echo "  \$_GET: " . json_encode($_GET) . "\n";
echo "  \$_SERVER['REQUEST_URI']: " . ($_SERVER['REQUEST_URI'] ?? 'NOT SET') . "\n";
echo "  \$_SERVER['REQUEST_METHOD']: " . ($_SERVER['REQUEST_METHOD'] ?? 'NOT SET') . "\n";
echo "  \$_SERVER['SCRIPT_NAME']: " . ($_SERVER['SCRIPT_NAME'] ?? 'NOT SET') . "\n";
echo "  \$_SERVER['PHP_SELF']: " . ($_SERVER['PHP_SELF'] ?? 'NOT SET') . "\n";
echo "  \$_SERVER['QUERY_STRING']: " . ($_SERVER['QUERY_STRING'] ?? 'NOT SET') . "\n";

echo "\n" . str_repeat("=", 50) . "\n\n";

// Now test the Request class path parsing
define('APP_ROOT', dirname(__DIR__));

echo "PATH EXTRACTION (as App\\Core\\Request does it):\n";

$uri = $_SERVER['REQUEST_URI'] ?? '/';
echo "  Raw REQUEST_URI: $uri\n";

$path = parse_url($uri, PHP_URL_PATH);
echo "  After parse_url(REQUEST_URI, PHP_URL_PATH): $path\n";

$scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
$scriptDir = rtrim(dirname($scriptName), '/');
echo "  Script directory: $scriptDir\n";

$finalPath = str_replace($scriptDir, '', $path);
echo "  After str_replace: $finalPath\n";

$normalized = '/' . trim($finalPath, '/');
echo "  Final normalized path: $normalized\n";

echo "\n" . str_repeat("=", 50) . "\n\n";

echo "ROUTE MATCHING:\n";

$testRoutes = [
    "GET /" => "DashboardController@index (requires AuthMiddleware)",
    "GET /login" => "AuthController@showLogin",
    "POST /login" => "AuthController@login",
    "GET /register" => "AuthController@showRegister",
];

foreach ($testRoutes as $route => $handler) {
    [$method, $routePath] = explode(' ', $route);
    $routeRegex = '#^' . preg_replace_callback('/{([a-z_]+)}/', fn($m) => '(?P<' . $m[1] . '>[0-9]+)', $routePath) . '$#';
    $matches = preg_match($routeRegex, $normalized);
    
    $status = ($matches && $_SERVER['REQUEST_METHOD'] === $method) ? '✓ MATCH' : '✗';
    echo "  $status  $route  =>  $routeRegex\n";
}

echo "\nURL YOU SHOULD USE: http://localhost/NeuvinCRM/public/?url=login\n";
echo "But the ?url=login param is NOT used by the framework - only REQUEST_URI is parsed.\n";
?>
