<?php
/**
 * Application Diagnostic - Trace Exact Error
 */

define('APP_ROOT', dirname(__DIR__));

// Load .env
$envFile = APP_ROOT . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

// Load constants
require_once APP_ROOT . '/config/constants.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

// Test 1: Check if installed
$test1 = file_exists(APP_ROOT . '/storage/installed.txt');
echo "✓ Test 1: Installation marker exists: " . ($test1 ? 'YES' : 'NO') . "\n";

// Test 2: Check constants loaded
echo "✓ Test 2: APP_NAME = " . (defined('APP_NAME') ? APP_NAME : 'NOT DEFINED') . "\n";
echo "✓ Test 3: APP_DEBUG = " . (defined('APP_DEBUG') ? APP_DEBUG : 'NOT DEFINED') . "\n";
echo "✓ Test 4: APP_ROOT = " . (defined('APP_ROOT') ? APP_ROOT : 'NOT DEFINED') . "\n";

// Test 3: Check autoloader
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    if (strpos($class, $prefix) === 0) {
        $path = APP_ROOT . '/app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        echo "  Loading: $class from $path ... ";
        if (file_exists($path)) {
            echo "FOUND\n";
            require_once $path;
        } else {
            echo "NOT FOUND\n";
        }
    }
});

// Test 4: Check if core classes exist
echo "\n✓ Test 5: Core classes\n";
echo "  Request: " . (class_exists('App\Core\Request', false) ? 'EXISTS' : 'NOT FOUND') . "\n";
echo "  Response: " . (class_exists('App\Core\Response', false) ? 'EXISTS' : 'NOT FOUND') . "\n";
echo "  Router: " . (class_exists('App\Core\Router', false) ? 'EXISTS' : 'NOT FOUND') . "\n";
echo "  Logger: " . (class_exists('App\Core\Logger', false) ? 'EXISTS' : 'NOT FOUND') . "\n";

// Test 5: Try to load Application
echo "\n✓ Test 6: Loading Application class\n";
try {
    $appClass = 'App\Core\Application';
    if (!class_exists($appClass)) {
        echo "  Attempting to load: $appClass\n";
        require_once APP_ROOT . '/app/core/Application.php';
    }
    
    if (class_exists($appClass)) {
        echo "  Application class loaded successfully\n";
        
        // Test 6: Try to get instance
        echo "\n✓ Test 7: Getting Application instance\n";
        $app = \App\Core\Application::getInstance();
        echo "  Application instance created: " . (is_object($app) ? 'YES' : 'NO') . "\n";
        
        // Test 7: Try to run
        echo "\n✓ Test 8: Running application\n";
        $app->run();
        echo "  Application ran successfully\n";
    } else {
        echo "  ERROR: Application class not loaded\n";
    }
} catch (\Throwable $e) {
    echo "  ERROR: " . $e->getMessage() . "\n";
    echo "  File: " . str_replace(APP_ROOT, '', $e->getFile()) . "\n";
    echo "  Line: " . $e->getLine() . "\n";
    echo "  Trace:\n";
    foreach (explode("\n", $e->getTraceAsString()) as $line) {
        echo "    $line\n";
    }
}

echo "\n✓ Core Request Details:\n";
echo "  Method: " . $_SERVER['REQUEST_METHOD'] . "\n";
echo "  URL: " . ($_GET['url'] ?? '(not set)') . "\n";
echo "  Query String: " . ($_SERVER['QUERY_STRING'] ?? '(none)') . "\n";
?>
