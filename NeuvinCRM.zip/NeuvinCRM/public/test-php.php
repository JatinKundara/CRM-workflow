<?php
echo "✓ PHP is executing correctly!";
echo "<br>";
echo "BASE_PATH would be: " . (defined('BASE_PATH') ? BASE_PATH : 'Not defined yet');
?>
