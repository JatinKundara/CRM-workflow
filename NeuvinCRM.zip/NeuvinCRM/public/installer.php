<?php
/**
 * NeuvinCRM Web Installer (Secure Version)
 */

declare(strict_types=1);

// Prevent running if already installed
$installedFile = dirname(__DIR__) . '/storage/installed.txt';
if (file_exists($installedFile)) {
    header('Location: /');
    exit;
}

class Installer
{
    private string $appRoot;

    public function __construct()
    {
        $this->appRoot = dirname(__DIR__);
        $this->prepareDirectories();
    }

    private function prepareDirectories(): void
    {
        @mkdir($this->appRoot . '/storage/logs', 0755, true);
        @mkdir($this->appRoot . '/storage/cache', 0755, true);
    }

    private function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }

    /* ================= REQUIREMENTS ================= */

    public function checkRequirements(): array
    {
        return [
            'php' => ['name'=>'PHP 8.0+','passed'=>version_compare(PHP_VERSION,'8.0.0')>=0,'current'=>PHP_VERSION],
            'pdo' => ['name'=>'PDO Extension','passed'=>extension_loaded('pdo')],
            'mysql' => ['name'=>'PDO MySQL','passed'=>extension_loaded('pdo_mysql')],
            'json' => ['name'=>'JSON Extension','passed'=>extension_loaded('json')],
            'mbstring' => ['name'=>'MBString Extension','passed'=>extension_loaded('mbstring')],
            'storage' => ['name'=>'Storage Writable','passed'=>is_writable($this->appRoot.'/storage')],
            'logs' => ['name'=>'Logs Writable','passed'=>is_writable($this->appRoot.'/storage/logs')],
            'cache' => ['name'=>'Cache Writable','passed'=>is_writable($this->appRoot.'/storage/cache')],
        ];
    }

    public function handleStep(): void
    {
        $step = $_GET['step'] ?? '1';
        match ($step) {
            '1' => $this->requirementsPage(),
            '2' => $this->databasePage(),
            '3' => $this->adminPage(),
            '4' => $this->completePage(),
            default => $this->requirementsPage(),
        };
    }

    /* ================= STEP 1 ================= */

    private function requirementsPage(): void
    {
        $req = $this->checkRequirements();
        $allPassed = !in_array(false, array_column($req,'passed'), true);
        ?>
        <h2>Step 1 — Requirements</h2>
        <?php foreach ($req as $r): ?>
            <div><?= $this->e($r['name']) ?> :
                <?= $r['passed'] ? '✅' : '❌' ?>
            </div>
        <?php endforeach; ?>

        <?php if($allPassed): ?>
            <a href="?step=2">Next →</a>
        <?php else: ?>
            <p>Fix requirements before continuing.</p>
        <?php endif;
    }

    /* ================= STEP 2 DATABASE ================= */

    private function databasePage(): void
    {
        $error = '';

        if($_SERVER['REQUEST_METHOD']==='POST')
        {
            $dbHost = trim($_POST['db_host']);
            $dbName = trim($_POST['db_name']);
            $dbUser = trim($_POST['db_user']);
            $dbPass = trim($_POST['db_pass']);

            try {
                $pdo = new PDO(
                    "mysql:host={$dbHost};charset=utf8mb4",
                    $dbUser,
                    $dbPass,
                    [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]
                );

                $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

                // Save ENV safely
                $env = sprintf(
"APP_ENV=production
APP_DEBUG=false

DB_HOST=%s
DB_NAME=%s
DB_USER=%s
DB_PASS=%s
DB_PORT=3306

JWT_SECRET=%s",
                    addslashes($dbHost),
                    addslashes($dbName),
                    addslashes($dbUser),
                    addslashes($dbPass),
                    bin2hex(random_bytes(32))
                );

                file_put_contents($this->appRoot.'/.env', $env);

                header('Location: ?step=3');
                exit;

            } catch(Throwable $e){
                $error = $e->getMessage();
            }
        }
        ?>

        <h2>Step 2 — Database</h2>
        <?php if($error): ?><p style="color:red"><?= $this->e($error) ?></p><?php endif; ?>

        <form method="POST">
            Host <input name="db_host" value="localhost"><br>
            DB Name <input name="db_name" value="neuvincrm"><br>
            User <input name="db_user" value="root"><br>
            Password <input name="db_pass" type="password"><br>
            <button>Create DB</button>
        </form>

        <?php
    }

    /* ================= STEP 3 ADMIN ================= */

    private function adminPage(): void
    {
        if($_SERVER['REQUEST_METHOD']==='POST')
        {
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);
            $pass = password_hash($_POST['password'], PASSWORD_BCRYPT);

            // TODO: insert into DB after migrations
            header('Location: ?step=4');
            exit;
        }
        ?>

        <h2>Step 3 — Admin Account</h2>
        <form method="POST">
            Name <input name="name" required><br>
            Email <input name="email" type="email" required><br>
            Password <input name="password" type="password" required><br>
            <button>Create Admin</button>
        </form>

        <?php
    }

    /* ================= STEP 4 COMPLETE ================= */

    private function completePage(): void
    {
        file_put_contents($this->appRoot.'/storage/installed.txt', date('c'));
        ?>

        <h2>🎉 Installation Complete</h2>
        <p>Delete /install folder for security.</p>
        <a href="/">Go to Dashboard</a>

        <?php
    }
}

(new Installer())->handleStep();
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>NeuvinCRM Installation - Step 1</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif; background: #f5f5f5; }
                .container { max-width: 800px; margin: 50px auto; padding: 20px; }
                .card { background: white; border-radius: 8px; padding: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
                h1 { color: #333; margin-bottom: 10px; }
                .subtitle { color: #666; margin-bottom: 30px; }
                .requirement { padding: 12px; margin: 10px 0; border-radius: 4px; display: flex; justify-content: space-between; align-items: center; }
                .requirement.pass { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
                .requirement.fail { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
                .status { font-weight: bold; }
                .btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; margin-top: 20px; text-decoration: none; }
                .btn:disabled { background: #ccc; cursor: not-allowed; }
                .progress { margin-bottom: 30px; }
                .step { display: inline-block; padding: 8px 16px; background: #e9ecef; margin: 5px; border-radius: 20px; }
                .step.active { background: #007bff; color: white; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="card">
                    <h1>🚀 NeuvinCRM Installation</h1>
                    <p class="subtitle">Step 1 of 4 - Check Server Requirements</p>

                    <div class="progress">
                        <span class="step active">1. Requirements</span>
                        <span class="step">2. Database</span>
                        <span class="step">3. Admin Account</span>
                        <span class="step">4. Complete</span>
                    </div>

                    <div>
                        <?php foreach ($requirements as $key => $req): ?>
                            <div class="requirement <?php echo $req['passed'] ? 'pass' : 'fail'; ?>">
                                <span><?php echo $req['name']; ?></span>
                                <span class="status"><?php echo $req['passed'] ? '✓' : '✗'; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <form method="GET">
                        <input type="hidden" name="step" value="2">
                        <button type="submit" class="btn" <?php echo !$allPassed ? 'disabled' : ''; ?>>
                            <?php echo $allPassed ? 'Next Step →' : 'Fix Requirements First'; ?>
                        </button>
                    </form>
                </div>
            </div>
        </body>
        </html>
        <?php
    }

    private function stepDatabase(): void
    {
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dbHost = $_POST['db_host'] ?? '';
            $dbName = $_POST['db_name'] ?? '';
            $dbUser = $_POST['db_user'] ?? '';
            $dbPass = $_POST['db_pass'] ?? '';

            try {
                $pdo = new PDO(
                    "mysql:host={$dbHost}",
                    $dbUser,
                    $dbPass
                );

                // Create database
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

                // Create .env file
                $env = "APP_ENV=development\nAPP_DEBUG=true\n\nDB_HOST={$dbHost}\nDB_NAME={$dbName}\nDB_USER={$dbUser}\nDB_PASS={$dbPass}\nDB_PORT=3306\n\nJWT_SECRET=" . bin2hex(random_bytes(32)) . "\n";
                file_put_contents($this->appRoot . '/.env', $env);

                // Run migrations
                header('Location: ?step=3');
                exit;
            } catch (PDOException $e) {
                $error = $e->getMessage();
            }
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>NeuvinCRM Installation - Step 2</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif; background: #f5f5f5; }
                .container { max-width: 800px; margin: 50px auto; padding: 20px; }
                .card { background: white; border-radius: 8px; padding: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
                h1 { color: #333; margin-bottom: 10px; }
                .subtitle { color: #666; margin-bottom: 30px; }
                .form-group { margin-bottom: 20px; }
                label { display: block; margin-bottom: 5px; font-weight: 500; color: #333; }
                input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; }
                input:focus { outline: none; border-color: #007bff; }
                .error { color: #721c24; background: #f8d7da; padding: 10px; border-radius: 4px; margin-bottom: 20px; }
                .btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; margin-top: 20px; }
                .progress { margin-bottom: 30px; }
                .step { display: inline-block; padding: 8px 16px; background: #e9ecef; margin: 5px; border-radius: 20px; }
                .step.active { background: #007bff; color: white; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="card">
                    <h1>🚀 NeuvinCRM Installation</h1>
                    <p class="subtitle">Step 2 of 4 - Database Configuration</p>

                    <div class="progress">
                        <span class="step">1. Requirements</span>
                        <span class="step active">2. Database</span>
                        <span class="step">3. Admin Account</span>
                        <span class="step">4. Complete</span>
                    </div>

                    <?php if ($error): ?>
                        <div class="error"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="form-group">
                            <label for="db_host">Database Host</label>
                            <input type="text" id="db_host" name="db_host" value="localhost" required>
                        </div>

                        <div class="form-group">
                            <label for="db_name">Database Name</label>
                            <input type="text" id="db_name" name="db_name" value="neuvincrm" required>
                        </div>

                        <div class="form-group">
                            <label for="db_user">Database User</label>
                            <input type="text" id="db_user" name="db_user" value="root" required>
                        </div>

                        <div class="form-group">
                            <label for="db_pass">Database Password</label>
                            <input type="password" id="db_pass" name="db_pass">
                        </div>

                        <button type="submit" class="btn">Create Database &amp; Continue →</button>
                    </form>
                </div>
            </div>
        </body>
        </html>
        <?php
    }

    private function stepAdmin(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Create admin account
            $name = $_POST['name'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';

            // This would be handled in the application
            header('Location: ?step=4');
            exit;
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>NeuvinCRM Installation - Step 3</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; }
                .container { max-width: 800px; margin: 50px auto; padding: 20px; }
                .card { background: white; border-radius: 8px; padding: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
                h1 { color: #333; margin-bottom: 10px; }
                .form-group { margin-bottom: 20px; }
                label { display: block; margin-bottom: 5px; font-weight: 500; }
                input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; }
                .btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; margin-top: 20px; }
                .progress { margin-bottom: 30px; }
                .step { display: inline-block; padding: 8px 16px; background: #e9ecef; margin: 5px; border-radius: 20px; }
                .step.active { background: #007bff; color: white; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="card">
                    <h1>🚀 NeuvinCRM Installation</h1>
                    <p style="color: #666; margin-bottom: 30px;">Step 3 of 4 - Create Admin Account</p>

                    <div class="progress">
                        <span class="step">1. Requirements</span>
                        <span class="step">2. Database</span>
                        <span class="step active">3. Admin Account</span>
                        <span class="step">4. Complete</span>
                    </div>

                    <form method="POST">
                        <div class="form-group">
                            <label>Administrator Name</label>
                            <input type="text" name="name" required>
                        </div>

                        <div class="form-group">
                            <label>Administrator Email</label>
                            <input type="email" name="email" required>
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" required>
                        </div>

                        <button type="submit" class="btn">Create Account &amp; Continue →</button>
                    </form>
                </div>
            </div>
        </body>
        </html>
        <?php
    }

    private function stepComplete(): void
    {
        @mkdir($this->appRoot . '/storage', 0755, true);
        file_put_contents($this->appRoot . '/storage/installed.txt', date('Y-m-d H:i:s'));
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>NeuvinCRM Installation Complete</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f5f5f5; }
                .container { max-width: 800px; margin: 50px auto; padding: 20px; }
                .card { background: white; border-radius: 8px; padding: 40px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
                h1 { color: #28a745; font-size: 48px; margin-bottom: 20px; }
                p { color: #666; margin-bottom: 20px; font-size: 18px; }
                .btn { display: inline-block; padding: 12px 30px; background: #007bff; color: white; border: none; border-radius: 4px; text-decoration: none; font-size: 16px; margin-top: 20px; }
                .info { background: #e7f3ff; border: 1px solid #b3d9ff; padding: 15px; border-radius: 4px; margin: 20px 0; text-align: left; }
                .info strong { color: #004085; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="card">
                    <h1>✓</h1>
                    <h2>Installation Complete!</h2>
                    <p>NeuvinCRM has been successfully installed and is ready to use.</p>

                    <div class="info">
                        <strong>Default Credentials:</strong><br>
                        Email: admin@neuvincrm.com<br>
                        Password: admin123456
                    </div>

                    <div class="info">
                        <strong>Important:</strong><br>
                        Please change your password immediately after logging in. Delete the installer file from the server.
                    </div>

                    <a href="/" class="btn">Go to Dashboard →</a>
                </div>
            </div>
        </body>
        </html>
        <?php
    }
}

// Run installer
$installer = new Installer();
$installer->handleStep();
