<?php
echo '<h1>Apache Module Test</h1>';

if (function_exists('apache_get_modules')) {
    $modules = apache_get_modules();
    echo '<h2>Installed Modules:</h2>';
    echo '<ul>';
    foreach ($modules as $module) {
        $highlight = strpos($module, 'rewrite') !== false ? ' style="color: red; font-weight: bold;"' : '';
        echo "<li{$highlight}>{$module}</li>";
    }
    echo '</ul>';
    
    if (in_array('mod_rewrite', $modules)) {
        echo '<p style="color: green;"><strong>✓ mod_rewrite is ENABLED</strong></p>';
    } else {
        echo '<p style="color: red;"><strong>✗ mod_rewrite is NOT ENABLED</strong></p>';
    }
} else {
    echo '<p>apache_get_modules() is not available</p>';
    echo '<p>Checking via $_SERVER[\'HTTP_MOD_REWRITE\']...</p>';
}

echo '<hr>';
echo '<h2>Current Request</h2>';
echo '<p>REQUEST_URI: ' . $_SERVER['REQUEST_URI'] . '</p>';
echo '<p>PHP_SELF: ' . $_SERVER['PHP_SELF'] . '</p>';
echo '<p>SCRIPT_NAME: ' . $_SERVER['SCRIPT_NAME'] . '</p>';

echo '<hr>';
echo '<h2>Quick Links</h2>';
echo '<ul>';
echo '<li><a href="/setup.php">Setup Wizard</a></li>';
echo '<li><a href="/installer.php">Installer</a></li>';
echo '<li><a href="/">Dashboard</a></li>';
echo '</ul>';
?>
