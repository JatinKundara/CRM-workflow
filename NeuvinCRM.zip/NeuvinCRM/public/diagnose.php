<?php
/**
 * Class Loader Test - Diagnose missing classes
 */

$appRoot = dirname(__DIR__);

echo '<h1>NeuvinCRM Class Loader Diagnostic</h1>';

// Load constants
if (@require_once $appRoot . '/config/constants.php') {
    echo '<p>✓ Constants loaded</p>';
} else {
    echo '<p>✗ Failed to load constants</p>';
    exit;
}

// Load .env
$envFile = $appRoot . '/.env';
if (file_exists($envFile)) {
    echo '<p>✓ .env file exists</p>';
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
    echo '<p>✓ .env loaded into environment</p>';
}

// Test autoloader
echo '<h2>Testing Class Autoloader</h2>';

// Manual autoloader function for testing
$classesToTest = [
    'App\\Core\\Application',
    'App\\Core\\Router',
    'App\\Core\\Request',
    'App\\Core\\Response',
    'App\\Core\\Logger',
    'App\\Core\\Controller',
    'App\\Controllers\\AuthController',
    'App\\Controllers\\DashboardController',
];

foreach ($classesToTest as $className) {
    $path = $appRoot . '/app/' . str_replace('\\', '/', substr($className, 4)) . '.php';
    
    if (file_exists($path)) {
        echo '<p>✓ <strong>' . $className . '</strong></p>';
        echo '   <small>Path: ' . str_replace($appRoot, '', $path) . '</small><br>';
    } else {
        echo '<p>✗ <strong>' . $className . '</strong></p>';
        echo '   <small>Expected: ' . str_replace($appRoot, '', $path) . '</small><br>';
    }
}

// Try loading core classes
echo '<h2>Loading Core Application</h2>';

spl_autoload_register(function ($class) use ($appRoot) {
    $prefix = 'App\\';
    if (strpos($class, $prefix) === 0) {
        $path = $appRoot . '/app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        if (file_exists($path)) {
            require_once $path;
            return true;
        }
    }
    return false;
});

try {
    echo '<p>Attempting to load Application class...</p>';
    $app = \App\Core\Application::getInstance();
    echo '<p>✓ Application instance created successfully!</p>';
} catch (Throwable $e) {
    echo '<p>✗ Failed to create Application instance</p>';
    echo '<p><strong>Error:</strong> ' . $e->getMessage() . '</p>';
    echo '<p><strong>File:</strong> ' . $e->getFile() . ':' . $e->getLine() . '</p>';
    echo '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
}

echo '<h2>Database Connection Test</h2>';
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME,
        DB_USER,
        DB_PASS
    );
    echo '<p>✓ Database connected successfully</p>';
} catch (PDOException $e) {
    echo '<p>✗ Database connection failed</p>';
    echo '<p>' . $e->getMessage() . '</p>';
}

?>
