<?php
require_once dirname(__DIR__) . '/config/constants.php';
require_once dirname(__DIR__) . '/app/core/Database.php';

$db = \App\Core\Database::getInstance()->getConnection();
$result = $db->query('DESCRIBE products')->fetchAll();

echo "=== Products Table Schema ===\n";
foreach ($result as $column) {
    echo $column['Field'] . " (" . $column['Type'] . ") - " . ($column['Null'] === 'YES' ? 'NULL' : 'NOT NULL') . "\n";
}
?>
