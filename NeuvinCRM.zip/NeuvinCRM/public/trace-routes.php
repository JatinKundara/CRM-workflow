<?php
/**
 * Route Dispatch Tracer
 */

header('Content-Type: application/json');

define('APP_ROOT', dirname(__DIR__));

// Load environment
$envFile = APP_ROOT . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

// Load constants  
require_once APP_ROOT . '/config/constants.php';

// Setup autoloader
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    if (strpos($class, $prefix) === 0) {
        $path = APP_ROOT . '/app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

try {
    // Create request
    $request = new \App\Core\Request();
    $response = new \App\Core\Response();
    $router = new \App\Core\Router($request, $response);
    
    // Capture request info
    $requestInfo = [
        'method' => $request->getMethod(),
        'path' => $request->getPath(),
        'uri' => $_SERVER['REQUEST_URI'] ?? 'N/A',
        'script_name' => $_SERVER['SCRIPT_NAME'] ?? 'N/A',
        'query_string' => $_SERVER['QUERY_STRING'] ?? 'N/A'
    ];
    
    // Register routes
    require APP_ROOT . '/routes/web.php';
    
    // Try to find matching route (reflection to access private routes array)
    $reflection = new ReflectionClass($router);
    $routesProperty = $reflection->getProperty('routes');
    $routesProperty->setAccessible(true);
    $routes = $routesProperty->getValue($router);
    
    // Filter matching routes
    $matchingRoutes = array_filter($routes, function ($route) use ($request) {
        $method = $request->getMethod();
        $path = $request->getPath();
        return $route['method'] === $method && preg_match($route['regex'], $path);
    });
    
    echo json_encode([
        'request' => $requestInfo,
        'total_routes' => count($routes),
        'matching_routes' => count($matchingRoutes),
        'first_5_routes' => array_slice(array_map(function ($r) {
            return [
                'method' => $r['method'],
                'path' => $r['path'],
                'handler' => $r['handler'],
                'regex' => $r['regex']
            ];
        }, $routes), 0, 5),
        'matching_route_details' => array_map(function ($r) {
            return [
                'method' => $r['method'],
                'path' => $r['path'],
                'handler' => $r['handler'],
                'middleware' => $r['middleware']
            ];
        }, $matchingRoutes)
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    
} catch (\Throwable $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'file' => str_replace(APP_ROOT, '', $e->getFile()),
        'line' => $e->getLine()
    ], JSON_PRETTY_PRINT);
}
