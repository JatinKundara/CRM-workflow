<?php
/**
 * Simple Path Trace
 */

define('APP_ROOT', dirname(__DIR__));

// Simulate request
$_SERVER['REQUEST_URI'] = '/NeuvinCRM/public/';
$_SERVER['SCRIPT_NAME'] = '/NeuvinCRM/public/index.php';
$_SERVER['REQUEST_METHOD'] = 'GET';

// Check path parsing
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
echo "parse_url(REQUEST_URI, PHP_URL_PATH): $path\n";

$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
echo "dirname(SCRIPT_NAME): $scriptDir\n";

$finalPath = str_replace($scriptDir, '', $path);
echo "Final path: $finalPath\n";

// Normalize
$normalized = '/' . trim($finalPath, '/');
echo "Normalized: $normalized\n";

echo "\n---\n";
echo "Route to match: '/'\n";
echo "Regex pattern for '/' route: #^/$#\n";
echo "Does it match? " . (preg_match('#^/$#', $normalized) ? 'YES' : 'NO') . "\n";
