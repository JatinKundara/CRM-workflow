<?php 
echo "✓ PHP is working!\n\n";
echo "Version: " . PHP_VERSION . "\n";
echo "SAPI: " . php_sapi_name() . "\n";
echo "OS: " . php_uname() . "\n";
?>
