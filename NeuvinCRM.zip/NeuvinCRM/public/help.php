<?php
/**
 * NeuvinCRM Diagnostic Hub
 */

$appRoot = dirname(__DIR__);
$pages = [
    [
        'url' => '?url=__diagnostic__',
        'name' => 'System Diagnostic (JSON)',
        'description' => 'Shows PHP version, environment, and class loading status'
    ],
    [
        'url' => 'test-api.php',
        'name' => 'API Test',
        'description' => 'Basic API response test'
    ],
    [
        'url' => 'test-auth.php',
        'name' => 'Auth System Test',
        'description' => 'Tests authentication components and controller loading'
    ],
    [
        'url' => 'diagnose.php',
        'name' => 'Full Diagnostics',
        'description'=> 'Complete system diagnosis including database connection'
    ],
    [
        'url' => 'debug.php',
        'name' => 'Installation Status',
        'description' => 'Check installation files and configuration'
    ],
    [
        'url' => 'php-info.php',
        'name' => 'PHP Information',
        'description' => 'Comprehensive PHP system information'
    ],
    [
        'url' => 'next-steps.php',
        'name' => 'Next Steps',
        'description' => 'Post-installation instructions and login information'
    ],
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeuvinCRM Diagnostic Hub</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        .container { max-width: 900px; margin: 0 auto; }
        .card { 
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 { color: #667eea; margin-bottom: 10px; }
        .subtitle { color: #999; font-size: 14px; margin-bottom: 30px; }
        .diagnostic-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; }
        .diagnostic-card {
            background: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            transition: all 0.3s ease;
        }
        .diagnostic-card:hover {
            border-color: #667eea;
            background: #f0f4ff;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.2);
        }
        .diagnostic-card h3 { color: #333; margin-bottom: 8px; } 
        .diagnostic-card p { color: #666; font-size: 13px; margin-bottom: 15px; }
        .link-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: bold;
            transition: background 0.3s ease;
        }
        .link-btn:hover { background: #5568d3; }
        
        .quick-access {
            background: #d4edda;
            border-left: 4px solid #28a745;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .quick-access h3 { color: #155724; margin-bottom: 10px; }
        .quick-access a {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px 5px 5px 0;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
        .quick-access a:hover { background: #218838; }
        
        .info-section { margin-top: 30px; }
        .info-section h2 { color: #333; margin-bottom: 15px; font-size: 18px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>🔍 NeuvinCRM Diagnostic Hub</h1>
            <p class="subtitle">System diagnostics and troubleshooting tools</p>

            <div class="quick-access">
                <h3>⚡ Quick Access</h3>
                <a href="next-steps.php">Setup Complete - Next Steps</a>
                <a href="?url=login">Go to Login</a>
                <a href="?url=__diagnostic__">System Status (JSON)</a>
            </div>

            <div class="info-section">
                <h2>Diagnostic Tools</h2>
                <div class="diagnostic-grid">
                    <?php foreach ($pages as $page): ?>
                        <div class="diagnostic-card">
                            <h3><?php echo htmlspecialchars($page['name']); ?></h3>
                            <p><?php echo htmlspecialchars($page['description']); ?></p>
                            <a href="<?php echo htmlspecialchars($page['url']); ?>" class="link-btn">Open →</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="info-section">
                <h2>Troubleshooting Guide</h2>
                <h3>If you see "Internal server error":</h3>
                <ol style="line-height: 1.8; color: #666;">
                    <li>Visit the <a href="test-auth.php" style="color: #667eea;">Auth System Test</a> page to check component loading</li>
                    <li>Check <a href="debug.php" style="color: #667eea;">Installation Status</a> to verify database connection</li>
                    <li>Review <a href="?url=__diagnostic__" style="color: #667eea;">System Diagnostic (JSON)</a> for detailed error information</li>
                    <li>Ensure all database tables are created - check database with a client</li>
                    <li>Verify file permissions on storage/* directories</li>
                </ol>
            </div>

            <div class="info-section" style="background: #f0f4ff; padding: 20px; border-radius: 8px;">
                <h3>System Status</h3>
                <p>
                    <strong>PHP Version:</strong> <?php echo PHP_VERSION; ?><br>
                    <strong>Installation Status:</strong> <?php echo file_exists($appRoot . '/storage/installed.txt') ? '✓ Installed' : '✗ Not installed'; ?><br>
                    <strong>.env File:</strong> <?php echo file_exists($appRoot . '/.env') ? '✓ Found' : '✗ Missing'; ?>
                </p>
            </div>
        </div>
    </div>
</body>
</html>
