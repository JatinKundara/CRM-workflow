<?php
/**
 * NeuvinCRM Debug Page
 */

$appRoot = dirname(__DIR__);

echo '<h1>NeuvinCRM Installation Status</h1>';

// Check if installed
$installed = file_exists($appRoot . '/storage/installed.txt');
echo '<p><strong>Installed:</strong> ' . ($installed ? '✓ Yes' : '✗ No') . '</p>';

if ($installed) {
    echo '<p><strong>Installation Date:</strong> ' . file_get_contents($appRoot . '/storage/installed.txt') . '</p>';
}

// Check .env
echo '<h2>.env File</h2>';
if (file_exists($appRoot . '/.env')) {
    echo '<p>✓ .env file exists</p>';
    $env = file_get_contents($appRoot . '/.env');
    echo '<pre style="background: #f0f0f0; padding: 10px; border-radius: 4px;">' . htmlspecialchars($env) . '</pre>';
} else {
    echo '<p>✗ .env file NOT found</p>';
}

// Check constants
echo '<h2>Constants Check</h2>';
if (file_exists($appRoot . '/config/constants.php')) {
    require_once $appRoot . '/config/constants.php';
    echo '<p>✓ Constants loaded</p>';
    echo '<p>APP_ROOT: ' . APP_ROOT . '</p>';
    echo '<p>APP_ENV: ' . APP_ENV . '</p>';
    echo '<p>DB_HOST: ' . DB_HOST . '</p>';
    echo '<p>DB_NAME: ' . DB_NAME . '</p>';
}

// Check if installer ran
echo '<h2>Storage Directories</h2>';
$dirs = ['storage', 'storage/logs', 'storage/cache', 'storage/uploads'];
foreach ($dirs as $dir) {
    $path = $appRoot . '/' . $dir;
    $exists = is_dir($path);
    $writable = $exists ? is_writable($path) : false;
    echo '<p>' . ($exists ? '✓' : '✗') . ' ' . $dir . ' (' . ($writable ? 'writable' : ($exists ? 'read-only' : 'missing')) . ')</p>';
}

// Try to connect to database
echo '<h2>Database Connection</h2>';
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME,
        DB_USER,
        DB_PASS
    );
    echo '<p>✓ MySQL connected successfully</p>';
    
    // Check tables
    $result = $pdo->query("SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = '" . DB_NAME . "'");
    $row = $result->fetch(PDO::FETCH_ASSOC);
    echo '<p>Tables in database: ' . $row['count'] . '</p>';
} catch (PDOException $e) {
    echo '<p>✗ MySQL Connection Failed: ' . $e->getMessage() . '</p>';
}

// Next Steps
echo '<h2>Next Steps</h2>';
if ($installed) {
    echo '<ul>';
    echo '<li><a href="/NeuvinCRM/public/?url=login">Go to Login Page</a></li>';
    echo '<li><a href="/NeuvinCRM/public/">Go to Dashboard</a></li>';
    echo '</ul>';
} else {
    echo '<ul>';
    echo '<li><a href="/NeuvinCRM/public/simple-setup.php">Run Setup Wizard</a></li>';
    echo '</ul>';
}

?>
