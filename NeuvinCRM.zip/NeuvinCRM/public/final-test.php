<?php
/**
 * Complete Application Flow Test
 */

header('Content-Type: application/json');

define('APP_ROOT', dirname(__DIR__));

// Load environment
$envFile = APP_ROOT . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

require_once APP_ROOT . '/config/constants.php';

// Setup autoloader
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    if (strpos($class, $prefix) === 0) {
        $path = APP_ROOT . '/app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

try {
    echo json_encode([
        'status' => 'Testing Application Flow',
        'tests' => []
    ], JSON_PRETTY_PRINT);

} catch (\Throwable $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'file' => str_replace(APP_ROOT, '', $e->getFile()),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString()
    ], JSON_PRETTY_PRINT);
}
