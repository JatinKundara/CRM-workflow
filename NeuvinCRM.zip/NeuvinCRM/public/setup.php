<?php
/**
 * NeuvinCRM Standalone Installer
 * Simple, no dependencies
 */

// Start session first
@session_start();

$appRoot = dirname(__DIR__);

// Check if already installed
if (file_exists($appRoot . '/storage/installed.txt')) {
    header('Location: /');
    exit('Already installed. Redirecting to dashboard...');
}

// Determine current step
$step = $_GET['step'] ?? 1;
$step = (int)$step;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($step) {
        case 2:
            // Database configuration
            $dbHost = $_POST['db_host'] ?? 'localhost';
            $dbName = $_POST['db_name'] ?? 'neuvincrm';
            $dbUser = $_POST['db_user'] ?? 'root';
            $dbPass = $_POST['db_pass'] ?? '';

            try {
                $pdo = new PDO(
                    "mysql:host={$dbHost}",
                    $dbUser,
                    $dbPass,
                    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
                );

                // Create database
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                
                // Create .env file
                $envContent = "APP_NAME=NeuvinCRM\n";
                $envContent .= "APP_ENV=development\n";
                $envContent .= "APP_DEBUG=true\n";
                $envContent .= "DB_HOST={$dbHost}\n";
                $envContent .= "DB_NAME={$dbName}\n";
                $envContent .= "DB_USER={$dbUser}\n";
                $envContent .= "DB_PASS={$dbPass}\n";
                $envContent .= "DB_PORT=3306\n";
                $envContent .= "JWT_SECRET=" . bin2hex(random_bytes(32)) . "\n";
                
                file_put_contents($appRoot . '/.env', $envContent);
                
                $_SESSION['db_configured'] = true;
                header('Location: ?step=3');
                exit;
                
            } catch (PDOException $e) {
                $error = 'Database Error: ' . $e->getMessage();
            }
            break;

        case 3:
            // Admin account setup
            $_SESSION['admin_configured'] = true;
            header('Location: ?step=4');
            exit;
            break;

        case 4:
            // Complete installation
            @mkdir($appRoot . '/storage', 0777, true);
            @mkdir($appRoot . '/storage/logs', 0777, true);
            @mkdir($appRoot . '/storage/cache', 0777, true);
            @mkdir($appRoot . '/storage/uploads', 0777, true);
            
            file_put_contents($appRoot . '/storage/installed.txt', date('Y-m-d H:i:s'));
            
            header('Location: /');
            exit('Installation complete. Redirecting...');
            break;
    }
}

// Start output
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeuvinCRM Installation</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container { max-width: 600px; width: 100%; }
        .card { 
            background: white;
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 { color: #333; margin-bottom: 10px; font-size: 28px; }
        .subtitle { color: #666; margin-bottom: 30px; font-size: 14px; }
        
        .progress {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        .step {
            flex: 1;
            min-width: 100px;
            padding: 10px;
            background: #e9ecef;
            border-radius: 6px;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        .step.active { background: #667eea; color: white; }
        .step.done { background: #28a745; color: white; }
        
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 6px; font-weight: 500; color: #333; }
        input, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            font-family: inherit;
        }
        input:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }
        
        .requirement {
            padding: 12px;
            margin: 10px 0;
            border-radius: 6px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .requirement.pass { background: #d4edda; color: #155724; }
        .requirement.fail { background: #f8d7da; color: #721c24; }
        
        .error { color: #721c24; background: #f8d7da; padding: 12px; border-radius: 6px; margin-bottom: 20px; }
        .success { color: #155724; background: #d4edda; padding: 12px; border-radius: 6px; margin-bottom: 20px; }
        
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            margin-top: 20px;
            font-size: 14px;
        }
        .btn:hover { background: #5568d3; }
        .btn:disabled { background: #ccc; cursor: not-allowed; }
        
        .logo { text-align: center; margin-bottom: 30px; }
        .logo img { max-width: 100px; height: auto; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="logo">
                <h1>🚀 NeuvinCRM</h1>
                <p style="color: #999; font-size: 12px;">Installation Wizard</p>
            </div>

            <div class="progress">
                <div class="step <?php echo $step >= 1 ? 'active' : ''; ?> <?php echo $step > 1 ? 'done' : ''; ?>">Step 1<br>Requirements</div>
                <div class="step <?php echo $step >= 2 ? 'active' : ''; ?> <?php echo $step > 2 ? 'done' : ''; ?>">Step 2<br>Database</div>
                <div class="step <?php echo $step >= 3 ? 'active' : ''; ?> <?php echo $step > 3 ? 'done' : ''; ?>">Step 3<br>Admin</div>
                <div class="step <?php echo $step >= 4 ? 'active' : ''; ?> <?php echo $step > 4 ? 'done' : ''; ?>">Step 4<br>Complete</div>
            </div>

            <?php

            // STEP 1: Check Requirements
            if ($step === 1) {
                $requirements = [
                    'PHP 8.4+' => version_compare(PHP_VERSION, '8.4.0') >= 0,
                    'PDO' => extension_loaded('pdo'),
                    'PDO MySQL' => extension_loaded('pdo_mysql'),
                    'JSON' => extension_loaded('json'),
                    'Storage Writable' => is_writable($appRoot . '/storage'),
                ];
                
                $allPass = !in_array(false, $requirements);
                ?>
                <h2>Step 1: Check Requirements</h2>
                <p class="subtitle">Verify your server meets the minimum requirements</p>
                
                <div>
                    <?php foreach ($requirements as $name => $passed): ?>
                        <div class="requirement <?php echo $passed ? 'pass' : 'fail'; ?>">
                            <span><?php echo $name; ?></span>
                            <span><?php echo $passed ? '✓' : '✗'; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <form method="GET">
                    <input type="hidden" name="step" value="2">
                    <button type="submit" class="btn">
                        Next: Database Configuration →
                    </button>
                </form>

            <?php
            // STEP 2: Database Configuration
            } elseif ($step === 2) {
                $error = $error ?? '';
                ?>
                <h2>Step 2: Database Configuration</h2>
                <p class="subtitle">Configure your MySQL database connection</p>
                
                <?php if ($error): ?>
                    <div class="error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <input type="hidden" name="step" value="2">
                    <div class="form-group">
                        <label for="db_host">Database Host</label>
                        <input type="text" id="db_host" name="db_host" value="localhost" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_name">Database Name</label>
                        <input type="text" id="db_name" name="db_name" value="neuvincrm" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_user">Database User</label>
                        <input type="text" id="db_user" name="db_user" value="root" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="db_pass">Database Password</label>
                        <input type="password" id="db_pass" name="db_pass" placeholder="Leave empty if no password">
                    </div>
                    
                    <button type="submit" class="btn">Create Database & Continue →</button>
                </form>

            <?php
            // STEP 3: Admin Account
            } elseif ($step === 3) {
                ?>
                <h2>Step 3: Create Admin Account</h2>
                <p class="subtitle">Set up your administrator account</p>
                
                <form method="POST">
                    <input type="hidden" name="step" value="3">
                    <div class="form-group">
                        <label for="admin_name">Administrator Name</label>
                        <input type="text" id="admin_name" name="admin_name" value="Administrator" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="admin_email">Administrator Email</label>
                        <input type="email" id="admin_email" name="admin_email" value="admin@neuvincrm.com" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="admin_password">Password</label>
                        <input type="password" id="admin_password" name="admin_password" value="admin123456" required>
                    </div>
                    
                    <button type="submit" class="btn">Complete Installation →</button>
                </form>

            <?php
            // STEP 4: Complete
            } elseif ($step === 4) {
                // Create installed marker
                @mkdir($appRoot . '/storage', 0777, true);
                file_put_contents($appRoot . '/storage/installed.txt', date('Y-m-d H:i:s'));
                ?>
                <div style="text-align: center;">
                    <h1 style="font-size: 48px; color: #28a745; margin-bottom: 20px;">✓</h1>
                    <h2>Installation Complete!</h2>
                    <p style="color: #666; margin: 20px 0;">NeuvinCRM has been successfully installed and configured.</p>
                    
                    <div style="background: #f0f4ff; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: left;">
                        <p style="margin: 8px 0;"><strong>Email:</strong> admin@neuvincrm.com</p>
                        <p style="margin: 8px 0;"><strong>Password:</strong> admin123456</p>
                    </div>
                    
                    <p style="color: #999; font-size: 12px; margin: 20px 0;">⚠️ Please change your password after first login.</p>
                    
                    <a href="/" style="display: inline-block; padding: 12px 30px; background: #667eea; color: white; border-radius: 6px; text-decoration: none; margin-top: 20px;">Go to Dashboard</a>
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>
<?php
?>
