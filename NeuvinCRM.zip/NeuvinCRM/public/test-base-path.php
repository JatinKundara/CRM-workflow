<?php
/**
 * Test BASE_PATH Detection
 */

// Simulate different server configurations
echo "=== BASE_PATH Detection Test ===\n\n";

// Current SERVER values
echo "Current \$_SERVER['SCRIPT_NAME']: " . ($_SERVER['SCRIPT_NAME'] ?? 'Not set') . "\n";
echo "Current \$_SERVER['REQUEST_URI']: " . ($_SERVER['REQUEST_URI'] ?? 'Not set') . "\n";
echo "Current \$_SERVER['HTTP_HOST']: " . ($_SERVER['HTTP_HOST'] ?? 'Not set') . "\n\n";

// Load constants
require_once dirname(__DIR__) . '/config/constants.php';

echo "Detected BASE_PATH: " . BASE_PATH . "\n";
echo "Detected BASE_URL: " . BASE_URL . "\n\n";

// Test url() helper
require_once dirname(__DIR__) . '/app/helpers/Common.php';

echo "Generated URLs:\n";
echo "  login: " . url('login') . "\n";
echo "  dashboard: " . url('dashboard') . "\n";
echo "  crm/leads: " . url('crm/leads') . "\n";
echo "  logout: " . url('logout') . "\n";

echo "\n✓ BASE_PATH test complete\n";
?>
