<?php
/**
 * NeuvinCRM Front Controller (Production Safe)
 */

declare(strict_types=1);

/* --------------------------------------------------
| 1. LOAD ENV FILE SAFELY
--------------------------------------------------*/
$envFile = dirname(__DIR__) . '/.env';

if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        if (!str_contains($line, '=')) continue;

        [$key, $value] = explode('=', $line, 2);
        $value = trim($value, "\"' "); // remove quotes safely
        putenv(trim($key) . '=' . $value);
        $_ENV[trim($key)] = $value;
    }
}

/* --------------------------------------------------
| 2. LOAD CONSTANTS
--------------------------------------------------*/
require_once dirname(__DIR__) . '/config/constants.php';

/* --------------------------------------------------
| 3. ERROR SETTINGS
--------------------------------------------------*/
error_reporting(E_ALL);
ini_set('display_errors', APP_DEBUG ? '1' : '0');
ini_set('log_errors', '1');

/* --------------------------------------------------
| 4. INSTALL CHECK
--------------------------------------------------*/
if (!file_exists(APP_ROOT . '/storage/installed.txt')) {
    header('Location: simple-setup.php');
    exit;
}

/* --------------------------------------------------
| 5. AUTOLOADER
--------------------------------------------------*/
if (file_exists(APP_ROOT . '/vendor/autoload.php')) {
    require_once APP_ROOT . '/vendor/autoload.php';
} else {
    spl_autoload_register(function ($class) {
        $prefix = 'App\\';
        if (str_starts_with($class, $prefix)) {
            $path = APP_ROOT . '/app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
            if (file_exists($path)) require_once $path;
        }
    });
}

/* --------------------------------------------------
| 6. HELPERS
--------------------------------------------------*/
require_once APP_ROOT . '/app/helpers/Common.php';

/* --------------------------------------------------
| 7. START SESSION (BEFORE HEADERS)
--------------------------------------------------*/
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* --------------------------------------------------
| 8. BASIC HEADERS
--------------------------------------------------*/
header('Content-Type: text/html; charset=utf-8');

/* Handle CORS PREFLIGHT safely */
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

/* --------------------------------------------------
| 9. TIMEZONE + LOCALE
--------------------------------------------------*/
date_default_timezone_set(DEFAULT_TIMEZONE);
setlocale(LC_ALL, DEFAULT_LOCALE);

/* --------------------------------------------------
| 10. DEV DIAGNOSTIC (DEV ONLY)
--------------------------------------------------*/
if (APP_DEBUG && ($_GET['url'] ?? '') === '__diagnostic__') {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'ok',
        'php' => PHP_VERSION,
        'env' => APP_ENV,
        'installed' => file_exists(APP_ROOT . '/storage/installed.txt'),
        'app_root' => APP_ROOT,
        'autoload' => class_exists('App\\Core\\Application')
    ], JSON_PRETTY_PRINT);
    exit;
}

/* --------------------------------------------------
| 11. RUN APPLICATION
--------------------------------------------------*/
try {
    ob_start();

    $app = \App\Core\Application::getInstance();
    $app->run();

    ob_end_flush();

} catch (Throwable $e) {

    while (ob_get_level()) ob_end_clean();
    error_log($e);

    http_response_code(500);

    if (APP_DEBUG) {
        header('Content-Type: application/json');
        echo json_encode([
            'error' => $e->getMessage(),
            'file' => str_replace(APP_ROOT, '', $e->getFile()),
            'line' => $e->getLine()
        ], JSON_PRETTY_PRINT);
    } else {
        echo "Internal Server Error";
    }
}