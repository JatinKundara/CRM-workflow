<?php
/**
 * PHP Installation & System Diagnostics
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP System Diagnostics</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        .container { max-width: 900px; margin: 0 auto; }
        .card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 { color: #333; margin-bottom: 10px; }
        .subtitle { color: #999; margin-bottom: 30px; font-size: 14px; }
        h2 { color: #667eea; margin-top: 20px; margin-bottom: 15px; border-bottom: 2px solid #667eea; padding-bottom: 10px; }
        
        .status { display: flex; align-items: center; gap: 10px; margin: 10px 0; padding: 10px; border-radius: 6px; }
        .status.pass { background: #d4edda; color: #155724; }
        .status.fail { background: #f8d7da; color: #721c24; }
        .status.warning { background: #fff3cd; color: #856404; }
        
        .badge { display: inline-block; padding: 4px 12px; background: #667eea; color: white; border-radius: 20px; font-size: 12px; font-weight: bold; }
        .badge.critical { background: #dc3545; }
        .badge.warning { background: #ffc107; color: #333; }
        .badge.success { background: #28a745; }
        
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f5f5f5; font-weight: 600; }
        
        .section-title { color: #333; font-weight: 600; margin-top: 20px; margin-bottom: 10px; }
        
        .quick-links { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 20px; }
        .link { display: inline-block; padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 6px; font-size: 14px; }
        .link:hover { background: #5568d3; }
        
        code { background: #f5f5f5; padding: 2px 6px; border-radius: 3px; font-family: 'Courier New', monospace; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>🔍 PHP System Diagnostics</h1>
            <p class="subtitle">Complete system and environment check</p>

            <!-- PHP Version -->
            <h2>PHP Installation</h2>
            <?php
            $phpVersion = PHP_VERSION;
            $versionParts = explode('.', $phpVersion);
            $majorVersion = (int)$versionParts[0];
            $minorVersion = (int)$versionParts[1];
            
            echo '<div class="status ' . ($majorVersion >= 8 && $minorVersion >= 5 ? 'pass' : ($majorVersion >= 8 ? 'warning' : 'fail')) . '">';
            echo '<span>';
            if ($majorVersion >= 8 && $minorVersion >= 5) {
                echo '✓ PHP ' . $phpVersion . ' <span class="badge success">EXCELLENT</span>';
            } elseif ($majorVersion >= 8) {
                echo '⚠ PHP ' . $phpVersion . ' <span class="badge warning">OK (8.5+ Recommended)</span>';
            } else {
                echo '✗ PHP ' . $phpVersion . ' <span class="badge critical">OUTDATED</span>';
            }
            echo '</span></div>';
            ?>

            <!-- SAPI -->
            <div class="section-title">Server API</div>
            <div class="status pass">
                <span>✓ SAPI: <code><?php echo php_sapi_name(); ?></code></span>
            </div>

            <!-- OS Information -->
            <h2>System Information</h2>
            <table>
                <tr>
                    <th>Property</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td>Operating System</td>
                    <td><?php echo php_uname(); ?></td>
                </tr>
                <tr>
                    <td>Platform</td>
                    <td><?php echo PHP_OS_FAMILY; ?></td>
                </tr>
                <tr>
                    <td>Processor</td>
                    <td><?php echo php_uname('m'); ?></td>
                </tr>
                <tr>
                    <td>Current Directory</td>
                    <td><code><?php echo getcwd(); ?></code></td>
                </tr>
            </table>

            <!-- Extensions Check -->
            <h2>Required Extensions</h2>
            <?php
            $requiredExtensions = [
                'PDO' => extension_loaded('pdo'),
                'PDO MySQL' => extension_loaded('pdo_mysql'),
                'JSON' => extension_loaded('json'),
                'MBString' => extension_loaded('mbstring'),
                'cURL' => extension_loaded('curl'),
                'OpenSSL' => extension_loaded('openssl'),
            ];

            foreach ($requiredExtensions as $ext => $loaded) {
                echo '<div class="status ' . ($loaded ? 'pass' : 'fail') . '">';
                echo '<span>' . ($loaded ? '✓' : '✗') . ' ' . $ext . '</span>';
                echo '</div>';
            }
            ?>

            <!-- Directory Permissions -->
            <h2>Directory Permissions</h2>
            <?php
            $baseDir = dirname(__DIR__);
            $directories = [
                $baseDir . '/storage' => 'Storage',
                $baseDir . '/storage/logs' => 'Logs',
                $baseDir . '/storage/cache' => 'Cache',
                $baseDir . '/storage/uploads' => 'Uploads',
                $baseDir . '/public' => 'Public',
            ];

            foreach ($directories as $dir => $name) {
                $exists = is_dir($dir);
                $writable = $exists && is_writable($dir);
                $status = $writable ? 'pass' : ($exists ? 'warning' : 'fail');
                $icon = $writable ? '✓' : ($exists ? '⚠' : '✗');
                
                echo '<div class="status ' . $status . '">';
                echo '<span>' . $icon . ' ' . $name . ' ';
                if ($exists && $writable) {
                    echo '<span class="badge success">Writable</span>';
                } elseif ($exists) {
                    echo '<span class="badge warning">Read-only</span>';
                } else {
                    echo '<span class="badge critical">Missing</span>';
                }
                echo '</span></div>';
            }
            ?>

            <!-- File Uploads -->
            <h2>Upload Configuration</h2>
            <table>
                <tr>
                    <th>Setting</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td>File Uploads Enabled</td>
                    <td><?php echo ini_get('file_uploads') ? '✓ Yes' : '✗ No'; ?></td>
                </tr>
                <tr>
                    <td>Max Upload Size</td>
                    <td><?php echo ini_get('upload_max_filesize'); ?></td>
                </tr>
                <tr>
                    <td>Max POST Size</td>
                    <td><?php echo ini_get('post_max_size'); ?></td>
                </tr>
                <tr>
                    <td>Default Timezone</td>
                    <td><?php echo date_default_timezone_get(); ?></td>
                </tr>
            </table>

            <!-- Memory & Execution -->
            <h2>Performance Settings</h2>
            <table>
                <tr>
                    <th>Setting</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td>Memory Limit</td>
                    <td><?php echo ini_get('memory_limit'); ?></td>
                </tr>
                <tr>
                    <td>Max Execution Time</td>
                    <td><?php echo ini_get('max_execution_time'); ?>s</td>
                </tr>
                <tr>
                    <td>Display Errors</td>
                    <td><?php echo ini_get('display_errors') ? 'On' : 'Off'; ?></td>
                </tr>
                <tr>
                    <td>Error Reporting</td>
                    <td><?php echo ini_get('error_reporting') === '-1' ? 'All' : ini_get('error_reporting'); ?></td>
                </tr>
            </table>

            <!-- Loaded Extensions Count -->
            <h2>All Loaded Extensions</h2>
            <div class="status pass">
                <span>✓ Total Extensions: <strong><?php echo count(get_loaded_extensions()); ?></strong></span>
            </div>

            <?php
            $extensions = get_loaded_extensions();
            sort($extensions);
            $cols = 3;
            $count = count($extensions);
            $perCol = ceil($count / $cols);
            
            echo '<table>';
            for ($i = 0; $i < $perCol; $i++) {
                echo '<tr>';
                for ($j = 0; $j < $cols; $j++) {
                    $idx = $j * $perCol + $i;
                    if ($idx < $count) {
                        echo '<td><code>' . $extensions[$idx] . '</code></td>';
                    } else {
                        echo '<td></td>';
                    }
                }
                echo '</tr>';
            }
            echo '</table>';
            ?>

            <!-- Database Connection Test -->
            <h2>Database Connection</h2>
            <?php
            try {
                $pdo = new PDO('mysql:host=localhost', 'root', '');
                echo '<div class="status pass"><span>✓ MySQL Connection Successful <span class="badge success">Connected</span></span></div>';
            } catch (PDOException $e) {
                echo '<div class="status fail"><span>✗ MySQL Connection Failed: ' . $e->getMessage() . ' <span class="badge critical">Error</span></span></div>';
            }
            ?>

            <!-- Summary -->
            <h2>Summary</h2>
            <div class="status pass">
                <span>✓ PHP is properly installed and working</span>
            </div>
            <div class="status pass">
                <span>✓ All essential extensions are loaded</span>
            </div>

            <!-- Quick Links -->
            <div class="quick-links">
                <a href="/check.php" class="link">Apache Module Check</a>
                <a href="/setup.php" class="link">Setup Wizard</a>
                <a href="/test.php" class="link">NeuvinCRM Test</a>
                <a href="/" class="link">Main Application</a>
            </div>
        </div>
    </div>
</body>
</html>
