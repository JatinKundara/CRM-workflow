<?php
/**
 * Simple Test Entry Point - No Framework
 */

// Load env
$appRoot = dirname(__DIR__);
$envFile = $appRoot . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

require_once $appRoot . '/config/constants.php';

echo json_encode([
    'status' => 'test',
    'php_version' => PHP_VERSION,
    'app_env' => APP_ENV,
    'app_debug' => APP_DEBUG,
    'db_host' => DB_HOST,
    'db_name' => DB_NAME,
    'installation_complete' => file_exists(APP_ROOT . '/storage/installed.txt'),
    'current_url' => $_SERVER['REQUEST_URI'],
    'server_name' => $_SERVER['SERVER_NAME'],
    'script_name' => $_SERVER['SCRIPT_NAME'],
], JSON_PRETTY_PRINT);
?>
