<?php
// Test database connection
require_once dirname(__DIR__) . '/config/constants.php';

echo "=== Database Configuration ===\n";
echo "Host: " . DB_HOST . "\n";
echo "Port: " . DB_PORT . "\n";
echo "Database: " . DB_NAME . "\n";
echo "User: " . DB_USER . "\n";
echo "Password: " . (DB_PASS ? '***' : '(empty)') . "\n\n";

// Test MySQL server connection (without database)
echo "=== Testing MySQL Server Connection ===\n";
try {
    $dsn = "mysql:host=" . DB_HOST . ":" . DB_PORT;
    $pdo = new PDO($dsn, DB_USER, DB_PASS);
    echo "✓ MySQL Server: Connected\n\n";
    
    // Check if database exists
    echo "=== Checking Database ===\n";
    $result = $pdo->query("SHOW DATABASES LIKE '" . DB_NAME . "'");
    $dbExists = $result->fetch();
    if ($dbExists) {
        echo "✓ Database '" . DB_NAME . "': EXISTS\n";
    } else {
        echo "✗ Database '" . DB_NAME . "': NOT FOUND\n";
        echo "\nCreating database...\n";
        $pdo->exec("CREATE DATABASE " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        echo "✓ Database created successfully\n";
    }
    
    // Test connecting to the specific database
    echo "\n=== Testing Database Connection ===\n";
    $dsn = "mysql:host=" . DB_HOST . ":" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS);
    echo "✓ Database Connection: OK\n";
    
} catch (PDOException $e) {
    echo "✗ Connection Failed: " . $e->getMessage() . "\n";
    echo "\nTroubleshooting:\n";
    echo "1. Make sure MySQL is running (check XAMPP Control Panel)\n";
    echo "2. Verify credentials in .env file\n";
    echo "3. Check DB_HOST and DB_PORT are correct\n";
}
?>
