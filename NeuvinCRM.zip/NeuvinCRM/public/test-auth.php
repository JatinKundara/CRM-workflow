<?php
/**
 * Auth Flow Test
 */

$appRoot = dirname(__DIR__);

// Load env
$envFile = $appRoot . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

require_once $appRoot . '/config/constants.php';
session_start();

// Autoloader
spl_autoload_register(function ($class) use ($appRoot) {
    $prefix = 'App\\';
    if (strpos($class, $prefix) === 0) {
        $path = $appRoot . '/app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        if (file_exists($path)) {
            require_once $path;
            return true;
        }
    }
    return false;
});

echo '<h1>Testing Login Flow</h1>';

try {
    // Test 1: Load Request class
    echo '<h2>1. Testing Request Class</h2>';
    $request = new \App\Core\Request();
    echo '<p>✓ Request loaded</p>';
    echo '<p>  Method: ' . $request->getMethod() . '</p>';
    echo '<p>  Path: ' . $request->getPath() . '</p>';
    
    // Test 2: Load Response class
    echo '<h2>2. Testing Response Class</h2>';
    $response = new \App\Core\Response();
    echo '<p>✓ Response loaded</p>';
    
    // Test 3: Load Router
    echo '<h2>3. Testing Router Class</h2>';
    $router = new \App\Core\Router($request, $response);
    echo '<p>✓ Router loaded</p>';
    
    // Test 4: Load and execute auth controller
    echo '<h2>4. Testing AuthController</h2>';
    $auth = new \App\Controllers\AuthController();
    echo '<p>✓ AuthController loaded</p>';
    
    // Test 5: Check view files
    echo '<h2>5. Checking View Files</h2>';
    $viewPath = $appRoot . '/app/views/auth/login.php';
    if (file_exists($viewPath)) {
        echo '<p>✓ Login view exists: ' . str_replace($appRoot, '', $viewPath) . '</p>';
    } else {
        echo '<p>✗ Login view NOT found: expected at ' . str_replace($appRoot, '', $viewPath) . '</p>';
    }
    
    echo '<h2>✓ All components loaded successfully!</h2>';
    echo '<p><a href="/NeuvinCRM/public/?url=login">Try accessing the login page</a></p>';
    
} catch (Throwable $e) {
    echo '<h2>✗ Error Occurred</h2>';
    echo '<p><strong>' . get_class($e) . ':</strong> ' . $e->getMessage() . '</p>';
    echo '<p><strong>File:</strong> ' . str_replace($appRoot, '', $e->getFile()) . ':' . $e->getLine() . '</p>';
    echo '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
}
?>
