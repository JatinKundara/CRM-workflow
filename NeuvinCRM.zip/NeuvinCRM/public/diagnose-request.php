<?php
echo "=== Request Diagnostics ===\n";
echo "REQUEST_URI: " . ($_SERVER['REQUEST_URI'] ?? 'NOT SET') . "\n";
echo "SCRIPT_NAME: " . ($_SERVER['SCRIPT_NAME'] ?? 'NOT SET') . "\n";
echo "PHP_SELF: " . ($_SERVER['PHP_SELF'] ?? 'NOT SET') . "\n";
echo "REQUEST_METHOD: " . ($_SERVER['REQUEST_METHOD'] ?? 'NOT SET') . "\n";
echo "QUERY_STRING: " . ($_SERVER['QUERY_STRING'] ?? 'NOT SET') . "\n";

// Parse the path like the Application does
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
echo "\nParsed path: $path\n";

$script_dir = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/');
echo "Script directory: $script_dir\n";

$clean_path = str_replace($script_dir, '', $path);
echo "Clean path: $clean_path\n";

// What the router would see
require_once dirname(__DIR__) . '/config/constants.php';
require_once APP_ROOT . '/app/core/Request.php';

$req = new \App\Core\Request();
echo "\nRouter would see: " . $req->getPath() . "\n";
?>
