<?php
/**
 * Direct Application Test
 * Shows the exact error being thrown
 */

header('Content-Type: application/json');

define('APP_ROOT', dirname(__DIR__));

// Load environment
$envFile = APP_ROOT . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

// Load constants
require_once APP_ROOT . '/config/constants.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Setup autoloader
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    if (strpos($class, $prefix) === 0) {
        $path = APP_ROOT . '/app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

session_start();

try {
    // Step 1: Load Application
    echo "Step 1: Loading Application...\n";
    $app = \App\Core\Application::getInstance();
    echo "Step 2: Application loaded\n";
    
    // Step 2: Get router
    echo "Step 3: Getting router...\n";
    $router = $app->getRouter();
    echo "Step 4: Router obtained\n";
    
    // Step 3: Try to run
    echo "Step 5: Running application...\n";
    $app->run();
    echo "Step 6: Application completed\n";
} catch (\Throwable $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'type' => class_basename($e),
        'file' => str_replace(APP_ROOT, '', $e->getFile()),
        'line' => $e->getLine(),
        'trace' => array_map(function ($frame) use ($APP_ROOT) {
            return [
                'function' => $frame['function'] ?? 'N/A',
                'class' => $frame['class'] ?? 'N/A',
                'file' => str_replace(APP_ROOT, '', $frame['file'] ?? 'N/A'),
                'line' => $frame['line'] ?? 'N/A'
            ];
        }, $e->getTrace())
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
