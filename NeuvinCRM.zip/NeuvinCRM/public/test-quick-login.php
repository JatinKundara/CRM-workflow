<?php
// Quick login test
require_once dirname(__DIR__) . '/config/constants.php';
require_once dirname(__DIR__) . '/app/core/Database.php';
require_once dirname(__DIR__) . '/app/core/Model.php';
require_once dirname(__DIR__) . '/app/models/User.php';
require_once dirname(__DIR__) . '/app/core/Security.php';
require_once dirname(__DIR__) . '/app/services/AuthService.php';

try {
    $auth = new \App\Services\AuthService();
    $result = $auth->login('admin@neuvincrm.com', 'admin123');
    echo json_encode([
        'success' => $result,
        'message' => $result ? 'Login successful!' : 'Login failed!'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
