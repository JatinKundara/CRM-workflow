<?php
/**
 * NeuvinCRM Simple Installer - Debug Version
 */

// Start session
@session_start();

$appRoot = dirname(__DIR__);
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;

// Debug info
$debug = [];
$debug['php_version'] = PHP_VERSION;
$debug['current_step'] = $step;
$debug['request_method'] = $_SERVER['REQUEST_METHOD'];
$debug['post_data'] = $_POST;
$debug['get_data'] = $_GET;
$debug['installed'] = file_exists($appRoot . '/storage/installed.txt');

// Handle Step 2 (Database)
if ($step === 2 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbHost = $_POST['db_host'] ?? 'localhost';
    $dbName = $_POST['db_name'] ?? 'neuvincrm';
    $dbUser = $_POST['db_user'] ?? 'root';
    $dbPass = $_POST['db_pass'] ?? '';
    
    try {
        $pdo = new PDO(
            "mysql:host={$dbHost}",
            $dbUser,
            $dbPass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        // Create database
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        // Create .env file
        $envContent = "APP_NAME=NeuvinCRM\n";
        $envContent .= "APP_ENV=development\nAPP_DEBUG=true\n";
        $envContent .= "DB_HOST={$dbHost}\nDB_NAME={$dbName}\nDB_USER={$dbUser}\nDB_PASS={$dbPass}\n";
        $envContent .= "DB_PORT=3306\nJWT_SECRET=" . bin2hex(random_bytes(32)) . "\n";
        
        file_put_contents($appRoot . '/.env', $envContent);
        
        // Force redirect
        header('Location: simple-setup.php?step=3', true, 302);
        exit;
        
    } catch (PDOException $e) {
        $error = $e->getMessage();
    }
}

// Handle Step 3 (Admin)
if ($step === 3 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Location: simple-setup.php?step=4', true, 302);
    exit;
}

// Handle Step 4 (Complete)
if ($step === 4 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    @mkdir($appRoot . '/storage', 0777, true);
    @mkdir($appRoot . '/storage/logs', 0777, true);
    @mkdir($appRoot . '/storage/cache', 0777, true);
    @mkdir($appRoot . '/storage/uploads', 0777, true);
    
    $installationTime = date('Y-m-d H:i:s');
    file_put_contents($appRoot . '/storage/installed.txt', $installationTime);
    
    // Verify the file was created
    if (file_exists($appRoot . '/storage/installed.txt')) {
        // Redirect to next steps page
        header('Location: next-steps.php', true, 302);
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeuvinCRM - Simple Setup</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #667eea; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .card { background: white; border-radius: 12px; padding: 40px; max-width: 500px; width: 100%; box-shadow: 0 10px 40px rgba(0,0,0,0.2); }
        h1 { color: #333; margin-bottom: 20px; }
        .step-counter { color: #999; font-size: 14px; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 6px; font-weight: bold; color: #333; }
        input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; }
        button { width: 100%; padding: 12px; background: #667eea; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: bold; margin-top: 20px; }
        button:hover { background: #5568d3; }
        .requirement { padding: 10px; margin: 10px 0; border-radius: 6px; display: flex; justify-content: space-between; }
        .requirement.pass { background: #d4edda; color: #155724; }
        .requirement.fail { background: #f8d7da; color: #721c24; }
        .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 6px; margin-bottom: 20px; }
        .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 6px; margin-bottom: 20px; }
        .debug { background: #f0f0f0; padding: 10px; border-radius: 6px; margin-top: 20px; font-family: monospace; font-size: 12px; }
    </style>
</head>
<body>
    <div class="card">
        <h1>🚀 NeuvinCRM Setup</h1>
        <p class="step-counter">Step <?php echo $step; ?> of 4</p>

        <?php if ($step === 1): ?>
            
            <h2>Step 1: Check Requirements</h2>
            
            <div class="requirement <?php echo version_compare(PHP_VERSION, '8.4.0') >= 0 ? 'pass' : 'fail'; ?>">
                <span>PHP 8.4+</span>
                <span><?php echo PHP_VERSION; ?> <?php echo version_compare(PHP_VERSION, '8.4.0') >= 0 ? '✓' : '✗'; ?></span>
            </div>
            
            <div class="requirement <?php echo extension_loaded('pdo_mysql') ? 'pass' : 'fail'; ?>">
                <span>PDO MySQL</span>
                <span><?php echo extension_loaded('pdo_mysql') ? '✓' : '✗'; ?></span>
            </div>
            
            <div class="requirement <?php echo is_writable($appRoot . '/storage') ? 'pass' : 'fail'; ?>">
                <span>Storage Writable</span>
                <span><?php echo is_writable($appRoot . '/storage') ? '✓' : '✗'; ?></span>
            </div>
            
            <form action="simple-setup.php?step=2" method="GET">
                <button type="submit">Next: Database Setup →</button>
            </form>

        <?php elseif ($step === 2): ?>
            
            <h2>Step 2: Database Configuration</h2>
            
            <?php if (isset($error)): ?>
                <div class="error"><strong>Error:</strong> <?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>Database Host</label>
                    <input type="text" name="db_host" value="localhost" required>
                </div>
                
                <div class="form-group">
                    <label>Database Name</label>
                    <input type="text" name="db_name" value="neuvincrm" required>
                </div>
                
                <div class="form-group">
                    <label>Database User</label>
                    <input type="text" name="db_user" value="root" required>
                </div>
                
                <div class="form-group">
                    <label>Database Password (leave empty if none)</label>
                    <input type="password" name="db_pass">
                </div>
                
                <button type="submit">Create Database & Continue →</button>
            </form>

        <?php elseif ($step === 3): ?>
            
            <h2>Step 3: Create Admin Account</h2>
            
            <form method="POST">
                <div class="form-group">
                    <label>Admin Name</label>
                    <input type="text" name="admin_name" value="Administrator" required>
                </div>
                
                <div class="form-group">
                    <label>Admin Email</label>
                    <input type="email" name="admin_email" value="admin@neuvincrm.com" required>
                </div>
                
                <div class="form-group">
                    <label>Admin Password</label>
                    <input type="password" name="admin_password" value="admin123456" required>
                </div>
                
                <button type="submit">Complete Installation →</button>
            </form>

        <?php elseif ($step === 4): ?>
            
            <div style="text-align: center;">
                <h1 style="font-size: 48px; color: #28a745; margin-bottom: 20px;">✓</h1>
                <h2>Installation Complete!</h2>
                <p style="color: #666; margin: 20px 0;">NeuvinCRM has been successfully installed and configured.</p>
                
                <div style="background: #f0f4ff; padding: 15px; border-radius: 6px; margin: 20px 0;">
                    <strong>Login Credentials:</strong><br>
                    Email: <code>admin@neuvincrm.com</code><br>
                    Password: <code>admin123456</code>
                    <p style="font-size: 12px; color: #999; margin-top: 10px;">⚠️ Please change your password immediately after first login.</p>
                </div>
                
                <form method="POST">
                    <button type="submit">Finish & Redirect to Login →</button>
                </form>
                
                <p style="color: #999; font-size: 12px; margin-top: 20px;">
                    If not redirected automatically, <a href="/NeuvinCRM/public/?url=login" style="color: #667eea;">click here to go to login</a>
                </p>
            </div>

        <?php endif; ?>
        
        <div class="debug" style="margin-top: 40px; border-top: 2px solid #ccc; padding-top: 20px;">
            <strong>Debug Info:</strong><br>
            Step: <?php echo $debug['current_step']; ?><br>
            Method: <?php echo $debug['request_method']; ?><br>
            PHP: <?php echo $debug['php_version']; ?><br>
            Installed: <?php echo $debug['installed'] ? 'Yes' : 'No'; ?>
        </div>
    </div>
</body>
</html>
