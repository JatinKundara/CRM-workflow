<?php
/**
 * Complete Login Flow Test
 */

// Simulate HTTP POST request to login
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['REQUEST_URI'] = '/neuvincrm/public/login';
$_SERVER['SCRIPT_NAME'] = '/neuvincrm/public/index.php';
$_SERVER['HTTP_HOST'] = 'localhost';

// Load environment
$envFile = dirname(__DIR__) . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

echo "=== Complete Login Flow Test ===\n\n";

try {
    // Initialize application components
    require_once dirname(__DIR__) . '/config/constants.php';
    require_once dirname(__DIR__) . '/app/core/Database.php';
    require_once dirname(__DIR__) . '/app/core/Model.php';
    require_once dirname(__DIR__) . '/app/models/User.php';
    require_once dirname(__DIR__) . '/app/core/Security.php';
    require_once dirname(__DIR__) . '/app/services/AuthService.php';

    echo "✓ All classes loaded\n\n";

    // Test 1: Direct model operations
    echo "--- Test 1: Direct Model Operations ---\n";
    $user = new \App\Models\User();
    $adminUser = $user->find(1);
    if ($adminUser) {
        echo "✓ User::find(1) works\n";
        echo "  - Email: " . $adminUser['email'] . "\n";
        echo "  - Name: " . $adminUser['name'] . "\n";
    } else {
        echo "✗ User::find(1) returned null\n";
    }

    echo "\n--- Test 2: AuthService findByEmail ---\n";
    $authService = new \App\Services\AuthService();
    $foundUser = $authService->findByEmail('admin@neuvincrm.com');
    if ($foundUser) {
        echo "✓ AuthService::findByEmail() works\n";
        echo "  - ID: " . $foundUser['id'] . "\n";
        echo "  - Email: " . $foundUser['email'] . "\n";
    } else {
        echo "✗ AuthService::findByEmail() returned null\n";
    }

    echo "\n--- Test 3: Password Verification ---\n";
    if ($foundUser && password_verify('admin123', $foundUser['password'])) {
        echo "✓ Password verification passed\n";
    } else {
        echo "✗ Password verification failed\n";
    }

    echo "\n--- Test 4: Complete Login ---\n";
    $result = $authService->login('admin@neuvincrm.com', 'admin123');
    if ($result === true) {
        echo "✓ Login successful\n";
        echo "  - Session ID should be set\n";
    } else {
        echo "✗ Login failed: " . $result . "\n";
    }

    echo "\n✓ All tests completed!\n";

} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    echo "  File: " . $e->getFile() . "\n";
    echo "  Line: " . $e->getLine() . "\n";
    
    // Print full backtrace
    echo "\nStack Trace:\n";
    foreach ($e->getTrace() as $i => $trace) {
        echo "  [{$i}] " . ($trace['file'] ?? 'unknown') . ":" . ($trace['line'] ?? 'unknown') . " in " . ($trace['function'] ?? 'unknown') . "\n";
    }
}

?>
