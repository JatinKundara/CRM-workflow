<?php
/**
 * Login Test Script
 */

// Load environment
$envFile = dirname(__DIR__) . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            [$key, $value] = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

require_once dirname(__DIR__) . '/config/constants.php';

echo "=== Login Test ===\n\n";

try {
    $dsn = "mysql:host=" . DB_HOST . ":" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    // Test 1: Check if admin user exists
    echo "✓ Connected to database\n";
    
    $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = ?");
    $stmt->execute(['admin@neuvincrm.com']);
    $user = $stmt->fetch();
    
    if ($user) {
        echo "✓ Admin user found: " . $user['email'] . "\n";
        echo "  - ID: " . $user['id'] . "\n";
        echo "  - Name: " . $user['name'] . "\n";
        echo "  - Active: " . ($user['is_active'] ? 'Yes' : 'No') . "\n";
        
        // Test 2: Test password verification
        require_once dirname(__DIR__) . '/app/core/Security.php';
        $test_password = 'admin123';
        $password_match = password_verify($test_password, $user['password']);
        echo "✓ Password verification: " . ($password_match ? 'PASS' : 'FAIL') . "\n";
        
        if (!$password_match) {
            // Try hashing and comparing
            echo "  Testing hash generation...\n";
            echo "  Password hash in DB: " . substr($user['password'], 0, 20) . "...\n";
        }
        
    } else {
        echo "✗ Admin user not found!\n";
        echo "  Create a user first using the registration page.\n";
    }
    
    echo "\n✓ Database tests completed successfully.\n";
    
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    echo "  File: " . $e->getFile() . "\n";
    echo "  Line: " . $e->getLine() . "\n";
}

?>
