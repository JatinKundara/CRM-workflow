<?php
/**
 * Test file to diagnose setup
 */

echo '<h1>NeuvinCRM Setup Test</h1>';

// Test 1: PHP Version
echo '<h2>✓ PHP ' . PHP_VERSION . ' is running</h2>';

// Test 2: Check files
echo '<h2>File Structure</h2>';
$files_to_check = [
    'index.php',
    'installer.php',
    '.htaccess',
    '../config/constants.php',
    '../.env',
    '../storage/installed.txt',
];

foreach ($files_to_check as $file) {
    $exists = file_exists(__DIR__ . '/' . $file) ? '✓' : '✗';
    echo "<p>{$exists} {$file}</p>";
}

// Test 3: Check constants
echo '<h2>Constants</h2>';
require_once dirname(__DIR__) . '/config/constants.php';
echo '<p>APP_ROOT: ' . APP_ROOT . '</p>';
echo '<p>APP_ENV: ' . APP_ENV . '</p>';
echo '<p>Storage writable: ' . (is_writable(APP_ROOT . '/storage') ? '✓' : '✗') . '</p>';

// Test 4: Installer status
echo '<h2>Installation Status</h2>';
if (file_exists(APP_ROOT . '/storage/installed.txt')) {
    echo '<p>✓ System is installed</p>';
} else {
    echo '<p>✗ System NOT installed - run installer</p>';
}

?>
