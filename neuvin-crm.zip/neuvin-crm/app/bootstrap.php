<?php

/**
 * Application bootstrap. Required by public/index.php and by any
 * module file invoked indirectly (CLI scripts, cron jobs, etc.).
 *
 * Order matters here:
 *   1. Composer autoload (DOMPDF, and our own PSR-4 App\ namespace)
 *   2. .env values loaded into getenv()
 *   3. Error reporting set based on environment
 *   4. Session started with secure-ish defaults
 *   5. Logger + Database instantiated and made available to controllers
 */

define('ROOT_PATH', dirname(__DIR__));

require ROOT_PATH . '/vendor/autoload.php';
require ROOT_PATH . '/app/config/env.php';
require ROOT_PATH . '/app/helpers/functions.php';

load_env(ROOT_PATH . '/.env');

$appConfig      = require ROOT_PATH . '/app/config/app.php';
$databaseConfig = require ROOT_PATH . '/app/config/database.php';
$constants      = require ROOT_PATH . '/app/config/constants.php';

date_default_timezone_set($appConfig['timezone']);

if ($appConfig['debug']) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

use App\Core\Logger;
use App\Core\Database;

Logger::init($appConfig['paths']['logs']);

// Secure-ish session config — adjust 'secure' to true once served over HTTPS.
session_name($appConfig['session']['name']);
session_set_cookie_params([
    'lifetime' => $appConfig['session']['lifetime'] * 60,
    'path'     => '/',
    'httponly' => true,
    'samesite' => 'Lax',
    'secure'   => false, // set true in production once HTTPS is in place
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Single shared DB instance for the request lifecycle.
try {
    $db = new Database($databaseConfig);
} catch (\Throwable $e) {
    Logger::error('Bootstrap DB init failed: ' . $e->getMessage());
    http_response_code(500);
    die('The application is temporarily unavailable. Please try again shortly.');
}
