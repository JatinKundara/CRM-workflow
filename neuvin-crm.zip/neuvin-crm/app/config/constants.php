<?php
/**
 * Business-level constants shared across modules.
 * Centralizing these means a prefix change happens in one place,
 * not in 15 different form.php files.
 */

return [
    'document_prefixes' => [
        'quotation'        => 'QT',
        'sales_order'       => 'SO',
        'sales_bill'        => 'INV',
        'purchase_order'    => 'PO',
        'purchase_bill'     => 'PB',
        'complaint'         => 'CMP',
        'amc'               => 'AMC',
        'material_inward'   => 'GRN',
        'material_outward'  => 'GDN',
        'bank_voucher'      => 'BV',
        'cash_voucher'      => 'CV',
        'petty_cash'        => 'PC',
        'credit_note'       => 'CN',
        'debit_note'        => 'DN',
        'expense_voucher'   => 'EV',
        'journal_voucher'   => 'JV',
        'lead'              => 'LEAD',
    ],

    'company' => [
        'name'    => 'Neuvin Advanced Technologies',
        'address' => "WZ-1258, Third Floor, Nand Gyan Bhawan\nAshram Lane, Palam Village, New Delhi - 110045",
        'phone'   => '+91 11-25081947',
        'mobile'  => '+91 9910584666',
        'email'   => 'info@neuvin.com',
        'website' => 'www.neuvin.com',
        'gstin'   => '07AADCN9370Q1ZO',
        'pan'     => 'AADCN9370Q',
    ],

    'roles' => ['Admin', 'Manager', 'Sales', 'Support', 'HR', 'Accounts', 'Viewer'],
];
