<?php
/**
 * Database connection settings.
 * Values come from .env — never hardcode credentials here.
 */

return [
    'host' => env('DB_HOST', 'localhost'),
    'name' => env('DB_NAME', 'neuvin_crm'),
    'user' => env('DB_USER', 'root'),
    'pass' => env('DB_PASS', ''),
    'charset' => 'utf8mb4',
];
