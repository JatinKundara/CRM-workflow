<?php
/**
 * General application configuration.
 * Pulls from .env via env(), with safe fallbacks.
 */

return [
    'name'      => env('APP_NAME', 'Neuvin CRM'),
    'env'       => env('APP_ENV', 'production'),
    'url'       => env('APP_URL', 'http://localhost'),
    'timezone'  => env('APP_TIMEZONE', 'Asia/Kolkata'),

    'debug'     => env('APP_ENV', 'production') !== 'production',

    // Absolute paths, computed from this file's location so they work
    // regardless of where the project is deployed on disk.
    'paths' => [
        'root'    => dirname(__DIR__, 2),
        'app'     => dirname(__DIR__, 2) . '/app',
        'modules' => dirname(__DIR__, 2) . '/modules',
        'storage' => dirname(__DIR__, 2) . '/storage',
        'uploads' => dirname(__DIR__, 2) . '/storage/uploads',
        'logs'    => dirname(__DIR__, 2) . '/storage/logs',
        'public'  => dirname(__DIR__, 2) . '/public',
    ],

    'upload' => [
        'max_size_mb'       => 5,
        'allowed_extensions'=> ['pdf', 'jpg', 'jpeg', 'png'],
        'allowed_mime_types'=> [
            'application/pdf',
            'image/jpeg',
            'image/png',
        ],
    ],

    'session' => [
        'name'     => env('SESSION_NAME', 'neuvin_crm_session'),
        'lifetime' => (int) env('SESSION_LIFETIME', 120), // minutes
    ],
];
