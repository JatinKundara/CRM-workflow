<?php
/**
 * Minimal .env loader — no external package required.
 * Reads KEY=VALUE lines from the project root .env file into getenv()/$_ENV.
 * Called once from public/index.php before anything else runs.
 */

function load_env(string $path): void
{
    if (!file_exists($path)) {
        // Fail loudly in dev, log quietly in prod — handled by bootstrap, not here.
        throw new RuntimeException(".env file not found at: $path");
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lines as $line) {
        $line = trim($line);

        // Skip comments
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        if (!str_contains($line, '=')) {
            continue;
        }

        [$key, $value] = explode('=', $line, 2);
        $key   = trim($key);
        $value = trim($value);

        // Strip surrounding quotes if present
        $value = trim($value, "\"'");

        putenv("$key=$value");
        $_ENV[$key]    = $value;
        $_SERVER[$key] = $value;
    }
}

/**
 * Convenience getter with default fallback.
 */
function env(string $key, $default = null)
{
    $value = $_ENV[$key] ?? getenv($key);
    return $value !== false && $value !== null ? $value : $default;
}
