<?php

/**
 * Role-restricted version of RequireAuth. Use in modules where only
 * specific roles should have access — e.g. Accounts module pages:
 *
 *   $allowedRoles = ['Admin', 'Accounts'];
 *   require_once __DIR__ . '/../../../app/middleware/RequireRole.php';
 *
 * Set $allowedRoles BEFORE including this file.
 */

use App\Core\Auth;

if (!isset($allowedRoles) || !is_array($allowedRoles)) {
    $allowedRoles = ['Admin'];
}

Auth::requireRole($allowedRoles, '/403.php');
