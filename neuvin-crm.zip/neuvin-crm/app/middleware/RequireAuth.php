<?php

/**
 * Include this at the very top of every protected controller/page:
 *
 *   require_once __DIR__ . '/../../../app/middleware/RequireAuth.php';
 *
 * It guarantees that no module logic below this line runs unless the
 * request comes from a logged-in session. This single file is what
 * closes the gap where every save.php / delete.php was previously
 * reachable by anyone with the URL.
 */

use App\Core\Auth;

Auth::requireLogin('/login.php');
