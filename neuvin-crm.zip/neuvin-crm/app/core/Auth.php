<?php

namespace App\Core;

/**
 * Session-based authentication.
 * This is the piece that was completely missing before — every save.php
 * and delete.php in the previous structure was callable by anyone with
 * the URL. Now controllers call Auth::check() (via RequireAuth middleware)
 * before doing anything with the database.
 */
class Auth
{
    public static function attempt(string $email, string $password, Database $db): bool
    {
        $users = $db->select('users', 'email = ? AND status = ?', [$email, 'Active']);

        if (empty($users)) {
            return false;
        }

        $user = $users[0];

        if (!password_verify($password, $user['password'])) {
            return false;
        }

        self::login($user);
        return true;
    }

    public static function login(array $user): void
    {
        // Never store the password hash in the session
        unset($user['password']);

        $_SESSION['user'] = $user;
        $_SESSION['login_time'] = time();

        session_regenerate_id(true); // prevent session fixation on login
    }

    public static function logout(): void
    {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        session_destroy();
    }

    public static function check(): bool
    {
        return isset($_SESSION['user']);
    }

    public static function user(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public static function userId()
    {
        return $_SESSION['user']['userId'] ?? null;
    }

    public static function role(): ?string
    {
        return $_SESSION['user']['role'] ?? null;
    }

    public static function hasRole(array $allowedRoles): bool
    {
        $role = self::role();
        return $role !== null && in_array($role, $allowedRoles, true);
    }

    /**
     * Redirects to login if not authenticated. Call at the top of every
     * protected page via the RequireAuth middleware include.
     */
    public static function requireLogin(string $loginUrl = '/login.php'): void
    {
        if (!self::check()) {
            header("Location: $loginUrl");
            exit();
        }
    }

    public static function requireRole(array $allowedRoles, string $forbiddenUrl = '/403.php'): void
    {
        self::requireLogin();

        if (!self::hasRole($allowedRoles)) {
            header("Location: $forbiddenUrl");
            exit();
        }
    }
}
