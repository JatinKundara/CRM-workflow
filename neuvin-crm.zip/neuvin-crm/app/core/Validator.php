<?php

namespace App\Core;

/**
 * Lightweight validation helper so every module's controller doesn't
 * reinvent "is this required field empty" checks.
 *
 * Usage:
 *   $v = new Validator($_POST);
 *   $v->required('customerId', 'Customer is required.');
 *   $v->required('quoteNo', 'Quote No is required.');
 *   if ($v->fails()) { ... show $v->errors() ... }
 */
class Validator
{
    private array $data;
    private array $errors = [];

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public function required(string $field, string $message): self
    {
        if (empty($this->data[$field]) && $this->data[$field] !== '0') {
            $this->errors[$field] = $message;
        }
        return $this;
    }

    public function numeric(string $field, string $message): self
    {
        if (isset($this->data[$field]) && $this->data[$field] !== '' && !is_numeric($this->data[$field])) {
            $this->errors[$field] = $message;
        }
        return $this;
    }

    public function email(string $field, string $message): self
    {
        if (!empty($this->data[$field]) && !filter_var($this->data[$field], FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = $message;
        }
        return $this;
    }

    public function maxLength(string $field, int $max, string $message): self
    {
        if (!empty($this->data[$field]) && mb_strlen((string) $this->data[$field]) > $max) {
            $this->errors[$field] = $message;
        }
        return $this;
    }

    public function fails(): bool
    {
        return !empty($this->errors);
    }

    public function passes(): bool
    {
        return empty($this->errors);
    }

    public function errors(): array
    {
        return $this->errors;
    }

    public function firstError(): ?string
    {
        return $this->errors === [] ? null : array_values($this->errors)[0];
    }
}
