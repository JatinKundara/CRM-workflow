<?php

namespace App\Core;

/**
 * One-time session messages, e.g. "Quotation saved successfully"
 * shown once after a redirect, then cleared automatically.
 */
class Flash
{
    public static function set(string $type, string $message): void
    {
        $_SESSION['flash'][$type] = $message;
    }

    public static function success(string $message): void
    {
        self::set('success', $message);
    }

    public static function error(string $message): void
    {
        self::set('error', $message);
    }

    /**
     * Returns all flashed messages and clears them — call once per page load,
     * typically from app/views/partials/flash-messages.php
     */
    public static function consume(): array
    {
        $messages = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $messages;
    }
}
