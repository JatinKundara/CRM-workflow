<?php

namespace App\Core;

/**
 * Writes errors/info to storage/logs instead of printing them to the browser.
 * This is what replaces every die("Query failed: " . $error) call from the
 * original db.php — the user sees a generic message, the real detail goes here.
 */
class Logger
{
    private static string $logPath = '';

    public static function init(string $logDirectory): void
    {
        self::$logPath = rtrim($logDirectory, '/') . '/app.log';

        if (!is_dir($logDirectory)) {
            mkdir($logDirectory, 0755, true);
        }
    }

    public static function error(string $message): void
    {
        self::write('ERROR', $message);
    }

    public static function info(string $message): void
    {
        self::write('INFO', $message);
    }

    public static function warning(string $message): void
    {
        self::write('WARNING', $message);
    }

    private static function write(string $level, string $message): void
    {
        if (self::$logPath === '') {
            // Fallback so a forgotten init() doesn't silently lose errors
            self::$logPath = __DIR__ . '/../../storage/logs/app.log';
        }

        $timestamp = date('Y-m-d H:i:s');
        $line = "[$timestamp] [$level] $message" . PHP_EOL;

        @file_put_contents(self::$logPath, $line, FILE_APPEND);
    }
}
