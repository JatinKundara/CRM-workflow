<?php

namespace App\Core;

/**
 * CSRF protection. None of the forms in the original session had tokens —
 * this closes that gap. Every <form> that POSTs must include the hidden
 * field rendered by Csrf::field(), and every save.php/delete.php must call
 * Csrf::verifyOrFail() before touching the database.
 */
class Csrf
{
    private const SESSION_KEY = 'csrf_token';

    public static function token(): string
    {
        if (empty($_SESSION[self::SESSION_KEY])) {
            $_SESSION[self::SESSION_KEY] = bin2hex(random_bytes(32));
        }

        return $_SESSION[self::SESSION_KEY];
    }

    /**
     * Echoes a hidden input ready to drop into any <form>.
     * Usage in a view: <?= \App\Core\Csrf::field() ?>
     */
    public static function field(): string
    {
        $token = htmlspecialchars(self::token(), ENT_QUOTES, 'UTF-8');
        return '<input type="hidden" name="csrf_token" value="' . $token . '">';
    }

    public static function verify(?string $submittedToken): bool
    {
        if (empty($submittedToken) || empty($_SESSION[self::SESSION_KEY])) {
            return false;
        }

        return hash_equals($_SESSION[self::SESSION_KEY], $submittedToken);
    }

    /**
     * Call this at the top of every POST handler (save.php / delete.php).
     * Stops execution with a 419-style response if the token is missing or wrong.
     */
    public static function verifyOrFail(): void
    {
        $submitted = $_POST['csrf_token'] ?? null;

        if (!self::verify($submitted)) {
            Logger::warning('CSRF token mismatch on ' . ($_SERVER['REQUEST_URI'] ?? 'unknown URI'));
            http_response_code(419);
            die('Your session has expired or the form was submitted incorrectly. Please go back and try again.');
        }
    }
}
