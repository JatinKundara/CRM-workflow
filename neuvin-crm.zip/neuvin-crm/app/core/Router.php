<?php

namespace App\Core;

/**
 * Minimal router. Not a full framework router — just enough to map a
 * clean URL like /quotations or /accounts/bank-voucher to the right
 * module's controller.php, so public/index.php can be the single
 * front controller without needing one file per page on disk to be
 * directly web-accessible.
 *
 * This is OPTIONAL relative to the folder structure itself — modules
 * can also be reached by including their controller.php directly from
 * public/index.php with a simple switch statement if you'd rather not
 * use this class at all. It's provided because the structure assumes
 * a single entry point.
 */
class Router
{
    private array $routes = [];

    public function get(string $path, string $controllerFile): void
    {
        $this->routes['GET'][$this->normalize($path)] = $controllerFile;
    }

    public function post(string $path, string $controllerFile): void
    {
        $this->routes['POST'][$this->normalize($path)] = $controllerFile;
    }

    public function dispatch(string $method, string $uri, string $modulesPath): void
    {
        $path = $this->normalize(parse_url($uri, PHP_URL_PATH) ?? '/');

        $controllerFile = $this->routes[$method][$path] ?? null;

        if ($controllerFile === null) {
            http_response_code(404);
            require __DIR__ . '/../../public/404.php';
            return;
        }

        $fullPath = $modulesPath . '/' . $controllerFile;

        if (!file_exists($fullPath)) {
            Logger::error("Router: controller file missing — $fullPath");
            http_response_code(500);
            echo 'Something went wrong. Please try again later.';
            return;
        }

        require $fullPath;
    }

    private function normalize(string $path): string
    {
        $path = '/' . trim($path, '/');
        return $path === '/' ? '/' : rtrim($path, '/');
    }
}
