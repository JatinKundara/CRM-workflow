<?php

namespace App\Core;

use mysqli;
use RuntimeException;

/**
 * Database access layer.
 *
 * Differences from the original procedural db.php:
 *  - Uses prepared statements for all parameter binding (insert/update/delete),
 *    closing the SQL-injection surface that existed when $cond / $param values
 *    were concatenated directly into query strings.
 *  - Never echoes raw mysqli errors to the browser — logs them via Logger
 *    and throws a generic exception instead. Callers (controllers) decide
 *    what the user sees.
 *  - select_data() still accepts a raw WHERE fragment for flexibility with
 *    existing module code, but insert/update/delete build their own
 *    parameterized queries internally and do not interpolate values.
 */
class Database
{
    private mysqli $connection;

    public function __construct(array $config)
    {
        $this->connection = new mysqli(
            $config['host'],
            $config['user'],
            $config['pass'],
            $config['name']
        );

        if ($this->connection->connect_error) {
            Logger::error('DB connection failed: ' . $this->connection->connect_error);
            throw new RuntimeException('Database connection failed. Check logs for details.');
        }

        $this->connection->set_charset($config['charset'] ?? 'utf8mb4');
    }

    public function raw(): mysqli
    {
        return $this->connection;
    }

    /**
     * SELECT helper.
     * $cond is a raw WHERE fragment for now (kept for compatibility with
     * existing module patterns like "status = 'active'"), but values that
     * come from user input should be passed via $bindings and referenced
     * with ? placeholders inside $cond instead of being concatenated.
     *
     * Example (safe):
     *   select('quotations', 'quoteId = ?', [$quoteId])
     *
     * Example (only safe because $quoteId was cast to int by the caller —
     * avoid this pattern going forward):
     *   select('quotations', "quoteId = $quoteId")
     */
    public function select(string $table, ?string $cond = null, array $bindings = []): array
    {
        $this->assertValidTableName($table);

        $sql = "SELECT * FROM `$table`";
        if ($cond) {
            $sql .= " WHERE $cond";
        }

        if (empty($bindings)) {
            $result = $this->connection->query($sql);
            if ($result === false) {
                Logger::error("Query failed: {$this->connection->error} | SQL: $sql");
                throw new RuntimeException('Database query failed. Check logs for details.');
            }
            return $result->fetch_all(MYSQLI_ASSOC);
        }

        $stmt = $this->prepareAndBind($sql, $bindings);
        $stmt->execute();
        $result = $stmt->get_result();
        $rows   = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
        $stmt->close();

        return $rows;
    }

    /**
     * INSERT — values are always bound as parameters, never concatenated.
     */
    public function insert(string $table, array $data): int
    {
        $this->assertValidTableName($table);

        if (empty($data)) {
            throw new RuntimeException('No data provided to insert.');
        }

        $columns      = array_keys($data);
        $placeholders = implode(',', array_fill(0, count($columns), '?'));
        $columnList   = '`' . implode('`,`', $columns) . '`';

        $sql = "INSERT INTO `$table` ($columnList) VALUES ($placeholders)";

        $stmt = $this->prepareAndBind($sql, array_values($data));
        $success = $stmt->execute();

        if (!$success) {
            Logger::error("Insert failed: {$stmt->error} | SQL: $sql");
            $stmt->close();
            throw new RuntimeException('Database insert failed. Check logs for details.');
        }

        $insertId = $this->connection->insert_id;
        $stmt->close();

        return $insertId;
    }

    /**
     * UPDATE — requires an explicit condition with placeholder(s) and matching
     * bindings, e.g.:
     *   update('quotations', $data, 'quoteId = ?', [$quoteId])
     */
    public function update(string $table, array $data, string $cond, array $condBindings = []): bool
    {
        $this->assertValidTableName($table);

        if (empty($data)) {
            throw new RuntimeException('No data provided to update.');
        }
        if (trim($cond) === '') {
            throw new RuntimeException('A WHERE condition is required to update records.');
        }

        $setParts = [];
        foreach (array_keys($data) as $column) {
            $setParts[] = "`$column` = ?";
        }
        $setClause = implode(', ', $setParts);

        $sql = "UPDATE `$table` SET $setClause WHERE $cond";

        $bindings = array_merge(array_values($data), $condBindings);
        $stmt     = $this->prepareAndBind($sql, $bindings);
        $success  = $stmt->execute();

        if (!$success) {
            Logger::error("Update failed: {$stmt->error} | SQL: $sql");
            $stmt->close();
            throw new RuntimeException('Database update failed. Check logs for details.');
        }

        $stmt->close();
        return true;
    }

    /**
     * DELETE — same pattern as update(): condition placeholders + bindings.
     */
    public function delete(string $table, string $cond, array $condBindings = []): bool
    {
        $this->assertValidTableName($table);

        if (trim($cond) === '') {
            throw new RuntimeException('A WHERE condition is required to delete records.');
        }

        $sql  = "DELETE FROM `$table` WHERE $cond";
        $stmt = $this->prepareAndBind($sql, $condBindings);
        $success = $stmt->execute();

        if (!$success) {
            Logger::error("Delete failed: {$stmt->error} | SQL: $sql");
            $stmt->close();
            throw new RuntimeException('Database delete failed. Check logs for details.');
        }

        $stmt->close();
        return true;
    }

    public function lastInsertId(): int
    {
        return $this->connection->insert_id;
    }

    /**
     * Builds a prepared statement and binds all values generically,
     * regardless of type (mysqli bind_param needs explicit type chars,
     * so we infer them here rather than forcing every caller to know
     * mysqli's type-string format).
     */
    private function prepareAndBind(string $sql, array $bindings)
    {
        $stmt = $this->connection->prepare($sql);

        if ($stmt === false) {
            Logger::error("Prepare failed: {$this->connection->error} | SQL: $sql");
            throw new RuntimeException('Database query preparation failed. Check logs for details.');
        }

        if (!empty($bindings)) {
            $types = '';
            foreach ($bindings as $value) {
                if (is_int($value)) {
                    $types .= 'i';
                } elseif (is_float($value)) {
                    $types .= 'd';
                } else {
                    $types .= 's'; // covers strings, null, and is the safest default
                }
            }
            $stmt->bind_param($types, ...$bindings);
        }

        return $stmt;
    }

    private function assertValidTableName(string $table): void
    {
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {
            throw new RuntimeException("Invalid table name: $table");
        }
    }
}
