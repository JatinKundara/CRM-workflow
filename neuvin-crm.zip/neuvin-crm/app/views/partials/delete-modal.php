<!--
  Shared delete-confirmation modal.
  Include once per page (e.g. in layouts/footer.php), then any delete
  button anywhere on that page just needs:

    <a href="#" data-bs-toggle="modal" data-bs-target="#delete_modal"
       data-id="123" data-type="customers">
       <i class="ti ti-trash"></i>
    </a>

  The JS below reads data-id / data-type and points the confirm button
  at the right module's delete route. data-type must match the route
  prefix registered in public/index.php (e.g. "customers" for the
  /customers/delete route), not the raw folder path under modules/.
-->
<div class="modal fade" id="delete_modal">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-body p-4 text-center">
                <span class="avatar avatar-xl badge-soft-danger border-0 text-danger rounded-circle mb-3">
                    <i class="ti ti-trash fs-24"></i>
                </span>
                <h5 class="mb-1">Delete?</h5>
                <p class="mb-3 text-muted">This action cannot be undone.</p>
                <div class="d-flex justify-content-center gap-2">
                    <a href="#" class="btn btn-light w-100" data-bs-dismiss="modal">Cancel</a>
                    <a href="#" id="confirmDeleteBtn" class="btn btn-danger w-100">Yes, Delete</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('delete_modal').addEventListener('show.bs.modal', function (e) {
    const id   = e.relatedTarget.getAttribute('data-id');
    const type = e.relatedTarget.getAttribute('data-type');
    // type maps to a route prefix, e.g. "customers" -> /customers/delete
    document.getElementById('confirmDeleteBtn').href = '/' + type + '/delete?id=' + id;
});
</script>
