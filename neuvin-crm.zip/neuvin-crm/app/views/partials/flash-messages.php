<?php
use App\Core\Flash;
$flashMessages = Flash::consume();
?>
<?php if (!empty($flashMessages['success'])): ?>
    <div class="alert alert-success d-flex align-items-center gap-2" role="alert">
        <i class="ti ti-circle-check"></i>
        <span><?= e($flashMessages['success']) ?></span>
    </div>
<?php endif; ?>

<?php if (!empty($flashMessages['error'])): ?>
    <div class="alert alert-danger d-flex align-items-center gap-2" role="alert">
        <i class="ti ti-alert-circle"></i>
        <span><?= e($flashMessages['error']) ?></span>
    </div>
<?php endif; ?>
