<?php
/**
 * Shared page header: <head>, top navbar, and the start of the sidebar.
 * Included from each module's index.php / form.php like:
 *   require APP_PATH . '/views/layouts/header.php';
 */
use App\Core\Auth;

$appName = $appConfig['name'] ?? 'Neuvin CRM';
$user    = Auth::user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? $appName) ?></title>

    <!-- Bootstrap, Tabler Icons, Select2 — adjust paths to your build -->
    <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
<div class="wrapper">

    <!-- Sidebar -->
    <?php require __DIR__ . '/sidebar.php'; ?>

    <!-- Top navbar -->
    <header class="topbar d-flex align-items-center justify-content-between px-3">
        <div></div>
        <div class="d-flex align-items-center gap-3">
            <?php if ($user): ?>
                <span class="fw-medium"><?= e($user['name'] ?? '') ?></span>
                <a href="/logout.php" class="btn btn-sm btn-outline-secondary">
                    <i class="ti ti-logout me-1"></i>Logout
                </a>
            <?php endif; ?>
        </div>
    </header>

    <main class="page-wrapper">
        <div class="content">
            <?php require __DIR__ . '/../partials/flash-messages.php'; ?>
