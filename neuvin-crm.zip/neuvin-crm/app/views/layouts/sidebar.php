<?php
/**
 * Sidebar navigation.
 *
 * IMPORTANT: links here must be clean routes registered in
 * public/index.php (e.g. "/customers"), NOT direct paths into modules/
 * (e.g. "/modules/customers/index.php") — the latter are unreachable
 * by design, since modules/ sits outside the public web root.
 *
 * Only /customers and /quotations are wired up as real routes in this
 * skeleton. The remaining links below are placeholders showing the
 * intended URL pattern — register each one in public/index.php using
 * the same four-line block already used for customers, then the link
 * will work without any further changes needed here.
 */
?>
<nav class="sidebar">
    <ul class="sidebar-menu">

        <li><a href="/dashboard.php"><i class="ti ti-layout-dashboard"></i><span>Dashboard</span></a></li>

        <li><a href="/customers"><i class="ti ti-building-store"></i><span>Customers</span></a></li>
        <li><a href="/contacts"><i class="ti ti-users"></i><span>Contacts</span></a></li>
        <li><a href="/suppliers"><i class="ti ti-truck"></i><span>Suppliers</span></a></li>
        <li><a href="/products"><i class="ti ti-package"></i><span>Products</span></a></li>
        <li><a href="/quotations"><i class="ti ti-file-invoice"></i><span>Quotations</span></a></li>

        <li class="submenu">
            <a href="javascript:void(0);"><i class="ti ti-shopping-cart"></i><span>Sales</span><span class="menu-arrow"></span></a>
            <ul>
                <li><a href="/sales/sales-order">Sales Order</a></li>
                <li><a href="/sales/sales-order-approval">Sales Order Approval</a></li>
                <li><a href="/sales/sales-bill">Sales Bill</a></li>
                <li><a href="/sales/purchase-order">Purchase Order</a></li>
                <li><a href="/sales/purchase-approval">Purchase Approval</a></li>
                <li><a href="/sales/purchase-bill">Purchase Bill</a></li>
            </ul>
        </li>

        <li class="submenu">
            <a href="javascript:void(0);"><i class="ti ti-topology-star-3"></i><span>Lead MGMT</span><span class="menu-arrow"></span></a>
            <ul>
                <li><a href="/leads/telecaller">Telecaller Lead</a></li>
                <li><a href="/leads/lead-generation">Lead Generation</a></li>
                <li><a href="/leads/followups">Followups</a></li>
            </ul>
        </li>

        <li class="submenu">
            <a href="javascript:void(0);"><i class="ti ti-headset"></i><span>Support</span><span class="menu-arrow"></span></a>
            <ul>
                <li><a href="/support/complaints">Complaint Register</a></li>
                <li><a href="/support/complaint-visit">Complaint Visit</a></li>
                <li><a href="/support/amc">AMC</a></li>
            </ul>
        </li>

        <li class="submenu">
            <a href="javascript:void(0);"><i class="ti ti-packages"></i><span>Trading</span><span class="menu-arrow"></span></a>
            <ul>
                <li><a href="/trading/material-inward">Material Inward</a></li>
                <li><a href="/trading/material-outward">Material Outward</a></li>
            </ul>
        </li>

        <li class="submenu">
            <a href="javascript:void(0);"><i class="ti ti-users-group"></i><span>HR</span><span class="menu-arrow"></span></a>
            <ul>
                <li><a href="/hr/organization">Organization</a></li>
                <li><a href="/hr/employees">Employees</a></li>
                <li><a href="/hr/attendance">Attendance</a></li>
                <li><a href="/hr/leave-request">Leave Request</a></li>
                <li><a href="/hr/leave-approval">Leave Approval</a></li>
                <li><a href="/hr/shift-time">Shift Time</a></li>
                <li><a href="/hr/payslip">Payslip</a></li>
            </ul>
        </li>

        <li class="submenu">
            <a href="javascript:void(0);"><i class="ti ti-cash"></i><span>Accounts</span><span class="menu-arrow"></span></a>
            <ul>
                <li><a href="/accounts/bank-voucher">Bank Voucher</a></li>
                <li><a href="/accounts/cash-voucher">Cash Voucher</a></li>
                <li><a href="/accounts/petty-cash">Petty Cash</a></li>
                <li><a href="/accounts/credit-note">Credit Note</a></li>
                <li><a href="/accounts/debit-note">Debit Note</a></li>
                <li><a href="/accounts/expense-voucher">Expense Voucher</a></li>
                <li><a href="/accounts/journal-voucher">Journal Voucher</a></li>
            </ul>
        </li>

        <li class="submenu">
            <a href="javascript:void(0);"><i class="ti ti-briefcase"></i><span>Office Management</span><span class="menu-arrow"></span></a>
            <ul>
                <li><a href="/office/task-management">Task Management</a></li>
                <li><a href="/office/work-log">Daily Work Log</a></li>
            </ul>
        </li>

        <li><a href="/settings"><i class="ti ti-settings"></i><span>Settings</span></a></li>

    </ul>
</nav>
