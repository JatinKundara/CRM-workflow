        </div><!-- /.content -->
    </main>

</div><!-- /.wrapper -->

<?php require __DIR__ . '/../partials/delete-modal.php'; ?>

<script src="/assets/js/app.js"></script>
</body>
</html>
