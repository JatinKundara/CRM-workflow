<?php

/**
 * Shared helper functions used across modules.
 * Centralized here instead of being copy-pasted into every PDF generator
 * and form.php, the way numberToWords() and status badge logic were
 * duplicated across the quotation and proforma invoice code previously.
 */

if (!function_exists('format_currency')) {
    function format_currency(float $amount, string $symbol = '₹'): string
    {
        return $symbol . ' ' . number_format($amount, 2);
    }
}

if (!function_exists('generate_document_number')) {
    /**
     * Generates the next sequential document number for a given prefix.
     * Example: generate_document_number('QT', $count) -> "QT-2026-0001"
     */
    function generate_document_number(string $prefix, int $existingCount): string
    {
        return $prefix . '-' . date('Y') . '-' . str_pad($existingCount + 1, 4, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('number_to_words')) {
    /**
     * Converts an integer amount to Indian-style words (Lakh, Crore).
     * Used by the Proforma Invoice PDF for the "Total INR ... Only" line.
     */
    function number_to_words(int $num): string
    {
        $ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
                 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
                 'Seventeen', 'Eighteen', 'Nineteen'];
        $tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

        if ($num < 20) {
            return $ones[$num];
        }
        if ($num < 100) {
            return $tens[(int) ($num / 10)] . ($num % 10 ? ' ' . $ones[$num % 10] : '');
        }
        if ($num < 1000) {
            return $ones[(int) ($num / 100)] . ' Hundred' . ($num % 100 ? ' ' . number_to_words($num % 100) : '');
        }
        if ($num < 100000) {
            return number_to_words((int) ($num / 1000)) . ' Thousand' . ($num % 1000 ? ' ' . number_to_words($num % 1000) : '');
        }
        if ($num < 10000000) {
            return number_to_words((int) ($num / 100000)) . ' Lakh' . ($num % 100000 ? ' ' . number_to_words($num % 100000) : '');
        }
        return number_to_words((int) ($num / 10000000)) . ' Crore' . ($num % 10000000 ? ' ' . number_to_words($num % 10000000) : '');
    }
}

if (!function_exists('status_badge_class')) {
    /**
     * Maps a status string to a Bootstrap badge class.
     * Covers the status enums used across quotations, sales orders,
     * purchase orders, complaints, and leave requests.
     */
    function status_badge_class(string $status): string
    {
        $map = [
            'Draft'             => 'badge-soft-secondary',
            'Submitted'         => 'badge-soft-info',
            'Pending'           => 'badge-soft-warning',
            'Pending Approval'  => 'badge-soft-warning',
            'Approved'          => 'badge-soft-success',
            'Active'            => 'badge-soft-success',
            'Open'              => 'badge-soft-danger',
            'InProgress'        => 'badge-soft-warning',
            'Processing'        => 'badge-soft-info',
            'Resolved'          => 'badge-soft-success',
            'Delivered'         => 'badge-soft-primary',
            'Paid'              => 'badge-soft-success',
            'Unpaid'            => 'badge-soft-danger',
            'Overdue'           => 'badge-soft-danger',
            'Rejected'          => 'badge-soft-danger',
            'Expired'           => 'badge-soft-danger',
            'Cancelled'         => 'badge-soft-dark',
            'Closed'            => 'badge-soft-secondary',
            'ConvertedToSO'     => 'badge-soft-primary',
        ];

        return $map[$status] ?? 'badge-soft-secondary';
    }
}

if (!function_exists('e')) {
    /**
     * Shorthand for htmlspecialchars(), used heavily in every view.
     */
    function e(?string $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('old')) {
    /**
     * Re-populates a form field with its previously submitted value
     * after a validation failure redirect, falling back to $default.
     */
    function old(string $field, $default = '')
    {
        return $_SESSION['old_input'][$field] ?? $default;
    }
}
