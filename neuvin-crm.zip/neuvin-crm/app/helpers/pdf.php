<?php

namespace App\Helpers;

use Dompdf\Dompdf;
use Dompdf\Options;

/**
 * Shared DOMPDF instantiation, so every PDF generator (quotation,
 * proforma invoice, payslip, etc.) doesn't repeat the same Options setup.
 */
class Pdf
{
    public static function make(): Dompdf
    {
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isRemoteEnabled', true);
        $options->set('defaultFont', 'DejaVu Sans');

        return new Dompdf($options);
    }

    /**
     * Reads an image file and returns it as a base64 data URI,
     * ready to embed directly in PDF HTML (DOMPDF cannot reliably
     * load images via filesystem path alone in all environments).
     */
    public static function imageToBase64(string $absolutePath): string
    {
        if (!file_exists($absolutePath)) {
            return '';
        }

        $extension = strtolower(pathinfo($absolutePath, PATHINFO_EXTENSION));
        $mime      = match ($extension) {
            'png'        => 'image/png',
            'jpg', 'jpeg'=> 'image/jpeg',
            default      => 'image/jpeg',
        };

        return 'data:' . $mime . ';base64,' . base64_encode(file_get_contents($absolutePath));
    }

    /**
     * Streams a PDF as a downloadable attachment with a sanitized filename.
     */
    public static function download(Dompdf $dompdf, string $html, string $filename, string $paper = 'A4', string $orientation = 'portrait'): void
    {
        $dompdf->loadHtml($html);
        $dompdf->setPaper($paper, $orientation);
        $dompdf->render();

        $safeFilename = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $filename);
        $dompdf->stream($safeFilename . '.pdf', ['Attachment' => true]);
        exit();
    }
}
