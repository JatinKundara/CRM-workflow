<?php

namespace App\Helpers;

use App\Core\Logger;
use RuntimeException;

/**
 * Centralized upload handling with real MIME-type verification.
 * The original db.php trusted the filename extension alone — this checks
 * the actual file content via finfo before accepting it, which is what
 * stops a renamed "shell.php.jpg" from being treated as a real image.
 */
class Upload
{
    public static function validateAndMove(array $file, string $destinationDir, array $allowedExtensions, array $allowedMimeTypes, int $maxSizeMb): string
    {
        if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException('File upload failed. Please try again.');
        }

        if ($file['size'] > $maxSizeMb * 1024 * 1024) {
            throw new RuntimeException("File is too large. Maximum allowed size is {$maxSizeMb}MB.");
        }

        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, $allowedExtensions, true)) {
            throw new RuntimeException('File type not allowed: .' . $extension);
        }

        // Real MIME check — never trust the extension or $_FILES['type'] alone,
        // both of which are client-supplied and can be spoofed.
        $finfo    = new \finfo(FILEINFO_MIME_TYPE);
        $realMime = $finfo->file($file['tmp_name']);

        if (!in_array($realMime, $allowedMimeTypes, true)) {
            Logger::warning("Upload rejected — claimed extension .$extension but real MIME was $realMime");
            throw new RuntimeException('File content does not match an allowed file type.');
        }

        if (!is_dir($destinationDir)) {
            mkdir($destinationDir, 0755, true);
        }

        $uniqueName = uniqid('file_', true) . '.' . $extension;
        $targetPath = rtrim($destinationDir, '/') . '/' . $uniqueName;

        if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
            throw new RuntimeException('Failed to save the uploaded file.');
        }

        return $targetPath;
    }
}
