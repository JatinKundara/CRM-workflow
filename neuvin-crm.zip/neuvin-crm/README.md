# Neuvin CRM

Internal CRM for Neuvin Advanced Technologies. PHP/MySQL, no framework —
structured for a single developer to extend safely as modules grow.

## Folder structure at a glance

```
app/        Framework-ish code: config, core classes, helpers, middleware, shared views.
            NOT web-accessible — sits outside public/.

modules/    One folder per feature (customers, quotations, accounts/bank-voucher, etc.)
            EACH module is web-accessible directly (e.g. /modules/customers/index.php),
            since public/index.php currently just redirects to /dashboard.php rather
            than routing every request itself.

storage/    Uploaded files, logs, DB backups. Writable at runtime, NOT web-accessible.

public/     The ONLY folder your web server's document root should point to.
            Contains the front controller, login/dashboard/logout, error pages,
            and static assets (css/js/img).

vendor/     Composer dependencies (DOMPDF etc.)
```

## First-time setup

1. **Point your web server's document root at `public/`** — not at the
   project root. This is the single most important step; everything else
   assumes `app/`, `modules/`, and `storage/` are *not* reachable by URL.

2. **Copy `.env.example` to `.env`** and fill in real database credentials.
   `.env` is already in `.gitignore` — never commit it.

3. **Install dependencies:**
   ```
   composer install
   ```

4. **Create the `users` table** (referenced by `App\Core\Auth`) if it
   doesn't already exist in your schema:
   ```sql
   CREATE TABLE users (
     userId INT AUTO_INCREMENT PRIMARY KEY,
     name VARCHAR(255),
     email VARCHAR(255) UNIQUE,
     password VARCHAR(255),
     role VARCHAR(50),
     status ENUM('Active','Inactive') DEFAULT 'Active'
   );
   ```
   Passwords must be hashed with `password_hash($plain, PASSWORD_DEFAULT)`
   when you insert your first admin user — `Auth::attempt()` verifies
   against `password_verify()`.

5. **Visit `/login.php`**, log in, you'll land on `/dashboard.php`.

## What's fully built vs. scaffolded

- **`modules/customers/`** is a complete, working reference module:
  repository, list page, create/edit form, save handler, delete handler —
  all wired to auth, CSRF, validation, and flash messages.

- **Every other module folder** (`modules/quotations/`, `modules/accounts/bank-voucher/`,
  etc.) contains only a `README.md` describing the pattern to copy from
  `customers/`. The actual form fields, table columns, and PDF logic for
  those modules were already designed in earlier conversation — this
  scaffold defines *where* that code belongs, not what it contains.

## Key architectural decisions (and why)

| Decision | Reason |
|---|---|
| `public/` is the only web root | Everything else (config, .env, module save/delete handlers) is physically unreachable by URL, even if `.htaccess` rules fail. |
| `app/core/Database.php` uses prepared statements everywhere | Closes the SQL-injection surface that existed when `$cond` values were concatenated as raw strings. |
| `app/core/Auth.php` + `app/middleware/RequireAuth.php` | Every protected `index.php`/`form.php`/`save.php`/`delete.php` requires this at the top. Previously nothing enforced login at all. |
| `app/core/Csrf.php` | Every `<form>` must include `Csrf::field()`; every POST handler must call `Csrf::verifyOrFail()` first. |
| `app/core/Logger.php` | Replaces `die("Query failed: " . $error)` patterns — errors go to `storage/logs/app.log`, never to the browser. |
| One `Repository` class per module | All SQL for a module lives in one place (e.g. `CustomerRepository.php`), not scattered across `index.php`/`form.php`/`save.php`. |
| PSR-4 autoloading via Composer | Class filenames must match class names exactly (`CustomerRepository.php` contains `class CustomerRepository`). No manual `require` needed for classes once `vendor/autoload.php` is loaded. |

## Known gaps to close before real production traffic

- `delete.php` handlers currently use GET + a confirmation modal, not
  POST + CSRF. Harden this before going live with financial records.
- HTTPS / secure cookies: `app/bootstrap.php` sets `'secure' => false`
  for the session cookie — flip to `true` once served over HTTPS.
- No automated tests exist yet. At minimum, test `Database::update()`
  and `Database::insert()` against a throwaway schema before trusting
  them with real customer/quotation data.
- `Router.php` is provided but unused by default — `public/index.php`
  currently just redirects to `/dashboard.php`. Decide whether to adopt
  clean URLs via the router or keep direct module-file access before
  this grows much further; mixing both patterns will get confusing.
