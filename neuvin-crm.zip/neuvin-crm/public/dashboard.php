<?php

require_once dirname(__DIR__) . '/app/bootstrap.php';
require_once dirname(__DIR__) . '/app/middleware/RequireAuth.php';

$pageTitle = 'Dashboard';

require $appConfig['paths']['app'] . '/views/layouts/header.php';
?>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h2 class="mb-1 fs-2">Dashboard</h2>
        <p class="text-muted mb-0">Welcome back<?= isset($_SESSION['user']['name']) ? ', ' . e($_SESSION['user']['name']) : '' ?></p>
    </div>
</div>

<div class="row row-gap-3">
    <div class="col-xl-3 col-sm-6">
        <a href="/quotations" class="card text-decoration-none d-block">
            <div class="card-body">
                <i class="ti ti-file-invoice fs-24 text-primary mb-2"></i>
                <h6 class="fw-bold mb-0">Quotations</h6>
            </div>
        </a>
    </div>
    <div class="col-xl-3 col-sm-6">
        <a href="/sales/sales-order" class="card text-decoration-none d-block">
            <div class="card-body">
                <i class="ti ti-shopping-cart fs-24 text-success mb-2"></i>
                <h6 class="fw-bold mb-0">Sales Orders</h6>
            </div>
        </a>
    </div>
    <div class="col-xl-3 col-sm-6">
        <a href="/support/complaints" class="card text-decoration-none d-block">
            <div class="card-body">
                <i class="ti ti-headset fs-24 text-danger mb-2"></i>
                <h6 class="fw-bold mb-0">Support</h6>
            </div>
        </a>
    </div>
    <div class="col-xl-3 col-sm-6">
        <a href="/accounts/bank-voucher" class="card text-decoration-none d-block">
            <div class="card-body">
                <i class="ti ti-cash fs-24 text-warning mb-2"></i>
                <h6 class="fw-bold mb-0">Accounts</h6>
            </div>
        </a>
    </div>
</div>

<p class="text-muted mt-4 fs-13">
    This dashboard is a placeholder. Wire up real stat cards here the same way
    the module overview pages were built — pull counts via each module's
    repository class instead of querying the database directly from this file.
</p>

<?php require $appConfig['paths']['app'] . '/views/layouts/footer.php'; ?>
