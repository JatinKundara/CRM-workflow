<?php

require_once dirname(__DIR__) . '/app/bootstrap.php';

http_response_code(404);
$pageTitle = 'Page Not Found';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= e($pageTitle) ?></title>
    <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
    <div class="d-flex flex-column align-items-center justify-content-center" style="height:100vh;">
        <i class="ti ti-error-404 fs-1 text-muted mb-3"></i>
        <h2>404 — Page Not Found</h2>
        <p class="text-muted">The page you're looking for doesn't exist.</p>
        <a href="/dashboard.php" class="btn btn-primary">Back to Dashboard</a>
    </div>
</body>
</html>
