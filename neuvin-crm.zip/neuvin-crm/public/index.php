<?php

/**
 * Single front controller. This is the ONLY PHP file in public/ that
 * actually runs application logic — everything else under public/
 * is static assets (css/js/img).
 *
 * Apache/Nginx rewrites all requests that aren't real files in
 * public/assets/ to this file (see public/.htaccess).
 *
 * IMPORTANT: modules/ lives OUTSIDE public/ on purpose (see the
 * security rationale in the structure write-up — it stops module
 * PHP files from being requested directly by URL). That means every
 * link in the app must go through a clean route defined here, which
 * dispatches to the right module file server-side. Module views must
 * therefore link to routes like "/customers" rather than
 * "/modules/customers/index.php" — the latter will 404 in production
 * because it is not reachable.
 */

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Core\Router;

$router = new Router();

// ── Customers ──
$router->get('/customers',            'customers/index.php');
$router->get('/customers/form',       'customers/form.php');
$router->post('/customers/save',      'customers/save.php');
$router->get('/customers/delete',     'customers/delete.php');

// ── Quotations ──
$router->get('/quotations',                 'quotations/index.php');
$router->get('/quotations/form',            'quotations/form.php');
$router->post('/quotations/save',           'quotations/save.php');
$router->get('/quotations/delete',          'quotations/delete.php');
$router->get('/quotations/download',        'quotations/download_quote.php');
$router->get('/quotations/proforma-invoice','quotations/proforma_invoice.php');

// Additional modules (contacts, suppliers, products, sales/*, leads/*,
// support/*, trading/*, hr/*, accounts/*, office/*, settings) follow the
// exact same four-line pattern as customers above — add them here as
// each module's controller files are built out, using the same
// index / form / save / delete naming used throughout this project.

$router->dispatch(
    $_SERVER['REQUEST_METHOD'],
    $_SERVER['REQUEST_URI'],
    $appConfig['paths']['modules']
);
