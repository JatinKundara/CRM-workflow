<?php

require_once dirname(__DIR__) . '/app/bootstrap.php';

http_response_code(403);
$pageTitle = 'Access Denied';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= e($pageTitle) ?></title>
    <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
    <div class="d-flex flex-column align-items-center justify-content-center" style="height:100vh;">
        <i class="ti ti-lock fs-1 text-danger mb-3"></i>
        <h2>403 — Access Denied</h2>
        <p class="text-muted">You don't have permission to view this page.</p>
        <a href="/dashboard.php" class="btn btn-primary">Back to Dashboard</a>
    </div>
</body>
</html>
