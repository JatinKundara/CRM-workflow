<?php

namespace Modules\Customers;

use App\Core\Database;

/**
 * All SQL for the customers module lives here. Controllers never write
 * raw SQL directly — they call repository methods, which use Database's
 * prepared-statement methods under the hood.
 */
class CustomerRepository
{
    public function __construct(private Database $db) {}

    public function all(): array
    {
        return $this->db->select('customers', "status = ?", ['active']);
    }

    public function find(int $customerId): ?array
    {
        $rows = $this->db->select('customers', 'customerId = ?', [$customerId]);
        return $rows[0] ?? null;
    }

    public function create(array $data): int
    {
        return $this->db->insert('customers', $data);
    }

    public function update(int $customerId, array $data): bool
    {
        return $this->db->update('customers', $data, 'customerId = ?', [$customerId]);
    }

    public function delete(int $customerId): bool
    {
        return $this->db->delete('customers', 'customerId = ?', [$customerId]);
    }
}
