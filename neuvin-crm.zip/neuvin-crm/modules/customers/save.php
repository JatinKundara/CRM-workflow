<?php

/**
 * Customer POST handler — create or update depending on whether
 * ?id= is present, mirroring the pattern fixed in the quotation module:
 * insert_data() for new records, update_data() (with a real WHERE) for edits.
 */

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/middleware/RequireAuth.php';

use App\Core\Csrf;
use App\Core\Flash;
use App\Core\Validator;
use Modules\Customers\CustomerRepository;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /customers');
    exit();
}

Csrf::verifyOrFail();

$validator = new Validator($_POST);
$validator->required('companyName', 'Company name is required.');

if ($validator->fails()) {
    Flash::error($validator->firstError());
    $_SESSION['old_input'] = $_POST;
    header('Location: /customers/form' . (!empty($_GET['id']) ? '?id=' . (int) $_GET['id'] : ''));
    exit();
}

$repository = new CustomerRepository($db);

$data = [
    'companyName' => trim($_POST['companyName']),
    'industry'    => trim($_POST['industry'] ?? ''),
    'gstin'       => trim($_POST['gstin']    ?? ''),
    'phone'       => trim($_POST['phone']    ?? ''),
    'email'       => trim($_POST['email']    ?? ''),
    'city'        => trim($_POST['city']     ?? ''),
    'status'      => trim($_POST['status']   ?? 'active'),
];

$customerId = (int) ($_GET['id'] ?? 0);

try {
    if ($customerId > 0) {
        $repository->update($customerId, $data);
        Flash::success('Customer updated successfully.');
    } else {
        $repository->create($data);
        Flash::success('Customer added successfully.');
    }
} catch (\Throwable $e) {
    Flash::error('Something went wrong while saving the customer.');
}

header('Location: /customers');
exit();
