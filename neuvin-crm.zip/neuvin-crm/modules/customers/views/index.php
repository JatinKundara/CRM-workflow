<?php
/**
 * Customers list view. Expects $customers from the controller.
 */
?>
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
    <div>
        <h2 class="mb-1 fs-2">Customers</h2>
        <p class="text-muted mb-0">Manage your customer accounts</p>
    </div>
    <a href="/customers/form" class="btn btn-primary">
        <i class="ti ti-plus me-1"></i>Add Customer
    </a>
</div>

<div class="card">
    <div class="card-body p-0">
        <table class="table table-nowrap mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Company</th>
                    <th>Industry</th>
                    <th>City</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($customers)): ?>
                    <?php foreach ($customers as $i => $customer): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><strong><?= e($customer['companyName']) ?></strong></td>
                            <td><?= e($customer['industry'] ?? '-') ?></td>
                            <td><?= e($customer['city'] ?? '-') ?></td>
                            <td><?= e($customer['phone'] ?? '-') ?></td>
                            <td>
                                <span class="badge <?= status_badge_class(ucfirst($customer['status'])) ?>">
                                    <?= e(ucfirst($customer['status'])) ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <a href="/customers/form?id=<?= (int) $customer['customerId'] ?>"
                                   class="btn btn-icon btn-sm btn-outline-white border-0">
                                    <i class="ti ti-edit"></i>
                                </a>
                                <a href="#" data-bs-toggle="modal" data-bs-target="#delete_modal"
                                   data-id="<?= (int) $customer['customerId'] ?>" data-type="customers"
                                   class="btn btn-icon btn-sm btn-outline-white border-0">
                                    <i class="ti ti-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">No customers found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
