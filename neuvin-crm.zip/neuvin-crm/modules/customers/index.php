<?php

/**
 * Customers module controller.
 * Normally reached via the router at GET /customers (see public/index.php),
 * which already runs app/bootstrap.php before requiring this file.
 * The require_once below is a no-op in that case (same absolute path,
 * already loaded) but keeps this file safely runnable on its own too.
 */

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/middleware/RequireAuth.php';

use Modules\Customers\CustomerRepository;

$repository = new CustomerRepository($db);
$customers  = $repository->all();

$pageTitle = 'Customers';

require $appConfig['paths']['app'] . '/views/layouts/header.php';
require __DIR__ . '/views/index.php';
require $appConfig['paths']['app'] . '/views/layouts/footer.php';
