<?php

/**
 * Customer delete handler.
 * Note: unlike save.php, delete is triggered via a GET link from the
 * delete-confirmation modal (see app/views/partials/delete-modal.php).
 * Since this performs a destructive action, ideally this should be a
 * POST request with a CSRF token in production — the GET pattern here
 * matches the modal markup already in use, but ought to be hardened to
 * POST + CSRF before going live with real data.
 */

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/middleware/RequireAuth.php';

use App\Core\Flash;
use App\Core\Logger;
use Modules\Customers\CustomerRepository;

$customerId = (int) ($_GET['id'] ?? 0);

if ($customerId <= 0) {
    Flash::error('Invalid customer.');
    header('Location: /customers');
    exit();
}

$repository = new CustomerRepository($db);

try {
    $repository->delete($customerId);
    Flash::success('Customer deleted.');
} catch (\Throwable $e) {
    Logger::error('Customer delete failed: ' . $e->getMessage());
    Flash::error('Could not delete this customer.');
}

header('Location: /customers');
exit();
