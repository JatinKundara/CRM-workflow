<?php

/**
 * Customer create/edit form controller.
 * Loads existing data if ?id= is present, then renders the form.
 * Actual save logic lives in save.php — this file only displays.
 */

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/middleware/RequireAuth.php';

use App\Core\Csrf;
use Modules\Customers\CustomerRepository;

$repository = new CustomerRepository($db);

$customerId = (int) ($_GET['id'] ?? 0);
$isEdit     = $customerId > 0;
$customer   = $isEdit ? $repository->find($customerId) : [];

$pageTitle = $isEdit ? 'Edit Customer' : 'Add Customer';

require $appConfig['paths']['app'] . '/views/layouts/header.php';
?>

<div class="d-flex align-items-center justify-content-between mb-4">
    <h2 class="mb-0 fs-2"><?= $isEdit ? 'Edit Customer' : 'Add Customer' ?></h2>
</div>

<form action="/customers/save<?= $isEdit ? '?id=' . $customerId : '' ?>" method="POST">
    <?= Csrf::field() ?>

    <div class="card">
        <div class="card-body">
            <div class="row row-gap-3">

                <div class="col-lg-6">
                    <label class="form-label">Company Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="companyName"
                        value="<?= e($customer['companyName'] ?? '') ?>" required>
                </div>

                <div class="col-lg-6">
                    <label class="form-label">Industry</label>
                    <input type="text" class="form-control" name="industry"
                        value="<?= e($customer['industry'] ?? '') ?>">
                </div>

                <div class="col-lg-6">
                    <label class="form-label">GSTIN</label>
                    <input type="text" class="form-control" name="gstin"
                        value="<?= e($customer['gstin'] ?? '') ?>">
                </div>

                <div class="col-lg-6">
                    <label class="form-label">Phone</label>
                    <input type="text" class="form-control" name="phone"
                        value="<?= e($customer['phone'] ?? '') ?>">
                </div>

                <div class="col-lg-6">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="email"
                        value="<?= e($customer['email'] ?? '') ?>">
                </div>

                <div class="col-lg-6">
                    <label class="form-label">City</label>
                    <input type="text" class="form-control" name="city"
                        value="<?= e($customer['city'] ?? '') ?>">
                </div>

                <div class="col-lg-6">
                    <label class="form-label">Status</label>
                    <select class="form-select" name="status">
                        <option value="active"   <?= ($customer['status'] ?? 'active') === 'active'   ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= ($customer['status'] ?? '')        === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>

            </div>
        </div>
    </div>

    <div class="mt-3 d-flex gap-2">
        <button type="submit" class="btn btn-success">
            <i class="ti ti-device-floppy me-1"></i><?= $isEdit ? 'Update' : 'Save' ?> Customer
        </button>
        <a href="/customers" class="btn btn-light">Cancel</a>
    </div>
</form>

<?php require $appConfig['paths']['app'] . '/views/layouts/footer.php'; ?>
