# quotations

This module is scaffolded but not yet implemented.

Copy the pattern from `modules/customers/` (the fully-built reference
module) to build this one:

1. **Repository class** (e.g. `CustomerRepository.php`) — all SQL for this
   module, using `$db->select() / insert() / update() / delete()` with
   bound parameters. Filename must match the class name exactly for
   PSR-4 autoloading.

2. **`index.php`** — controller for the list page. Requires
   `app/bootstrap.php` + `app/middleware/RequireAuth.php`, instantiates the
   repository, fetches records, then includes
   `app/views/layouts/header.php` -> `views/index.php` -> `app/views/layouts/footer.php`.

3. **`form.php`** — controller + view for create/edit. Loads existing data
   when `?id=` is present (edit mode), otherwise renders blank (create mode).
   Includes `App\Core\Csrf::field()` inside the `<form>`.

4. **`save.php`** — POST handler. Calls `Csrf::verifyOrFail()` first, then
   validates input with `App\Core\Validator`, then calls the repository's
   `create()` or `update()` depending on whether an id was submitted.

5. **`delete.php`** — calls the repository's `delete()`, sets a flash
   message, redirects back to `index.php`.

6. **`views/index.php`** — pure HTML/PHP list table, no business logic.
   **`views/form.php`** if the form markup is long enough to split out.

Refer to the field names, sections, and validation rules already designed
for this module earlier in the project — this scaffold just defines
*where* that code should live in the production structure.
